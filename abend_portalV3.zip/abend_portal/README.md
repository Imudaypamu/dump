# Abend desk

One Flask app replacing `Master_Abend_Tracker_v9_1.xlsx` (tracker + VBA incident macro) and
`Grid_Issues_Analsys_V3_Final.xlsx` (dashboard).

## Setup (Windows or Linux, Python 3.10+)
```
pip install -r requirements.txt
copy .env.example .env        (cp on Linux)  -> set PORTAL_USER / PORTAL_PASSWORD (and optionally PORTAL_OPERATOR_*)
python run.py                 # http://127.0.0.1:5000
```
`data/Abend_Portal_Data.xlsx` ships pre-loaded with your history, so no database or init step is needed.

## Users and what each can do
* **admin**: everything, including the **MyWizard** page (URL, headers, tokens, fetch/close settings, live/dry-run) and
  the **Users** page.
* **operator**: intake, tracker, dashboard, creating/closing incidents, script incidents, Config tables (root causes,
  ITSM defaults, applications). Cannot see or change the MyWizard connection, switch live/dry-run, or manage users.
  An operator never sees the MyWizard URLs, headers or tokens (they do see the shape of the request body in previews).
* The admin (and optional operator) are created from `.env` on the very first start. After that, users are managed on
  the Users page and the `.env` passwords are ignored. Everyone can change their own password under their name.
* Sign-in locks out an address for 5 minutes after 5 wrong passwords.

## The MyWizard connection (admin > MyWizard)
Set inside the portal, not in `.env`. It is the portal's version of
`curl -s -X POST <url> -H "Name: value" ...`: a URL plus a free list of header rows. Default rows: Accept,
Content-Type, X-WL-AUTH, Authorization. Add any other header you need. Tick **secret** on tokens: they are stored
**encrypted** in the workbook (key = `instance/secret.key`), are never shown again, and a blank value on re-save keeps
the stored one. There is no caller_id, X-API-Key or Message-Id.
If you ever lose or replace `instance/secret.key`, the secret headers can't be decrypted: the page tells you and you
enter them again. Back up `instance/` together with `data/`.

Three calls use that one header set: **create** (POST), **close** (POST/PUT/PATCH/DELETE) and **fetch**
(POST/GET). The request bodies for fetch and close are JSON templates you can edit; their defaults are guesses at
your MyWizard contract and have never been tested against the real API.

## Daily flow
1. **Raw intake**: paste the text (tab separated: app, task text, root cause, action, date, category).
2. **Review**: every extracted field is shown and editable; unknown root causes can be added in one click; duplicates
   are unticked.
3. **Log ticked rows**: they appear on the Tracker and Dashboard.
4. **Incidents**: preview, then create in bulk: grouped (category + issue type + action), one per task, or a mix
   (tick *One per task* on any group). Starts in **dry run**; only an admin can go live.

## Service desk
* **Dashboard** shows open incidents, recently closed incidents, open RITMs and recently closed RITMs.
* **Script incidents**: press *Fetch from MyWizard* to pull the incidents for configuration item **Informatica**
  assigned to **ETL Support** (both editable on the MyWizard page; anything for another CI or team is dropped). Each
  is read for task / app / category / root cause, matched to the tracker row for the same task (same day +-1), and
  can be filtered like the tracker. If there is no API access, import a ServiceNow export instead.
* **Tickets**: import a ServiceNow export (CSV/Excel/paste) to include other incidents and RITMs.
* **Close incidents**: tick open incidents, fill one template (state, resolution code, close notes with
  {number}/{short_description}/{date}), save templates by name, close them all. Dry run first.

## Production (WSGI)
`wsgi.py` exposes `application`. Always ONE worker (the data is held in memory):
```
waitress-serve --listen=127.0.0.1:5000 wsgi:application          # Windows or Linux
gunicorn -w 1 --threads 4 -b 127.0.0.1:5000 wsgi:application      # Linux only
```
Put HTTPS (IIS / nginx / Caddy) in front and set SESSION_COOKIE_SECURE=true.

## Safe by default
* Dry run until an admin goes live. Payloads are rebuilt on the server from saved rows.
* Rows are claimed before the API call, so a double click or second tab can't create twin incidents or close twice.
* A 200/201 reply with no recognisable incident number is stored as `CHECK:...` and never retried automatically.
* Fetching is read-only on the MyWizard side, so it works in dry run too.

## Where the data lives
No database. Everything is in `data/Abend_Portal_Data.xlsx` (sheets Abends, Incidents, Tickets, Close Templates, Root
Causes, Applications, Settings, Users, Batches, Staging), rewritten after every change. Back it up by copying it. Don't
edit it by hand while the portal is running (the portal holds a copy in memory and would overwrite your edit). If Excel
has it open, the portal shows a red banner and saves on the next change once you close it.

## Tests
`python tests/test_smoke.py`, `test_split.py`, `test_script_incidents.py`, `test_security.py` (each uses a fake
MyWizard server and a temporary workbook).
