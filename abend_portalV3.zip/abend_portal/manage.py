#!/usr/bin/env python3
"""Command line helpers.

  python manage.py init              create the data workbook, load Config + your existing history
  python manage.py hash-password     print a PORTAL_PASSWORD_HASH for .env
  python manage.py import-excel F    import a workbook as history (no incidents queued)
  python manage.py stats             row counts
"""
import argparse
import getpass
import sqlite3
import sys
from pathlib import Path

from openpyxl import load_workbook
from werkzeug.security import generate_password_hash

from portal import db, excel_io, intake
from portal.rules import Rules, norm, seed_config
from portal.settings import BASE_DIR, build_config

SEED_DIR = BASE_DIR / "seed_data"
GRID_XLSX = SEED_DIR / "Grid_Issues_Analsys_V3_Final.xlsx"
MASTER_XLSX = SEED_DIR / "Master_Abend_Tracker_v9_1.xlsx"


def connect() -> sqlite3.Connection:
    """Open (or create) the data workbook; returns the in-memory working connection."""
    cfg = build_config()
    store = db.init_store(cfg["DATABASE"])
    seed_config(store.conn)
    return store.conn


def save() -> None:
    if not db.STORE.save():
        sys.exit(db.STORE.save_error)


def import_history(conn, path: Path, sheet=None, source_note="") -> int:
    """Run a workbook through the normal intake pipeline, auto-accepting every valid row."""
    text, used, n = excel_io.workbook_to_text(str(path), sheet)
    if not n:
        print(f"  {path.name}: no data rows on sheet '{used}'")
        return 0
    # most common date on the sheet is the fallback for any blank date
    dates = [l.split("\t")[4] for l in text.splitlines() if len(l.split("\t")) > 4 and l.split("\t")[4]]
    default = max(set(dates), key=dates.count) if dates else ""
    rules = Rules(conn)
    bid = intake.create_batch(conn, rules, text, default, historical=True, source=f"excel:{used}",
                              force_include=True)
    rules = Rules(conn)
    res = intake.commit(conn, rules, bid)
    print(f"  {path.name} / '{used}': {n} lines read, {res['committed']} logged, {res['blocked']} blocked"
          + (f", new apps added: {', '.join(res['new_apps'])}" if res.get("new_apps") else ""))
    if res["blocked"]:
        for r in intake.batch_rows(conn, bid):
            if r["status"] == "error":
                print("     blocked line", r["line_no"], "-", "; ".join(i["msg"] for i in r["errors"]))
    return res["committed"]


def apply_summary_incidents(conn, path: Path) -> None:
    """Master_Abend_Tracker's 'Incident Summary' sheet has the INC numbers for the 20 tracker rows.
    The tracker's own Incident# column is empty, so match rows to groups by app + root cause + action."""
    wb = load_workbook(str(path), data_only=True)
    if "Incident Summary" not in wb.sheetnames:
        return
    rules = Rules(conn)
    total = 0
    for row in wb["Incident Summary"].iter_rows(min_row=3, values_only=True):
        apps, count, rcs, action, inc = (list(row) + [None] * 5)[:5]
        if not apps or not inc or not str(inc).upper().startswith("INC"):
            continue
        app_set = {norm(a) for a in str(apps).split(",")}
        rc_set = {norm(rules.canonical_root_cause(x)[0]) for x in str(rcs).split("/")}
        hits = []
        for r in conn.execute("SELECT id, app, root_cause, action FROM abends WHERE source='excel:Abend Tracker' "
                              "AND COALESCE(incident_no,'')=''"):
            if norm(r["app"]) in app_set and norm(r["root_cause"]) in rc_set and norm(r["action"]) == norm(action):
                hits.append(r["id"])
        if hits:
            marks = ",".join("?" * len(hits))
            conn.execute(f"UPDATE abends SET incident_no=?, incident_status='created' WHERE id IN ({marks})",
                         [str(inc)] + hits)
            total += len(hits)
        flag = "" if len(hits) == count else f"   <-- sheet says {count}"
        print(f"  {inc}: matched {len(hits)} tracker rows{flag}")
    conn.commit()
    print(f"  {total} tracker rows carry their incident number from the summary sheet.")


def cmd_init(args):
    conn = connect()
    have = conn.execute("SELECT COUNT(*) FROM abends").fetchone()[0]
    print("Data workbook:", build_config()["DATABASE"])
    if have:
        print(f"Already holds {have} abend rows - skipping the history import.")
        save()
        return
    if args.no_history:
        save()
        return
    print("Importing your existing history (marked as backfill, so no incidents are queued):")
    if GRID_XLSX.exists():
        import_history(conn, GRID_XLSX, "Abends_data")
    if MASTER_XLSX.exists():
        import_history(conn, MASTER_XLSX, "Abend Tracker")
        apply_summary_incidents(conn, MASTER_XLSX)
    save()
    cmd_stats(args)
    print("\nNext: copy .env.example to .env, set PORTAL_PASSWORD, then run:  python run.py")


def cmd_hash(_args):
    pw = getpass.getpass("New portal password: ")
    if pw != getpass.getpass("Repeat it: "):
        sys.exit("Passwords differ.")
    print("\nPut this line in .env (and remove PORTAL_PASSWORD):\n")
    print("PORTAL_PASSWORD_HASH=" + generate_password_hash(pw))


def cmd_import(args):
    conn = connect()
    import_history(conn, Path(args.file), args.sheet)
    save()


def cmd_stats(_args):
    conn = connect()
    n = conn.execute("SELECT COUNT(*) FROM abends").fetchone()[0]
    lo, hi = conn.execute("SELECT MIN(date), MAX(date) FROM abends").fetchone()
    print(f"\nabends: {n}  ({lo} to {hi})")
    for r in conn.execute("SELECT incident_status s, COUNT(*) c FROM abends GROUP BY s ORDER BY c DESC"):
        print(f"  {r['s']:<11}{r['c']}")
    print("root causes in config:", conn.execute("SELECT COUNT(*) FROM root_causes").fetchone()[0],
          "| applications:", conn.execute("SELECT COUNT(*) FROM app_names").fetchone()[0])


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("init", help="create the data workbook and import history")
    p.add_argument("--no-history", action="store_true")
    p.set_defaults(fn=cmd_init)
    sub.add_parser("hash-password").set_defaults(fn=cmd_hash)
    p = sub.add_parser("import-excel")
    p.add_argument("file")
    p.add_argument("--sheet")
    p.set_defaults(fn=cmd_import)
    sub.add_parser("stats").set_defaults(fn=cmd_stats)
    args = ap.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()
