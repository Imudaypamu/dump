from pathlib import Path

from flask import Flask, g, request

from . import db
from .settings import build_config


def create_app(overrides: dict | None = None) -> Flask:
    app = Flask(__name__, instance_relative_config=False)
    app.config.update(build_config())
    if overrides:
        app.config.update(overrides)
    app.json.sort_keys = False  # keep payload key order exactly as the macro built it

    Path(app.config["DATABASE"]).parent.mkdir(parents=True, exist_ok=True)
    store = db.init_store(app.config["DATABASE"])
    from .rules import seed_config
    seed_config(store.conn)
    # one user, one workbook in memory: handle one request at a time
    @app.before_request
    def _lock():
        store.lock.acquire()
        g._locked = True

    @app.teardown_request
    def _unlock(_exc):
        if g.pop("_locked", False):
            store.lock.release()

    from .auth import ensure_users, init_auth
    created = ensure_users(store.conn, app.config)
    if created or not store.exists:
        store.save()
    init_auth(app)

    @app.after_request
    def _persist(resp):
        if request.method in ("POST", "PUT", "PATCH", "DELETE") and resp.status_code < 400:
            store.save()
        return resp

    from .routes import bp as main_bp, register_filters
    app.register_blueprint(main_bp)
    register_filters(app)
    return app
