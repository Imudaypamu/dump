"""Everything the Excel 'Dashboard' + 'Platform_Summary' sheets computed, done in Python
over the abends table.  One call -> one dict the template and charts render from."""
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta

from .rules import ACTIONS, CATEGORIES, PLATFORMS, Rules, norm

WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def _d(s):
    return datetime.strptime(s, "%Y-%m-%d").date()


def month_bounds(ym: str):
    y, m = int(ym[:4]), int(ym[5:7])
    first = date(y, m, 1)
    nxt = date(y + (m == 12), (m % 12) + 1, 1)
    return first, nxt - timedelta(days=1)


def resolve_range(filters: dict, all_dates: list):
    """Month dropdown / From / To / +-7 days, exactly as the Excel controls behaved."""
    months = sorted({d[:7] for d in all_dates})
    month = filters.get("month") or (months[-1] if months else "All Months")
    lo = filters.get("from")
    hi = filters.get("to")
    if not lo or not hi:
        if month != "All Months" and month in months:
            f, l = month_bounds(month)
        elif all_dates:
            f, l = _d(min(all_dates)), _d(max(all_dates))
        else:
            f = l = date.today()
        lo = lo or f.isoformat()
        hi = hi or l.isoformat()
    buffer = filters.get("buffer") == "Yes"
    eff_lo, eff_hi = _d(lo), _d(hi)
    if buffer:
        eff_lo -= timedelta(days=7)
        eff_hi += timedelta(days=7)
    return {"month": month, "months": months, "from": lo, "to": hi, "buffer": buffer,
            "eff_from": eff_lo.isoformat(), "eff_to": eff_hi.isoformat()}


def _ranked(counter: Counter, limit=None):
    items = sorted(counter.items(), key=lambda kv: (-kv[1], str(kv[0]).lower()))
    return items[:limit] if limit else items


def compute(conn, rules: Rules, filters: dict) -> dict:
    all_rows = [dict(r) for r in conn.execute("SELECT * FROM abends ORDER BY date, id")]
    rng = resolve_range(filters, [r["date"] for r in all_rows])

    scope = filters.get("scope") or "all"
    cat_f = filters.get("category") or ""
    app_f = filters.get("app") or ""

    rows = []
    for r in all_rows:
        if not (rng["eff_from"] <= r["date"] <= rng["eff_to"]):
            continue
        r["issue_type_dash"] = rules.dashboard_issue_type(r["root_cause"])
        if scope == "grid" and r["issue_type_dash"] != "Grid Issue":
            continue
        if cat_f and r["category"] != cat_f:
            continue
        if app_f and norm(r["app"]) != norm(app_f):
            continue
        r["weekday"] = WEEKDAYS[_d(r["date"]).weekday()]
        r["month"] = r["date"][:7]
        r["platform"] = rules.platform(r["category"], r["app"], r["task_name"])
        rows.append(r)

    total = len(rows)
    by_month = Counter(r["month"] for r in rows)
    by_day = Counter(r["weekday"] for r in rows)
    by_app = Counter(r["app"] for r in rows)
    by_cat = Counter(r["category"] for r in rows)
    by_type = Counter(r["issue_type_dash"] for r in rows)
    by_action = Counter(r["action"] for r in rows)
    by_date = Counter(r["date"] for r in rows)

    def top(counter):
        if not counter:
            return ("-", 0)
        k, v = _ranked(counter)[0]
        return (k, v)

    busiest_wd = top(by_day)
    busiest_date = top(by_date)

    # continuous daily trend
    trend = []
    trend_unit = "day"
    if rows:
        lo, hi = _d(min(by_date)), _d(max(by_date))
        n = (hi - lo).days
        if n <= 400:
            for i in range(n + 1):
                d = (lo + timedelta(days=i)).isoformat()
                trend.append({"label": d, "value": by_date.get(d, 0)})
        else:  # too long for a daily axis -> weekly buckets
            trend_unit = "week"
            wk = Counter()
            for d, c in by_date.items():
                dd = _d(d)
                wk[(dd - timedelta(days=dd.weekday())).isoformat()] += c
            trend = [{"label": k, "value": v} for k, v in sorted(wk.items())]

    # top tasks per category (Dashboard 'Top 50 tasks')
    top_tasks = {}
    for cat in ("BDM", "CLOUD", "PWC"):
        c = Counter()
        meta = {}
        for r in rows:
            if r["category"] == cat:
                k = norm(r["task_name"])
                c[k] += 1
                meta.setdefault(k, (r["task_name"], r["process"], r["app"]))
        top_tasks[cat] = [{"task": meta[k][0], "process": meta[k][1], "app": meta[k][2], "count": v}
                          for k, v in _ranked(c, 50)]

    # repeat offenders across all categories
    rep = Counter()
    rep_meta = {}
    rep_dates = defaultdict(set)
    for r in rows:
        k = norm(r["task_name"])
        rep[k] += 1
        rep_meta.setdefault(k, r)
        rep_dates[k].add(r["date"])
    repeat = [{"task": rep_meta[k]["task_name"], "app": rep_meta[k]["app"], "category": rep_meta[k]["category"],
               "count": v, "days": len(rep_dates[k])} for k, v in _ranked(rep, 10) if v > 1]

    # category summary: one row per category, with the platform split shown underneath (derived, nothing to configure)
    notes = {name: stack for name, stack, _ in PLATFORMS}
    cat_total = sum(by_cat.values())
    cat_summary = []
    for cat in CATEGORIES:
        crow = [r for r in rows if r["category"] == cat]
        months = Counter(r["month"] for r in crow)
        plats = Counter(r["platform"] for r in crow)
        parts = []
        if any(p.lower() != cat.lower() for p in plats):
            parts = [{"platform": p, "stack": notes.get(p, ""), "count": c} for p, c in _ranked(plats)]
        cat_summary.append({
            "category": cat, "count": len(crow), "pct": (len(crow) / cat_total * 100) if cat_total else 0,
            "peak": _ranked(months)[0][0] if months else "-",
            "apps": ", ".join(sorted({r["app"] for r in crow}, key=str.lower)), "parts": parts})

    inc = Counter(r["incident_status"] for r in rows)
    grid_n = by_type.get("Grid Issue", 0)

    return {
        "range": rng,
        "filters": {"scope": scope, "category": cat_f, "app": app_f},
        "kpis": {
            "total": total,
            "unique_apps": len(by_app),
            "top_issue": top(by_type), "top_category": top(by_cat),
            "busiest_weekday": busiest_wd, "busiest_date": busiest_date,
            "grid_pct": (grid_n / total * 100) if total else 0,
            "rerun": by_action.get("Rerun", 0),
            "set_normal": by_action.get("Set to normal", 0),
        },
        "incident_status": {k: inc.get(k, 0) for k in ("pending", "created", "check", "failed", "historical")},
        "by_month": [{"label": k, "value": by_month[k]} for k in sorted(by_month)],
        "by_day": [{"label": d, "value": by_day.get(d, 0)} for d in WEEKDAYS],
        "by_app": [{"label": k, "value": v} for k, v in _ranked(by_app)],
        "by_category": [{"label": k, "value": v} for k, v in _ranked(by_cat)],
        "by_type": [{"label": k, "value": v} for k, v in _ranked(by_type)],
        "by_action": [{"label": a, "value": by_action.get(a, 0)} for a in ACTIONS if by_action.get(a, 0)],
        "trend": trend,
        "trend_unit": trend_unit,
        "top_tasks": top_tasks,
        "repeat": repeat,
        "cat_summary": cat_summary,
        "apps_all": sorted({r["app"] for r in all_rows}, key=str.lower),
    }
