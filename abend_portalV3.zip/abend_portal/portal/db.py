import os
import sqlite3
import threading
from datetime import date, datetime

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

SCHEMA = """
CREATE TABLE IF NOT EXISTS batches(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'paste',
  raw_text TEXT NOT NULL,
  default_date TEXT,
  historical INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'staged',      -- staged | partial | committed | discarded
  row_count INTEGER NOT NULL DEFAULT 0,
  committed_count INTEGER NOT NULL DEFAULT 0,
  committed_at TEXT
);

CREATE TABLE IF NOT EXISTS staging(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  batch_id INTEGER NOT NULL REFERENCES batches(id) ON DELETE CASCADE,
  line_no INTEGER,
  raw_line TEXT,
  include INTEGER NOT NULL DEFAULT 1,
  committed INTEGER NOT NULL DEFAULT 0,
  app TEXT, task_text TEXT, task_name TEXT, process TEXT, run_id TEXT,
  alert INTEGER NOT NULL DEFAULT 0,
  root_cause TEXT, action TEXT, date TEXT, category TEXT,
  comments TEXT, assigned_to TEXT,
  issues TEXT NOT NULL DEFAULT '[]',
  dup TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_staging_batch ON staging(batch_id);

CREATE TABLE IF NOT EXISTS abends(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  batch_id INTEGER,
  line_no INTEGER,
  app TEXT NOT NULL,
  task_text TEXT NOT NULL,
  task_name TEXT, process TEXT, run_id TEXT,
  alert INTEGER NOT NULL DEFAULT 0,
  root_cause TEXT, action TEXT,
  date TEXT NOT NULL,
  category TEXT NOT NULL,
  comments TEXT, assigned_to TEXT,
  incident_no TEXT,
  incident_status TEXT NOT NULL DEFAULT 'pending',  -- pending | creating | created | check | failed | historical
  incident_error TEXT,
  incident_id INTEGER,
  source TEXT NOT NULL DEFAULT 'paste',
  created_at TEXT NOT NULL,
  updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_abends_date ON abends(date);
CREATE INDEX IF NOT EXISTS idx_abends_status ON abends(incident_status);

CREATE TABLE IF NOT EXISTS incidents(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT NOT NULL,
  mode TEXT,
  group_key TEXT,
  incident_no TEXT,
  status TEXT,
  abend_ids TEXT,
  payload TEXT,
  http_status INTEGER,
  response TEXT,
  error TEXT
);

CREATE TABLE IF NOT EXISTS root_causes(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  root_cause TEXT NOT NULL UNIQUE COLLATE NOCASE,
  issue_type TEXT NOT NULL,
  resolution_summary TEXT NOT NULL DEFAULT '',
  aliases TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS app_names(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE
);

CREATE TABLE IF NOT EXISTS tickets(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  number TEXT NOT NULL UNIQUE COLLATE NOCASE,
  kind TEXT NOT NULL,                              -- INC | RITM | OTHER
  short_description TEXT,
  state TEXT NOT NULL DEFAULT 'open',              -- open | closing | closed
  state_text TEXT,
  opened_at TEXT, closed_at TEXT,
  assignment_group TEXT, assigned_to TEXT, priority TEXT,
  resolution_code TEXT, close_notes TEXT,
  source TEXT, last_error TEXT, updated_at TEXT,
  description TEXT,
  task_text TEXT, task_name TEXT, process TEXT, run_id TEXT,
  app TEXT, category TEXT, root_cause TEXT,
  abend_date TEXT,                                 -- the day the failure happened (defaults to the opened date)
  abend_id INTEGER                                 -- tracker row this incident is linked to, if any
);

CREATE TABLE IF NOT EXISTS close_templates(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE,
  resolution_code TEXT, state TEXT, close_notes TEXT
);

CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'operator',          -- admin | operator
  created_at TEXT
);

CREATE TABLE IF NOT EXISTS settings(
  key TEXT PRIMARY KEY,
  value TEXT
);
"""



# Sheets in the data workbook <-> internal tables.  "Abends" comes first on purpose: it is the
# sheet you will actually want to open in Excel.
SAVE_ORDER = [("Abends", "abends"), ("Incidents", "incidents"), ("Tickets", "tickets"),
              ("Close Templates", "close_templates"), ("Root Causes", "root_causes"),
              ("Applications", "app_names"), ("Settings", "settings"), ("Users", "users"), ("Batches", "batches"),
              ("Staging", "staging")]
LOAD_ORDER = [("Settings", "settings"), ("Users", "users"), ("Root Causes", "root_causes"), ("Applications", "app_names"),
              ("Batches", "batches"), ("Staging", "staging"), ("Abends", "abends"), ("Incidents", "incidents"),
              ("Tickets", "tickets"), ("Close Templates", "close_templates")]
CELL_LIMIT = 32000
HEADER_FILL = PatternFill("solid", fgColor="1F3864")


def now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _from_cell(v):
    if isinstance(v, datetime):
        return v.strftime("%Y-%m-%d") if (v.hour, v.minute, v.second) == (0, 0, 0) else v.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, float) and v.is_integer():
        return int(v)
    return v


class Store:
    """All data lives in one Excel workbook.  No database server and no database file: the
    workbook is read into memory at start-up and rewritten (atomically) after every change."""

    def __init__(self, path: str):
        self.path = path
        self.lock = threading.RLock()
        self.save_error = None
        self.load_notes = []
        self.conn = sqlite3.connect(":memory:", check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys=ON")
        self.conn.executescript(SCHEMA)
        self.exists = os.path.exists(path)
        if self.exists:
            self.load()

    def _columns(self, table):
        return [r[1] for r in self.conn.execute(f"PRAGMA table_info({table})")]

    def load(self):
        try:
            wb = load_workbook(self.path, data_only=True)
        except PermissionError:
            raise RuntimeError(f"Can't read {self.path}. Close it in Excel and start the portal again.")
        for sheet, table in LOAD_ORDER:
            if sheet not in wb.sheetnames:
                continue
            rows = wb[sheet].iter_rows(values_only=True)
            header = next(rows, None) or []
            cols = self._columns(table)
            use = [(i, h) for i, h in enumerate(header) if h in cols]
            skipped = 0
            for r in rows:
                if all(v is None or v == "" for v in r):
                    continue
                # empty Excel cells are left out of the INSERT so the column's DEFAULT applies
                # (inserting NULL into a NOT NULL ... DEFAULT '' column would wrongly reject the row)
                pairs = [(h, _from_cell(r[i])) for i, h in use if i < len(r) and r[i] is not None]
                names = ",".join(h for h, _ in pairs)
                vals = [v for _, v in pairs]
                try:
                    self.conn.execute(f"INSERT INTO {table}({names}) VALUES({','.join('?' * len(pairs))})", vals)
                except sqlite3.IntegrityError:
                    skipped += 1
            if skipped:
                self.load_notes.append(f"{skipped} unusable row(s) skipped on sheet '{sheet}'")
        self.conn.commit()
        wb.close()

    def save(self) -> bool:
        """Rewrite the workbook. If Excel has it open the save is retried on the next change."""
        with self.lock:
            self.conn.commit()
            wb = Workbook()
            wb.remove(wb.active)
            for sheet, table in SAVE_ORDER:
                ws = wb.create_sheet(sheet)
                cols = self._columns(table)
                for c, name in enumerate(cols, start=1):
                    cell = ws.cell(row=1, column=c, value=name)
                    cell.fill, cell.font = HEADER_FILL, Font(name="Calibri", size=10, bold=True, color="FFFFFF")
                    ws.column_dimensions[get_column_letter(c)].width = 40 if name in ("task_text", "raw_text") else 16
                for r, row in enumerate(self.conn.execute(f"SELECT * FROM {table} ORDER BY rowid"), start=2):
                    for c, v in enumerate(tuple(row), start=1):
                        if isinstance(v, str) and len(v) > CELL_LIMIT:
                            v = v[:CELL_LIMIT]
                        ws.cell(row=r, column=c, value=v)
                ws.freeze_panes = "A2"
                ws.auto_filter.ref = f"A1:{get_column_letter(len(cols))}{max(ws.max_row, 1)}"
            tmp = self.path + ".tmp"
            try:
                os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
                wb.save(tmp)
                os.replace(tmp, self.path)
            except OSError as exc:
                self.save_error = (f"Couldn't save {os.path.basename(self.path)} ({exc.strerror or exc}). "
                                   "Close it in Excel - your changes are safe in memory and will be written on the next change.")
                try:
                    os.remove(tmp)
                except OSError:
                    pass
                return False
            self.save_error = None
            self.exists = True
            return True


STORE = None


def init_store(path: str) -> Store:
    global STORE
    STORE = Store(path)
    return STORE


def get_db() -> sqlite3.Connection:
    return STORE.conn


def persist() -> None:
    """Write to disk right now (used before a MyWizard call so a crash can't cause a twin incident)."""
    if STORE:
        STORE.save()


def init_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA)
    conn.commit()


def q(sql: str, args=()):
    return get_db().execute(sql, args).fetchall()


def q1(sql: str, args=()):
    return get_db().execute(sql, args).fetchone()


def run(sql: str, args=()):
    cur = get_db().execute(sql, args)
    get_db().commit()
    return cur
