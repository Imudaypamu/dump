"""Bulk incident creation.

Payload fields, headers, timeout and incident-number parsing are ported 1:1 from the
VBA macro (BuildJSON / CallMyWizardAPI).  Two modes:

  group  one incident per Category + Issue Type + Action  (how your Incident Summary
         sheet reads: 13 grid rows -> one INC, 2 data rows -> one INC, ...)
  row    one incident per abend row                         (what the macro literally did)
"""
import json
from collections import OrderedDict

import requests

from . import mywizard, tickets

from .db import now, persist
from .rules import CATEGORIES, Rules, norm

INC_KEYS = ["incidentId", "incident_number", "number", "sys_id"]
OPEN_STATUSES = ("pending", "failed")


# --------------------------------------------------------------------------- payloads
def _payload(rules: Rules, short, desc, rc, summary, app, action) -> "OrderedDict":
    itsm = rules.itsm()
    p = OrderedDict()
    p["short_description"] = short
    p["description"] = desc
    p["category"] = itsm["category"]
    p["subcategory"] = itsm["subcategory"]
    p["cmdb_ci"] = itsm["config_item"]
    p["assignment_group"] = itsm["assignment_group"]
    p["impact"] = itsm["impact"]
    p["urgency"] = itsm["urgency"]
    p["close_notes"] = summary
    p["resolution_code"] = rules.resolution_code
    p["application"] = app
    p["root_cause"] = rc
    p["action_taken"] = action
    return p


def _row_payload(rules, r):
    return _payload(
        rules,
        short=rules.short_description(r["category"], r["app"], r["root_cause"]),
        desc=r["task_text"], rc=r["root_cause"],
        summary=rules.resolution_summary(r["root_cause"]),
        app=r["app"], action=r["action"],
    )


def _group_payload(rules, rows):
    apps = list(OrderedDict.fromkeys(r["app"] for r in rows))
    rcs = list(OrderedDict.fromkeys(r["root_cause"] for r in rows))
    cat = rows[0]["category"]
    itype = rules.issue_type(rows[0]["root_cause"])
    rc_text = " / ".join(rcs)
    app_text = ", ".join(apps)
    short = f"{cat} | {app_text} | {rc_text}" if itype == "Grid Issue" else f"{cat} | {app_text} | {itype} | {rc_text}"
    dates = sorted({r["date"] for r in rows})
    lines = [f"{len(rows)} task(s) abended on {', '.join(dates)}:"]
    lines += [f"- {r['app']}: {r['task_text']}" for r in rows]
    if len(rcs) == 1:
        summary = rules.resolution_summary(rcs[0])
    else:
        summary = "\n".join(f"{rc}: {rules.resolution_summary(rc)}" for rc in rcs)
    return _payload(rules, short, "\n".join(lines), rc_text, summary, app_text, rows[0]["action"])


def build_items(rules: Rules, rows: list, mode: str) -> list:
    """rows: dict rows from abends. -> list of items ready to preview / send."""
    items = []
    if mode == "row":
        for r in rows:
            p = _row_payload(rules, r)
            items.append(_item(f"row:{r['id']}", mode, p["short_description"], [r], p, rules))
    else:
        groups = OrderedDict()
        for r in rows:
            key = f"{r['category']}|{rules.issue_type(r['root_cause'])}|{r['action']}"
            groups.setdefault(key, []).append(r)
        order = {c: i for i, c in enumerate(CATEGORIES)}
        for key in sorted(groups, key=lambda k: (order.get(k.split("|")[0], 9), k)):
            g = groups[key]
            p = _group_payload(rules, g)
            it = _item(key, mode, p["short_description"], g, p, rules)
            # what each task would look like as its own incident (for the "one per task" toggle)
            it["row_payloads"] = {str(r["id"]): _row_payload(rules, r) for r in g}
            items.append(it)
    return items


def _item(key, mode, label, rows, payload, rules):
    return {
        "key": key, "mode": mode, "label": label,
        "ids": [r["id"] for r in rows], "count": len(rows),
        "apps": list(OrderedDict.fromkeys(r["app"] for r in rows)),
        "category": rows[0]["category"], "action": rows[0]["action"],
        "issue_type": rules.issue_type(rows[0]["root_cause"]),
        "tasks": [{"app": r["app"], "task": r["task_name"] or r["task_text"], "date": r["date"],
                   "root_cause": r["root_cause"], "status": r["incident_status"], "error": r["incident_error"]}
                  for r in rows],
        "failed": any(r["incident_status"] == "failed" for r in rows),
        "payload": payload,
    }


# --------------------------------------------------------------------------- API
def parse_incident_no(text: str):
    """Look for incidentId / incident_number / number / sys_id (also nested), like ParseJSONValue."""
    try:
        data = json.loads(text)
    except ValueError:
        return None

    def walk(node):
        if isinstance(node, dict):
            for k in INC_KEYS:
                if k in node and node[k] not in (None, "", {}, []) and not isinstance(node[k], (dict, list)):
                    return str(node[k])
            for v in node.values():
                found = walk(v)
                if found:
                    return found
        elif isinstance(node, list):
            for v in node:
                found = walk(v)
                if found:
                    return found
        return None

    # honour key priority at every level first, then recurse
    return walk(data)


def call_api(cfg, payload) -> dict:
    t = cfg["TIMEOUT"]
    try:
        resp = requests.post(cfg["URL"], data=json.dumps(payload), headers=mywizard.headers_dict(cfg),
                             timeout=(t, t), verify=cfg["VERIFY"])
    except requests.RequestException as exc:
        return {"ok": False, "http": None, "incident_no": None, "text": "", "error": f"{type(exc).__name__}: {exc}"[:300]}
    text = resp.text or ""
    if resp.status_code in (200, 201):
        inc = parse_incident_no(text)
        return {"ok": True, "http": resp.status_code, "incident_no": inc or ("CHECK:" + text[:60]),
                "text": text[:2000], "error": None}
    return {"ok": False, "http": resp.status_code, "incident_no": None, "text": text[:2000],
            "error": f"HTTP {resp.status_code} - {text[:120]}"}


# --------------------------------------------------------------------------- queue
def fetch_rows(conn, ids):
    ids = [int(i) for i in ids]
    if not ids:
        return []
    marks = ",".join("?" * len(ids))
    return [dict(r) for r in conn.execute(f"SELECT * FROM abends WHERE id IN ({marks}) ORDER BY date, id", ids)]


def open_rows(conn, date_from="", date_to=""):
    sql = "SELECT * FROM abends WHERE incident_status IN ('pending','failed') AND COALESCE(incident_no,'')=''"
    args = []
    if date_from:
        sql += " AND date>=?"
        args.append(date_from)
    if date_to:
        sql += " AND date<=?"
        args.append(date_to)
    return [dict(r) for r in conn.execute(sql + " ORDER BY date, id", args)]


def create_incident(conn, rules: Rules, cfg, mode: str, ids: list) -> dict:
    """Build the payload server-side from DB rows (never from the browser), claim the rows so a
    double click can't create twins, call MyWizard, then record the outcome."""
    rows = fetch_rows(conn, ids)
    if not rows or len(rows) != len(set(int(i) for i in ids)):
        return {"ok": False, "error": "Some rows no longer exist."}
    items = build_items(rules, rows, mode)
    if len(items) != 1:
        return {"ok": False, "error": "These rows do not belong to one incident group."}
    item = items[0]

    if rules.dry_run:
        return {"ok": True, "dry_run": True, "payload": item["payload"], "label": item["label"], "count": item["count"]}

    missing = mywizard.missing(cfg, "create")
    if missing:
        return {"ok": False, "error": "MyWizard connection incomplete (ask an admin): " + ", ".join(missing)}

    conn.commit()
    conn.execute("BEGIN IMMEDIATE")
    marks = ",".join("?" * len(item["ids"]))
    eligible = conn.execute(
        f"SELECT COUNT(*) FROM abends WHERE id IN ({marks}) AND incident_status IN ('pending','failed') "
        "AND COALESCE(incident_no,'')=''", item["ids"]).fetchone()[0]
    if eligible != len(item["ids"]):
        conn.rollback()
        return {"ok": False, "error": "Already created or in progress - refresh the page."}
    conn.execute(f"UPDATE abends SET incident_status='creating', incident_error=NULL, updated_at=? WHERE id IN ({marks})",
                 [now()] + item["ids"])
    cur = conn.execute(
        "INSERT INTO incidents(created_at, mode, group_key, status, abend_ids, payload) VALUES(?,?,?,?,?,?)",
        (now(), mode, item["key"], "sending", json.dumps(item["ids"]), json.dumps(item["payload"])))
    inc_row = cur.lastrowid
    conn.commit()
    persist()  # the claim is on disk before the API call

    res = call_api(cfg, item["payload"])

    if res["ok"]:
        status = "check" if res["incident_no"].startswith("CHECK:") else "created"
        conn.execute(
            f"UPDATE abends SET incident_no=?, incident_status=?, incident_id=?, incident_error=NULL, updated_at=? "
            f"WHERE id IN ({marks})", [res["incident_no"], status, inc_row, now()] + item["ids"])
        conn.execute("UPDATE incidents SET incident_no=?, status=?, http_status=?, response=? WHERE id=?",
                     (res["incident_no"], status, res["http"], res["text"], inc_row))
        tickets.record_created(conn, res["incident_no"], item["payload"]["short_description"],
                               item["payload"]["assignment_group"])
    else:
        conn.execute(
            f"UPDATE abends SET incident_status='failed', incident_error=?, updated_at=? WHERE id IN ({marks})",
            [res["error"], now()] + item["ids"])
        conn.execute("UPDATE incidents SET status='failed', http_status=?, response=?, error=? WHERE id=?",
                     (res["http"], res["text"], res["error"], inc_row))
    conn.commit()
    return {"ok": res["ok"], "incident_no": res.get("incident_no"), "error": res.get("error"),
            "label": item["label"], "count": item["count"]}


def reset_rows(conn, ids) -> int:
    """Put stuck/failed/check rows back to pending (user has verified in MyWizard)."""
    ids = [int(i) for i in ids]
    if not ids:
        return 0
    marks = ",".join("?" * len(ids))
    cur = conn.execute(
        f"UPDATE abends SET incident_status='pending', incident_no=NULL, incident_error=NULL, incident_id=NULL, "
        f"updated_at=? WHERE id IN ({marks}) AND incident_status IN ('creating','failed','check')", [now()] + ids)
    conn.commit()
    return cur.rowcount
