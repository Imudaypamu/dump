"""MyWizard connection settings, kept inside the portal (Settings sheet), not in .env.

The request is a plain curl-style call:  curl -s -X POST <url> -H "Name: value" ...
so the headers are a free list of name/value rows that an admin edits in the portal.
Header values flagged "secret" (X-WL-AUTH, Authorization, ...) are encrypted at rest with a key derived
from instance/secret.key, and are never shown again after saving.
"""
import base64
import hashlib
import json
import re

from cryptography.fernet import Fernet, InvalidToken

DEFAULT_HEADERS = [
    {"name": "Accept", "value": "application/json", "secret": False},
    {"name": "Content-Type", "value": "application/json", "secret": False},
    {"name": "X-WL-AUTH", "value": "", "secret": True},
    {"name": "Authorization", "value": "", "secret": True},
]

DEFAULTS = {
    "mw_url": "",
    "mw_headers": json.dumps(DEFAULT_HEADERS),
    "mw_timeout": "30",
    "mw_verify": "true",
    "mw_close_url": "",
    "mw_close_method": "POST",
    "mw_fetch_url": "",
    "mw_fetch_method": "POST",
    # a GUESS at the request body - the {placeholders} are filled from the two filter values below
    "mw_fetch_body": '{"cmdb_ci": "{config_item}", "assignment_group": "{assignment_group}"}',
    "mw_fetch_ci": "Informatica",
    "mw_fetch_group": "ETL Support",
}


# ----------------------------------------------------------------------------- encryption
def _fernet(secret_key: str) -> Fernet:
    digest = hashlib.sha256(("mywizard-headers:" + secret_key).encode()).digest()
    return Fernet(base64.urlsafe_b64encode(digest))


def encrypt(secret_key: str, plain: str) -> str:
    return "enc:" + _fernet(secret_key).encrypt(plain.encode()).decode()


def decrypt(secret_key: str, blob: str):
    """-> plain text, or None if it can't be decrypted (secret.key was replaced)."""
    if not blob.startswith("enc:"):
        return blob
    try:
        return _fernet(secret_key).decrypt(blob[4:].encode()).decode()
    except (InvalidToken, ValueError):
        return None


# ----------------------------------------------------------------------------- load / save
def stored_headers(settings: dict) -> list:
    try:
        rows = json.loads(settings.get("mw_headers") or "[]")
    except ValueError:
        rows = []
    return [r for r in rows if isinstance(r, dict) and r.get("name")]


def load(rules, secret_key: str) -> dict:
    """Decrypted connection settings for one request. Never hand this to a template."""
    s = rules.settings
    headers, unreadable = [], []
    for h in stored_headers(s):
        value = h.get("value", "")
        if h.get("secret") and value:
            plain = decrypt(secret_key, value)
            if plain is None:
                unreadable.append(h["name"])
                plain = ""
            value = plain
        headers.append((h["name"], value, bool(h.get("secret"))))
    verify = (s.get("mw_verify") or "true").strip()
    if verify.lower() in ("true", "1", "yes", ""):
        verify = True
    elif verify.lower() in ("false", "0", "no"):
        verify = False          # otherwise: path to a corporate CA bundle
    try:
        timeout = max(1, int(s.get("mw_timeout") or 30))
    except ValueError:
        timeout = 30
    return {
        "URL": (s.get("mw_url") or "").strip(),
        "HEADERS": headers, "UNREADABLE": unreadable,
        "TIMEOUT": timeout, "VERIFY": verify,
        "CLOSE_URL": (s.get("mw_close_url") or "").strip(),
        "CLOSE_METHOD": (s.get("mw_close_method") or "POST").strip().upper(),
        "FETCH_URL": (s.get("mw_fetch_url") or "").strip(),
        "FETCH_METHOD": (s.get("mw_fetch_method") or "POST").strip().upper(),
        "FETCH_BODY": s.get("mw_fetch_body") or "{}",
        "CONFIG_ITEM": (s.get("mw_fetch_ci") or "").strip(),
        "ASSIGNMENT_GROUP": (s.get("mw_fetch_group") or "").strip(),
    }


def headers_dict(cfg: dict) -> dict:
    """The -H lines of the curl command."""
    return {name: value for name, value, _ in cfg["HEADERS"] if name and value != ""}


def missing(cfg: dict, what: str) -> list:
    """What still has to be filled in on the MyWizard page ('create' | 'close' | 'fetch')."""
    bad = []
    url_key, label = {"create": ("URL", "Create URL"), "close": ("CLOSE_URL", "Close URL"),
                      "fetch": ("FETCH_URL", "Fetch URL")}[what]
    if not cfg[url_key] or "<" in cfg[url_key]:
        bad.append(label)
    if not cfg["HEADERS"]:
        bad.append("headers")
    for name, value, secret in cfg["HEADERS"]:
        if secret and not value:
            bad.append(f"header {name}")
    return bad


def save_headers(settings: dict, secret_key: str, form) -> list:
    """Build the new header list from the admin form. A blank secret value keeps the stored one (same name)."""
    old = {h["name"].lower(): h for h in stored_headers(settings)}
    names, values, secrets = form.getlist("h_name"), form.getlist("h_value"), form.getlist("h_secret")
    out = []
    for i, raw_name in enumerate(names):
        name = re.sub(r"[^A-Za-z0-9\-_]", "", raw_name.strip())
        if not name:
            continue
        secret = str(i) in secrets
        value = values[i].strip() if i < len(values) else ""
        if secret and not value and name.lower() in old and old[name.lower()].get("secret"):
            stored = old[name.lower()]["value"]
        elif secret and value:
            stored = encrypt(secret_key, value)
        else:
            stored = value
        out.append({"name": name, "value": stored, "secret": secret})
    return out
