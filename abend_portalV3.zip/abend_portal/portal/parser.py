"""Turns the text you paste every day into structured fields.

Expected shape (tab separated, one abend per line):

  App <TAB> Task '...' abnormal in process '...' (run id)alert <TAB> Root cause <TAB> Action <TAB> Date <TAB> Category

The parser is deliberately forgiving: stray quote characters around the paste, blank
lines, a header row, columns separated by 2+ spaces instead of tabs, or lines where the
tabs were lost entirely (it then anchors on the "Task '...' abnormal in process '...'"
sentence and reads the rest from the right).
"""
import re
from datetime import date, datetime, timedelta

from .rules import ACTIONS, CATEGORIES, clean

FIELD_ORDER = ["app", "task_text", "root_cause", "action", "date", "category", "comments", "assigned_to"]

TASK_RE = re.compile(
    r"(?:Task\s+)?'(?P<task>[^']+)'\s+abnormal\s+in\s+process\s+'(?P<proc>[^']+)'(?P<tail>.*)$",
    re.I | re.S,
)
RUN_RE = re.compile(r"\((\d{3,})\)")
TRAILING_ID_RE = re.compile(r"\s*\(\d+\)\s*(?:alert)?\s*$", re.I)
DATE_TOKEN_RE = re.compile(r"\d{4}[-/.]\d{1,2}[-/.]\d{1,2}|\d{1,2}[-/]\d{1,2}[-/]\d{4}|\d{1,2}[- ][A-Za-z]{3}[- ]\d{4}")

FALLBACK_RE = re.compile(
    r"^\s*(?P<app>.*?)\s*"
    r"(?P<task>(?:Task\s+)?'[^']+'\s+abnormal\s+in\s+process\s+'[^']+'(?:\s*\(\d+\))?\s*(?:alert)?)"
    r"\s*(?P<rest>.*?)\s*$",
    re.I,
)

DATE_FORMATS = [
    "%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d", "%d-%b-%Y", "%d %b %Y", "%b %d, %Y",
    "%B %d, %Y", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S",
]


def strip_quotes(s: str) -> str:
    s = s.strip()
    if len(s) >= 2 and s[0] == '"' and s[-1] == '"':
        s = s[1:-1]
    return s.strip()


def extract_lines(text: str):
    """-> [(line_no, line)] with wrapper quotes, blank lines and header rows removed."""
    text = (text or "").replace("\ufeff", "").replace("\r\n", "\n").replace("\r", "\n").strip()
    raw_lines = text.split("\n")
    out = []
    for i, line in enumerate(raw_lines, start=1):
        l = line.rstrip()
        if i == 1 and l.startswith('"'):
            l = l[1:]
        if i == len(raw_lines) and l.endswith('"') and l.count('"') % 2 == 1:
            l = l[:-1]
        if not l.strip() or l.strip() == '"':
            continue
        low = l.strip().lower()
        if low.startswith(("application\t", "app\t", "application ")) and "root" in low:
            continue  # header row
        if low.startswith("←"):
            continue  # hint row from the Raw Abend Log sheet
        out.append((i, l))
    return out


def parse_task(text: str) -> dict:
    """Pull task name, process, run id and the trailing 'alert' flag out of the task sentence."""
    t = clean(text)
    out = {"task_name": t, "process": "", "run_id": "", "alert": 0}
    m = TASK_RE.search(t)
    if m:
        out["task_name"] = m.group("task").strip()
        out["process"] = m.group("proc").strip()
        tail = m.group("tail") or ""
    else:
        tail = t
        out["task_name"] = TRAILING_ID_RE.sub("", t).strip() or t
    r = RUN_RE.search(tail)
    if r:
        out["run_id"] = r.group(1)
    if re.search(r"\balert\s*$", tail.strip(), re.I) or re.search(r"\)\s*alert\b", tail, re.I):
        out["alert"] = 1
    return out


def parse_date(s):
    """-> (iso_date | None, note | None).  `note` is set when the reading was a guess."""
    s = clean(s)
    if not s:
        return None, None
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(s, fmt).date().isoformat(), None
        except ValueError:
            pass
    m = re.match(r"^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$", s)
    if m:
        a, b, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        try:
            if a > 12:
                return date(y, b, a).isoformat(), None
            if b > 12:
                return date(y, a, b).isoformat(), None
            return date(y, a, b).isoformat(), f"'{s}' is ambiguous - read as month/day/year"
        except ValueError:
            return None, None
    if s.isdigit() and 30000 < int(s) < 80000:  # Excel serial date
        return (date(1899, 12, 30) + timedelta(days=int(s))).isoformat(), None
    return None, None


def _fallback_split(line: str):
    m = FALLBACK_RE.match(line)
    if not m:
        return None
    rest_tokens = m.group("rest").split()
    category = date_s = action = ""
    if rest_tokens and rest_tokens[-1].upper() in CATEGORIES:
        category = rest_tokens.pop()
    if rest_tokens and DATE_TOKEN_RE.fullmatch(rest_tokens[-1]):
        date_s = rest_tokens.pop()
    rest = " ".join(rest_tokens)
    for a in sorted(ACTIONS, key=len, reverse=True):
        if rest.lower().endswith(a.lower()):
            action = rest[-len(a):]
            rest = rest[: -len(a)].strip()
            break
    return [m.group("app"), m.group("task"), rest, action, date_s, category]


def split_line(line: str):
    """-> dict of raw field values (not yet normalised)."""
    if "\t" in line:
        cols = [strip_quotes(c) for c in line.split("\t")]
    else:
        cols = [strip_quotes(c) for c in re.split(r"\s{2,}", line.strip())]
        if len(cols) < 5:
            fb = _fallback_split(line)
            if fb:
                cols = fb
    cols = (cols + [""] * len(FIELD_ORDER))[: len(FIELD_ORDER)] if len(cols) <= len(FIELD_ORDER) \
        else cols[: len(FIELD_ORDER) - 1] + ["\t".join(cols[len(FIELD_ORDER) - 1:])]
    return dict(zip(FIELD_ORDER, cols))
