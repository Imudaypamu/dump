import io
import json
import re
import sqlite3
from datetime import date

from flask import (Blueprint, Response, abort, current_app, flash, g, jsonify, redirect, render_template, request,
                   url_for)

from werkzeug.security import generate_password_hash

from . import analytics, excel_io, incidents, intake, mywizard, tickets
from .auth import MIN_PASSWORD, USERNAME_RE, admin_required
from .db import get_db, now, q, q1, run
from .rules import (ACTIONS, CATEGORIES, DEFAULT_SETTINGS, EDITABLE_SETTINGS, ISSUE_TYPE_HELP, ISSUE_TYPES, TYPE_CLASS, Rules, clean,
                    norm)

bp = Blueprint("main", __name__)


def rules() -> Rules:
    return Rules(get_db())


def mw() -> dict:
    """Decrypted MyWizard connection for this request (never passed to a template)."""
    return mywizard.load(rules(), current_app.config["SECRET_KEY"])


def register_filters(app):
    app.jinja_env.filters["pct"] = lambda v: f"{v:.0f}%"
    app.jinja_env.filters["num"] = lambda v: f"{int(v):,}"
    app.jinja_env.filters["fromjson"] = lambda v: json.loads(v) if v else {}
    app.jinja_env.globals.update(CATEGORIES=CATEGORIES, ACTIONS=ACTIONS, ISSUE_TYPES=ISSUE_TYPES,
                                 TYPE_CLASS=TYPE_CLASS)

    @app.context_processor
    def inject():
        try:
            pending = q1("SELECT COUNT(*) c FROM abends WHERE incident_status IN ('pending','failed')")["c"]
            staged = q1("SELECT COUNT(*) c FROM batches WHERE status IN ('staged','partial')")["c"]
            dry = Rules(get_db()).dry_run
        except sqlite3.Error:
            pending = staged = 0
            dry = True
        from . import db as _db
        return {"nav_pending": pending, "nav_staged": staged, "dry_run": dry,
                "is_admin": g.get("role") == "admin", "user_name": g.get("user"),
                "save_error": _db.STORE.save_error if _db.STORE else None}

    @app.errorhandler(400)
    def bad_request(e):
        if request.is_json or request.accept_mimetypes.best == "application/json":
            return jsonify(ok=False, error=getattr(e, "description", "Bad request")), 400
        return render_template("error.html", code=400, message=getattr(e, "description", "Bad request")), 400

    @app.errorhandler(404)
    def not_found(e):
        return render_template("error.html", code=404, message="That page doesn't exist."), 404


@bp.route("/")
def index():
    return redirect(url_for("main.dashboard"))


# ============================================================================ dashboard
@bp.route("/dashboard")
def dashboard():
    r = rules()
    filters = {k: request.args.get(k, "") for k in ("month", "from", "to", "buffer", "scope", "category", "app")}
    data = analytics.compute(get_db(), r, filters)
    days = request.args.get("recent", "7")
    tk = tickets.dashboard_block(get_db(), int(days) if days.isdigit() and 0 < int(days) <= 90 else 7)
    return render_template("dashboard.html", d=data, f=filters, tk=tk)


# ============================================================================ raw intake
@bp.route("/intake")
def intake_home():
    batches = q("SELECT * FROM batches WHERE status!='discarded' ORDER BY id DESC LIMIT 30")
    return render_template("intake.html", batches=batches, today=date.today().isoformat())


@bp.route("/intake/parse", methods=["POST"])
def intake_parse():
    text = request.form.get("raw_text", "")
    if not text.strip():
        flash("Paste the abend text first.", "error")
        return redirect(url_for("main.intake_home"))
    bid = intake.create_batch(get_db(), rules(), text, request.form.get("default_date", ""),
                              historical=bool(request.form.get("historical")))
    return redirect(url_for("main.batch_view", batch_id=bid))


@bp.route("/intake/upload", methods=["POST"])
def intake_upload():
    f = request.files.get("xlsx")
    if not f or not f.filename.lower().endswith((".xlsx", ".xlsm")):
        flash("Choose an .xlsx or .xlsm file.", "error")
        return redirect(url_for("main.intake_home"))
    try:
        text, sheet, n = excel_io.workbook_to_text(f.stream)
    except Exception as exc:  # corrupt / password protected workbook
        flash(f"Couldn't read that workbook: {exc}", "error")
        return redirect(url_for("main.intake_home"))
    if not n:
        flash("No data rows found. Expected columns: Application, Task, Root cause, Action, Date, Category.", "error")
        return redirect(url_for("main.intake_home"))
    bid = intake.create_batch(get_db(), rules(), text, request.form.get("default_date", ""),
                              historical=bool(request.form.get("historical")), source=f"excel:{sheet}")
    flash(f"Read {n} rows from sheet '{sheet}'.", "ok")
    return redirect(url_for("main.batch_view", batch_id=bid))


def _batch_or_404(batch_id):
    b = q1("SELECT * FROM batches WHERE id=?", (batch_id,))
    if not b:
        abort(404)
    return b


@bp.route("/intake/batch/<int:batch_id>")
def batch_view(batch_id):
    b = _batch_or_404(batch_id)
    r = rules()
    rows = intake.batch_rows(get_db(), batch_id)
    for row in rows:
        row["platform"] = r.platform(row["category"], row["app"], row["task_name"])
        row["issue_type"] = r.issue_type(row["root_cause"])
        row["type_class"] = TYPE_CLASS[row["issue_type"]]
        row["short_description"] = (r.short_description(row["category"], row["app"], row["root_cause"])
                                    if row["category"] and row["app"] and row["root_cause"] else "")
    return render_template("batch.html", b=b, rows=rows, summary=intake.summary(rows),
                           unknown_rcs=intake.unknown_root_causes(rows), apps=r.apps,
                           root_causes=[x["root_cause"] for x in r.root_causes])


@bp.route("/intake/batch/<int:batch_id>/save", methods=["POST"])
def batch_save(batch_id):
    _batch_or_404(batch_id)
    intake.apply_form(get_db(), rules(), batch_id, request.form)
    flash("Edits saved and every row re-checked.", "ok")
    return redirect(url_for("main.batch_view", batch_id=batch_id))


@bp.route("/intake/batch/<int:batch_id>/commit", methods=["POST"])
def batch_commit(batch_id):
    _batch_or_404(batch_id)
    intake.apply_form(get_db(), rules(), batch_id, request.form)
    res = intake.commit(get_db(), rules(), batch_id)
    if res.get("error"):
        flash(res["error"], "error")
        return redirect(url_for("main.intake_home"))
    msg = f"{res['committed']} row(s) logged to the tracker and dashboard."
    if res["blocked"]:
        msg += f" {res['blocked']} ticked row(s) still have errors and were left in the batch."
    flash(msg, "ok" if res["committed"] else "error")
    if request.form.get("then") == "incidents" and res["committed"]:
        return redirect(url_for("main.incidents_home"))
    return redirect(url_for("main.batch_view", batch_id=batch_id))


@bp.route("/intake/batch/<int:batch_id>/discard", methods=["POST"])
def batch_discard(batch_id):
    _batch_or_404(batch_id)
    intake.discard(get_db(), batch_id)
    flash("Batch discarded. Nothing was logged.", "ok")
    return redirect(url_for("main.intake_home"))


@bp.route("/intake/batch/<int:batch_id>/add-root-cause", methods=["POST"])
def batch_add_root_cause(batch_id):
    _batch_or_404(batch_id)
    name = clean(request.form.get("root_cause", ""))
    itype = request.form.get("issue_type", "")
    if not name or itype not in ISSUE_TYPES:
        flash("Give the root cause a name and an issue type.", "error")
    else:
        try:
            get_db().execute(
                "INSERT INTO root_causes(root_cause, issue_type, resolution_summary) VALUES(?,?,?)",
                (name, itype, request.form.get("resolution_summary", "").strip()))
            get_db().commit()
            flash(f"'{name}' added to Config Table 2 as {itype}.", "ok")
        except sqlite3.IntegrityError:
            flash(f"'{name}' already exists in Config Table 2.", "error")
    intake.revalidate(get_db(), rules(), batch_id)
    return redirect(url_for("main.batch_view", batch_id=batch_id))


# ============================================================================ tracker
@bp.route("/tracker")
def tracker():
    r = rules()
    a = request.args
    sql, args = "SELECT * FROM abends WHERE 1=1", []
    if a.get("from"):
        sql += " AND date>=?"
        args.append(a["from"])
    if a.get("to"):
        sql += " AND date<=?"
        args.append(a["to"])
    if a.get("app"):
        sql += " AND app=? COLLATE NOCASE"
        args.append(a["app"])
    if a.get("category"):
        sql += " AND category=?"
        args.append(a["category"])
    if a.get("status"):
        sql += " AND incident_status=?"
        args.append(a["status"])
    if a.get("q"):
        sql += " AND (task_text LIKE ? OR root_cause LIKE ? OR COALESCE(incident_no,'') LIKE ?)"
        args += [f"%{a['q']}%"] * 3
    rows = [r.decorate(dict(x)) for x in get_db().execute(sql + " ORDER BY date DESC, id DESC", args)]
    if a.get("type"):
        rows = [x for x in rows if x["issue_type"] == a["type"]]
    per = 100
    page = max(1, int(a.get("page", 1) or 1))
    pages = max(1, (len(rows) + per - 1) // per)
    page = min(page, pages)
    apps = [x["app"] for x in q("SELECT DISTINCT app FROM abends ORDER BY app COLLATE NOCASE")]
    qs = {k: v for k, v in a.items() if k != "page" and v}
    return render_template("tracker.html", rows=rows[(page - 1) * per: page * per], total=len(rows), page=page,
                           pages=pages, apps=apps, f=a, qs=qs, statuses=["pending", "created", "check", "failed",
                                                                         "creating", "historical"],
                           root_causes=[x["root_cause"] for x in r.root_causes])


@bp.route("/tracker/<int:row_id>/update", methods=["POST"])
def tracker_update(row_id):
    cur = q1("SELECT * FROM abends WHERE id=?", (row_id,))
    if not cur:
        abort(404)
    r = rules()
    from .intake import History, process_row
    f = request.form
    raw = {k: f.get(k, "") for k in intake.EDITABLE}
    new = process_row(raw, r, cur["date"], History(get_db()))
    errs = [i["msg"] for i in new["issues"] if i["level"] == "error"]
    if errs:
        flash("Not saved: " + " ".join(errs), "error")
        return redirect(request.referrer or url_for("main.tracker"))
    inc_no = clean(f.get("incident_no", ""))
    status = f.get("incident_status", cur["incident_status"])
    if status not in ("pending", "created", "check", "failed", "historical"):
        status = cur["incident_status"]
    if inc_no and status in ("pending", "failed"):
        status = "created"          # typing an incident number means it exists
    if not inc_no and status in ("created", "check"):
        status = "pending"          # no number -> back in the queue
    get_db().execute(
        """UPDATE abends SET app=?, task_text=?, task_name=?, process=?, run_id=?, alert=?, root_cause=?, action=?,
           date=?, category=?, comments=?, assigned_to=?, incident_no=?, incident_status=?, incident_error=NULL,
           updated_at=? WHERE id=?""",
        (new["app"], new["task_text"], new["task_name"], new["process"], new["run_id"], new["alert"],
         new["root_cause"], new["action"], new["date"], new["category"], new["comments"], f.get("assigned_to", "").strip(),
         inc_no or None, status, now(), row_id))
    get_db().commit()
    flash("Row updated.", "ok")
    return redirect(request.referrer or url_for("main.tracker"))


@bp.route("/tracker/<int:row_id>/delete", methods=["POST"])
def tracker_delete(row_id):
    cur = q1("SELECT incident_status FROM abends WHERE id=?", (row_id,))
    if not cur:
        abort(404)
    if cur["incident_status"] in ("created", "check", "creating"):
        flash("This row has an incident. Clear the incident number first if you really want to delete it.", "error")
    else:
        run("DELETE FROM abends WHERE id=?", (row_id,))
        flash("Row deleted.", "ok")
    return redirect(request.referrer or url_for("main.tracker"))


# ============================================================================ incidents
@bp.route("/incidents")
def incidents_home():
    r = rules()
    mode = "row" if request.args.get("mode") == "row" else "group"
    d_from, d_to = request.args.get("from", ""), request.args.get("to", "")
    rows = incidents.open_rows(get_db(), d_from, d_to)
    items = incidents.build_items(r, rows, mode)
    attention = [r.decorate(dict(x)) for x in q(
        "SELECT * FROM abends WHERE incident_status IN ('creating','check') ORDER BY date DESC, id DESC")]
    recent = q("SELECT * FROM incidents ORDER BY id DESC LIMIT 15")
    return render_template("incidents.html", items=items, mode=mode, n_rows=len(rows), attention=attention,
                           recent=recent, missing=mywizard.missing(mw(), "create"), d_from=d_from, d_to=d_to)


@bp.route("/incidents/create", methods=["POST"])
def incidents_create():
    data = request.get_json(silent=True) or {}
    ids = data.get("ids") or []
    mode = "row" if data.get("mode") == "row" else "group"
    if not isinstance(ids, list) or not ids or not all(isinstance(i, int) for i in ids):
        return jsonify(ok=False, error="No rows supplied."), 400
    res = incidents.create_incident(get_db(), rules(), mw(), mode, ids)
    return jsonify(res)


@bp.route("/incidents/reset", methods=["POST"])
def incidents_reset():
    ids = [int(i) for i in request.form.getlist("ids") if i.isdigit()]
    n = incidents.reset_rows(get_db(), ids)
    flash(f"{n} row(s) put back in the queue. Check MyWizard first so you don't create a twin.", "ok")
    return redirect(url_for("main.incidents_home"))


# ============================================================================ tickets
@bp.route("/tickets")
def tickets_home():
    a = request.args
    rows = tickets.list_tickets(get_db(), a.get("kind", ""), a.get("state", ""), a.get("q", ""))
    stuck = [t for t in rows if t["state"] == "closing"]
    return render_template("tickets.html", rows=rows, f=a, stuck=stuck)


def _read_ticket_upload():
    """-> (rows, error) from an uploaded CSV/Excel or a pasted export."""
    f = request.files.get("file")
    try:
        if f and f.filename:
            return tickets.read_table(f.stream, f.filename), None
        if request.form.get("paste", "").strip():
            return tickets._to_dicts(tickets._rows_from_text(request.form["paste"])), None
    except Exception as exc:
        return None, f"Couldn't read that export: {exc}"
    return None, "Choose a CSV/Excel export or paste it with its header row."


@bp.route("/tickets/import", methods=["POST"])
def tickets_import():
    table, err = _read_ticket_upload()
    if err:
        flash(err, "error")
        return redirect(url_for("main.tickets_home"))
    res = tickets.import_rows(get_db(), table, rules=rules())
    flash(f"Imported {res['total']} ticket(s): {res['added']} new, {res['updated']} updated.", "ok")
    return redirect(url_for("main.tickets_home"))


@bp.route("/tickets/reset", methods=["POST"])
def tickets_reset():
    n = tickets.reset_closing(get_db(), request.form.getlist("numbers"))
    flash(f"{n} ticket(s) put back to open. Check ServiceNow first so you don't close one twice.", "ok")
    return redirect(url_for("main.tickets_home"))


# ---- incidents raised by your scripts: Informatica / ETL Support, fetched from MyWizard
@bp.route("/script-incidents")
def script_incidents():
    r = rules()
    a = request.args
    rows = tickets.script_list(get_db(), r, a)
    kp = {"total": len(rows), "open": sum(1 for x in rows if x["state"] != "closed"),
          "closed": sum(1 for x in rows if x["state"] == "closed")}
    apps = [x["app"] for x in q("SELECT DISTINCT app FROM tickets WHERE source!='portal' AND COALESCE(app,'')!='' "
                                "ORDER BY app COLLATE NOCASE")]
    cfg = mw()
    return render_template("script_incidents.html", rows=rows[:500], total=len(rows), kp=kp, f=a, apps=apps,
                           qs={k: v for k, v in a.items() if v}, missing=mywizard.missing(cfg, "fetch"),
                           ci=cfg["CONFIG_ITEM"], group=cfg["ASSIGNMENT_GROUP"],
                           last=q1("SELECT MAX(updated_at) m FROM tickets WHERE source='script'")["m"])


@bp.route("/script-incidents/fetch", methods=["POST"])
def script_fetch():
    res = tickets.fetch_incidents(get_db(), rules(), mw())
    if not res["ok"]:
        flash("Fetch failed: " + res["error"], "error")
    else:
        msg = (f"Fetched {res['fetched']} incident(s) from MyWizard, kept {res['kept']}: "
               f"{res['added']} new, {res['updated']} updated.")
        if res["dropped"]:
            msg += f" {res['dropped']} belonged to another configuration item or team and were ignored."
        flash(msg, "ok")
    return redirect(url_for("main.script_incidents"))


@bp.route("/script-incidents/import", methods=["POST"])
def script_import():
    table, err = _read_ticket_upload()
    if err:
        flash(err, "error")
        return redirect(url_for("main.script_incidents"))
    res = tickets.import_rows(get_db(), table, source="script", rules=rules())
    flash(f"Imported {res['total']} incident(s): {res['added']} new, {res['updated']} updated.", "ok")
    return redirect(url_for("main.script_incidents"))


# ---- bulk close
@bp.route("/incidents/close")
def close_home():
    a = request.args
    rows = [t for t in tickets.list_tickets(get_db(), "INC", "open", a.get("q", ""), 2000)
            if (not a.get("mine") or t["source"] == "portal")
            and (not a.get("from") or (t["opened_at"] or "")[:10] >= a["from"])
            and (not a.get("to") or (t["opened_at"] or "")[:10] <= a["to"])]
    cfg = mw()
    return render_template("close.html", rows=rows, f=a, templates=q("SELECT * FROM close_templates ORDER BY name"),
                           missing=mywizard.missing(cfg, "close"), method=cfg["CLOSE_METHOD"],
                           close_url=cfg["CLOSE_URL"] if g.role == "admin" else "", r=rules())


@bp.route("/incidents/close/run", methods=["POST"])
def close_run():
    d = request.get_json(silent=True) or {}
    number = clean(d.get("number", "")).upper()
    if not number:
        return jsonify(ok=False, error="No incident number."), 400
    return jsonify(tickets.close_ticket(get_db(), rules(), mw(), number, d))


@bp.route("/incidents/close/template", methods=["POST"])
def close_template_save():
    name = clean(request.form.get("name", ""))
    if not name or not request.form.get("resolution_code") or not request.form.get("close_notes"):
        flash("A template needs a name, resolution code and close notes.", "error")
    else:
        get_db().execute(
            "INSERT INTO close_templates(name, resolution_code, state, close_notes) VALUES(?,?,?,?) "
            "ON CONFLICT(name) DO UPDATE SET resolution_code=excluded.resolution_code, state=excluded.state, "
            "close_notes=excluded.close_notes",
            (name, request.form["resolution_code"].strip(), request.form.get("state", "").strip(),
             request.form["close_notes"].strip()))
        get_db().commit()
        flash(f"Template '{name}' saved.", "ok")
    return redirect(url_for("main.close_home"))


@bp.route("/incidents/close/template/<int:tid>/delete", methods=["POST"])
def close_template_delete(tid):
    run("DELETE FROM close_templates WHERE id=?", (tid,))
    flash("Template deleted.", "ok")
    return redirect(url_for("main.close_home"))


# ============================================================================ config
@bp.route("/config")
def config_home():
    r = rules()
    return render_template("config.html", r=r, issue_help=ISSUE_TYPE_HELP, apps="\n".join(r.apps))


@bp.route("/config/save", methods=["POST"])
def config_save():
    f = request.form
    db = get_db()
    problems = []
    # Table 2 - existing rows
    for row in db.execute("SELECT id FROM root_causes").fetchall():
        i = row["id"]
        if f.get(f"rc_del_{i}"):
            db.execute("DELETE FROM root_causes WHERE id=?", (i,))
            continue
        name, itype = clean(f.get(f"rc_name_{i}", "")), f.get(f"rc_type_{i}", "")
        if not name or itype not in ISSUE_TYPES:
            problems.append(f"Row {i}: name and issue type are required.")
            continue
        try:
            db.execute("UPDATE root_causes SET root_cause=?, issue_type=?, aliases=?, resolution_summary=? WHERE id=?",
                       (name, itype, f.get(f"rc_alias_{i}", "").strip(), f.get(f"rc_sum_{i}", "").strip(), i))
        except sqlite3.IntegrityError:
            problems.append(f"'{name}' is listed twice.")
    # Table 2 - new rows
    for name, itype, alias, summ in zip(f.getlist("new_name"), f.getlist("new_type"), f.getlist("new_alias"),
                                        f.getlist("new_sum")):
        name = clean(name)
        if not name:
            continue
        if itype not in ISSUE_TYPES:
            problems.append(f"'{name}': pick an issue type.")
            continue
        try:
            db.execute("INSERT INTO root_causes(root_cause, issue_type, aliases, resolution_summary) VALUES(?,?,?,?)",
                       (name, itype, alias.strip(), summ.strip()))
        except sqlite3.IntegrityError:
            problems.append(f"'{name}' already exists.")
    # Table 3
    for k in EDITABLE_SETTINGS:      # an explicit allow-list: nothing about the MyWizard connection can be set here
        if k in f:
            db.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                       (k, f.get(k, "").strip()))
    # apps
    if "apps" in f:
        wanted = [clean(a) for a in f.get("apps", "").splitlines() if clean(a)]
        db.execute("DELETE FROM app_names")
        for a in wanted:
            db.execute("INSERT OR IGNORE INTO app_names(name) VALUES(?)", (a,))
    db.commit()
    for p in problems:
        flash(p, "error")
    if not problems:
        flash("Configuration saved. Every tracker row picked up the change.", "ok")
    return redirect(url_for("main.config_home"))


# ============================================================================ admin (MyWizard connection + users)
def _setting_upsert(key, value):
    get_db().execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                     (key, value))


@bp.route("/admin/mywizard")
@admin_required
def admin_mywizard():
    r = rules()
    cfg = mw()
    rows = [{"name": h["name"], "secret": bool(h.get("secret")),
             "value": "" if h.get("secret") else h.get("value", ""), "is_set": bool(h.get("value"))}
            for h in mywizard.stored_headers(r.settings)]
    return render_template("admin_mywizard.html", s=r.settings, headers=rows, unreadable=cfg["UNREADABLE"],
                           miss_create=mywizard.missing(cfg, "create"), miss_close=mywizard.missing(cfg, "close"),
                           miss_fetch=mywizard.missing(cfg, "fetch"))


@bp.route("/admin/mywizard/save", methods=["POST"])
@admin_required
def admin_mywizard_save():
    f = request.form
    r = rules()
    problems = []
    for key, label in (("mw_url", "Create URL"), ("mw_close_url", "Close URL"), ("mw_fetch_url", "Fetch URL")):
        v = f.get(key, "").strip()
        if v and not re.match(r"^https?://", v):
            problems.append(f"{label} must start with http:// or https://")
    if f.get("mw_fetch_body", "").strip():
        try:
            if not isinstance(json.loads(f["mw_fetch_body"]), dict):
                problems.append("Fetch body must be a JSON object.")
        except ValueError as exc:
            problems.append(f"Fetch body is not valid JSON: {exc}")
    bad = tickets.validate_template(f.get("close_payload", "{}"))
    if bad:
        problems.append(bad)
    try:
        timeout = int(f.get("mw_timeout", "30"))
        if not 1 <= timeout <= 300:
            raise ValueError
    except ValueError:
        problems.append("Timeout must be a number of seconds between 1 and 300.")
        timeout = 30
    if problems:
        for p_ in problems:
            flash(p_, "error")
        return redirect(url_for("main.admin_mywizard"))

    headers = mywizard.save_headers(r.settings, current_app.config["SECRET_KEY"], f)
    values = {
        "mw_url": f.get("mw_url", "").strip(), "mw_headers": json.dumps(headers), "mw_timeout": str(timeout),
        "mw_verify": f.get("mw_verify", "true").strip() or "true",
        "mw_close_url": f.get("mw_close_url", "").strip(),
        "mw_close_method": f.get("mw_close_method", "POST") if f.get("mw_close_method") in ("POST", "PUT", "PATCH", "DELETE") else "POST",
        "mw_fetch_url": f.get("mw_fetch_url", "").strip(),
        "mw_fetch_method": "GET" if f.get("mw_fetch_method") == "GET" else "POST",
        "mw_fetch_body": f.get("mw_fetch_body", "").strip() or "{}",
        "mw_fetch_ci": f.get("mw_fetch_ci", "").strip(), "mw_fetch_group": f.get("mw_fetch_group", "").strip(),
        "close_payload": f.get("close_payload", "{}").strip(),
    }
    for k, v in values.items():
        _setting_upsert(k, v)
    get_db().commit()
    flash("MyWizard connection saved. Secret header values are stored encrypted and won't be shown again.", "ok")
    return redirect(url_for("main.admin_mywizard"))


@bp.route("/admin/mywizard/mode", methods=["POST"])
@admin_required
def admin_mywizard_mode():
    want_live = request.form.get("mode") == "live"
    if want_live:
        missing = mywizard.missing(mw(), "create")
        if missing:
            flash("Can't go live - still missing: " + ", ".join(missing), "error")
            return redirect(url_for("main.admin_mywizard"))
        if not request.form.get("confirm"):
            flash("Tick the confirmation box to go live.", "error")
            return redirect(url_for("main.admin_mywizard"))
    run("INSERT INTO settings(key,value) VALUES('dry_run',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        ("0" if want_live else "1",))
    flash("Live mode ON - incidents will be created in MyWizard." if want_live
          else "Dry run ON - nothing is sent to MyWizard.", "ok")
    return redirect(url_for("main.admin_mywizard"))


@bp.route("/admin/users")
@admin_required
def admin_users():
    return render_template("admin_users.html", users=q("SELECT id, username, role, created_at FROM users ORDER BY id"),
                           min_pw=MIN_PASSWORD)


def _admin_count():
    return q1("SELECT COUNT(*) c FROM users WHERE role='admin'")["c"]


@bp.route("/admin/users/add", methods=["POST"])
@admin_required
def admin_users_add():
    name, pw = request.form.get("username", "").strip(), request.form.get("password", "")
    role = "admin" if request.form.get("role") == "admin" else "operator"
    if not USERNAME_RE.match(name):
        flash("Username: 3-40 letters, digits, dot, dash or underscore.", "error")
    elif len(pw) < MIN_PASSWORD:
        flash(f"Use at least {MIN_PASSWORD} characters for the password.", "error")
    elif q1("SELECT 1 FROM users WHERE username=?", (name,)):
        flash("That username already exists.", "error")
    else:
        run("INSERT INTO users(username, password_hash, role, created_at) VALUES(?,?,?,?)",
            (name, generate_password_hash(pw), role, now()))
        flash(f"User '{name}' created as {role}.", "ok")
    return redirect(url_for("main.admin_users"))


@bp.route("/admin/users/<int:uid>/password", methods=["POST"])
@admin_required
def admin_users_password(uid):
    pw = request.form.get("password", "")
    if len(pw) < MIN_PASSWORD:
        flash(f"Use at least {MIN_PASSWORD} characters.", "error")
    elif not q1("SELECT 1 FROM users WHERE id=?", (uid,)):
        abort(404)
    else:
        run("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(pw), uid))
        flash("Password reset.", "ok")
    return redirect(url_for("main.admin_users"))


@bp.route("/admin/users/<int:uid>/delete", methods=["POST"])
@admin_required
def admin_users_delete(uid):
    u = q1("SELECT * FROM users WHERE id=?", (uid,))
    if not u:
        abort(404)
    if u["username"] == g.user:
        flash("You can't delete the account you're signed in with.", "error")
    elif u["role"] == "admin" and _admin_count() <= 1:
        flash("There must always be at least one admin.", "error")
    else:
        run("DELETE FROM users WHERE id=?", (uid,))
        flash(f"User '{u['username']}' deleted.", "ok")
    return redirect(url_for("main.admin_users"))


# ============================================================================ exports
def _xlsx_response(wb, name):
    buf = io.BytesIO()
    wb.save(buf)
    return Response(buf.getvalue(), mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="{name}"'})


def _export_rows():
    a = request.args
    sql, args = "SELECT * FROM abends WHERE 1=1", []
    if a.get("from"):
        sql += " AND date>=?"
        args.append(a["from"])
    if a.get("to"):
        sql += " AND date<=?"
        args.append(a["to"])
    return [dict(x) for x in get_db().execute(sql + " ORDER BY date, id", args)]


@bp.route("/export/tracker.xlsx")
def export_tracker():
    return _xlsx_response(excel_io.tracker_workbook(rules(), _export_rows()), f"Abend_Tracker_{date.today()}.xlsx")


@bp.route("/export/script_incidents.xlsx")
def export_script_incidents():
    rows = tickets.script_list(get_db(), rules(), request.args)
    return _xlsx_response(excel_io.script_incidents_workbook(rows), f"Script_Incidents_{date.today()}.xlsx")


@bp.route("/export/abends_data.xlsx")
def export_abends_data():
    return _xlsx_response(excel_io.abends_data_workbook(rules(), _export_rows()), f"Abends_data_{date.today()}.xlsx")
