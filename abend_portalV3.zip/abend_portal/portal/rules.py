"""Business rules lifted from the two workbooks.

Master_Abend_Tracker  -> Config Tables (Tables 1-3) + the Abend Tracker formulas
Grid_Issues_Analsys   -> IssueType / Platform logic used by the Dashboard

Everything that was an Excel formula is a plain function here, evaluated when a row
is read, so editing the Config page updates every row instantly (just like editing
Config Tables did in the workbook).
"""
import json
import re
import sqlite3

from .mywizard import DEFAULTS as MYWIZARD_DEFAULTS

CATEGORIES = ["BDM", "PWC", "CLOUD"]
ACTIONS = ["Rerun", "Set to normal", "Yet to take"]
ISSUE_TYPES = ["Grid Issue", "Data Issue", "Network Issue", "Other Issue"]

ISSUE_TYPE_HELP = {
    "Grid Issue": "Root cause is grid/infrastructure in Informatica. Action = Rerun. "
                  "Short description: Cat | App | Root cause.",
    "Data Issue": "Root cause is data quality: foreign key, UI violation, transformation, "
                  "null constraint, out of range. Action = Set to normal.",
    "Network Issue": "Root cause is network or connectivity. Add the root causes to Table 2. Action = Rerun.",
    "Other Issue": "Root cause does not fit the other three, e.g. lookup cache. Action = Rerun.",
}

# Row colours used by the macro's ColorRow / Incident Summary sheet
TYPE_CLASS = {
    "Grid Issue": "t-grid",
    "Data Issue": "t-data",
    "Network Issue": "t-net",
    "Other Issue": "t-other",
}

DEFAULT_SETTINGS = {
    "itsm_category": "Scheduled Job/Batch Processing",
    "itsm_subcategory": "Abend",
    "itsm_config_item": "Informatica",
    "itsm_assignment_group": "ETL Support HNA",
    "itsm_impact": "3 - Low",
    "itsm_urgency": "3 - Low",
    "resolution_code": "Service Restored By - Workaround",
    "default_assigned_to": "",
    "dry_run": "1",
    # Body sent when closing an incident. {placeholders} are filled per ticket. This is a GUESS at your
    # MyWizard close contract - adjust the field names on the Config page before going live.
    # Body sent when closing an incident. {placeholders} are filled per ticket. This is a GUESS at your
    # MyWizard close contract - adjust the field names on the MyWizard page before going live.
    "close_payload": '{"number": "{number}", "state": "{state}", "close_code": "{resolution_code}", '
                     '"close_notes": "{close_notes}"}',
}

DEFAULT_SETTINGS.update(MYWIZARD_DEFAULTS)

# the only settings the Config page may write (operators can open Config; the MyWizard connection is admin-only)
EDITABLE_SETTINGS = ["itsm_category", "itsm_subcategory", "itsm_config_item", "itsm_assignment_group", "itsm_impact",
                     "itsm_urgency", "resolution_code", "default_assigned_to"]

FALLBACK_RESOLUTION = "Investigated and resolved. Please refer to incident for details."

SEED_ROOT_CAUSES = [
    ("Foreign key issue", "Data Issue",
     "Job/task abended due to a Foreign Key constraint violation in the source/target data. "
     "Task set to normal after analysis. Data team notified to fix the referential integrity issue.", ""),
    ("Ui Violation", "Data Issue",
     "Job/task abended due to a UI Violation error in the data pipeline. Task set to normal after "
     "root cause analysis. Data team engaged for permanent fix.", ""),
    ("Transformation issue", "Data Issue",
     "Job/task abended due to a Transformation error in the Informatica mapping. Task set to normal "
     "after investigation. Mapping team notified for code review.", ""),
    ("Null Constraint", "Data Issue",
     "Job/task abended due to a Null Constraint violation. Task set to normal. "
     "Data team notified to fix upstream data.", ""),
    ("Out of range Issue", "Data Issue",
     "Job/task abended due to an Out of Range data error. Task set to normal after root cause "
     "analysis. Data team notified.", ""),
    ("Grid issue", "Grid Issue",
     "Job/task abended due to Informatica grid availability issue. Task rerun successfully after "
     "grid stabilised. No data impact observed.", "Gid issue"),
    ("Lookup cache issue", "Other Issue",
     "Job/task abended due to a Lookup Cache issue in the Informatica session. Task rerun "
     "successfully after cache refreshed.", ""),
    ("Memory issue", "Other Issue",
     "Job/task abended due to insufficient memory on the Informatica server. Task rerun "
     "successfully after memory freed.", ""),
]

SEED_APPS = [
    "VCD", "SEI", "eQuote", "WBI", "CDK", "HVD", "ALERT APP", "SPS", "FQR", "PPAT",
    "SVPG", "CRMS", "Publications", "SOCRATES", "ADW", "PEPORTAL", "SIMPL", "YMS",
]

GRID_RE = re.compile(r"grid|\bgid\b", re.I)
GLUE_APPS = {"simpl", "yms"}


def norm(s) -> str:
    """Case-insensitive, whitespace-collapsed comparison key."""
    return re.sub(r"\s+", " ", str(s or "")).strip().lower()


def clean(s) -> str:
    return re.sub(r"\s+", " ", str(s or "")).strip()


class Rules:
    """Snapshot of the Config tables for one request / one CLI run."""

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        self.settings = dict(DEFAULT_SETTINGS)
        for r in conn.execute("SELECT key, value FROM settings"):
            self.settings[r["key"]] = r["value"] if r["value"] is not None else ""

        self.root_causes = []          # list of dict rows
        self._rc_index = {}            # norm(name or alias) -> row
        for r in conn.execute("SELECT * FROM root_causes ORDER BY id"):
            row = dict(r)
            self.root_causes.append(row)
            self._rc_index[norm(row["root_cause"])] = row
            for alias in re.split(r"[,;\n]", row.get("aliases") or ""):
                if norm(alias):
                    self._rc_index.setdefault(norm(alias), row)

        self.apps = [r["name"] for r in conn.execute("SELECT name FROM app_names ORDER BY name COLLATE NOCASE")]
        self._app_index = {norm(a): a for a in self.apps}

    # ---- canonicalisation ------------------------------------------------
    def root_cause_row(self, raw):
        return self._rc_index.get(norm(raw))

    def canonical_root_cause(self, raw):
        """-> (canonical text, known_in_config)"""
        row = self.root_cause_row(raw)
        if row:
            return row["root_cause"], True
        return clean(raw), False

    def canonical_app(self, raw):
        key = norm(raw)
        if key in self._app_index:
            return self._app_index[key], True
        return clean(raw), False

    @staticmethod
    def canonical_action(raw):
        key = norm(raw)
        for a in ACTIONS:
            if norm(a) == key:
                return a, True
        return clean(raw), False

    @staticmethod
    def canonical_category(raw):
        key = clean(raw).upper()
        if key in CATEGORIES:
            return key, True
        return key, False

    # ---- Abend Tracker formulas -------------------------------------------
    def issue_type(self, root_cause) -> str:
        """VLOOKUP(RC, Config Table 2) -> Issue Type, else 'Other Issue'."""
        row = self.root_cause_row(root_cause)
        if row and row["issue_type"] in ISSUE_TYPES:
            return row["issue_type"]
        return "Other Issue"

    def short_description(self, category, app, root_cause) -> str:
        it = self.issue_type(root_cause)
        if it == "Grid Issue":
            return f"{category} | {app} | {root_cause}"
        return f"{category} | {app} | {it} | {root_cause}"

    def resolution_summary(self, root_cause) -> str:
        row = self.root_cause_row(root_cause)
        if row and row["resolution_summary"].strip():
            return row["resolution_summary"].strip()
        return FALLBACK_RESOLUTION

    def itsm(self) -> dict:
        s = self.settings
        return {
            "category": s["itsm_category"],
            "subcategory": s["itsm_subcategory"],
            "config_item": s["itsm_config_item"],
            "assignment_group": s["itsm_assignment_group"],
            "impact": s["itsm_impact"],
            "urgency": s["itsm_urgency"],
        }

    @property
    def resolution_code(self) -> str:
        return self.settings["resolution_code"]

    @property
    def dry_run(self) -> bool:
        return self.settings.get("dry_run", "1") == "1"

    def decorate(self, r: dict) -> dict:
        """Add the formula columns of the Abend Tracker sheet (H, J, L-Q) to a row dict."""
        it = self.issue_type(r["root_cause"])
        itsm = self.itsm()
        r["issue_type"] = it
        r["type_class"] = TYPE_CLASS[it]
        r["short_description"] = self.short_description(r["category"], r["app"], r["root_cause"])
        r["resolution_summary"] = self.resolution_summary(r["root_cause"])
        r["resolution_code"] = self.resolution_code
        r["impact"], r["urgency"] = itsm["impact"], itsm["urgency"]
        r["itsm_category"], r["itsm_subcategory"] = itsm["category"], itsm["subcategory"]
        r["config_item"], r["assignment_group"] = itsm["config_item"], itsm["assignment_group"]
        return r

    # ---- Dashboard formulas -------------------------------------------------
    def dashboard_issue_type(self, root_cause) -> str:
        """Grid_Issues 'IssueType' column: anything with grid/gid -> 'Grid Issue',
        otherwise the trimmed root cause (canonical casing when known)."""
        if GRID_RE.search(root_cause or ""):
            return "Grid Issue"
        canon, _ = self.canonical_root_cause(root_cause)
        return canon or "(blank)"

    @staticmethod
    def platform(category, app, task_name) -> str:
        """Platform_Summary logic."""
        cat = clean(category).upper()
        a = norm(app)
        t = (task_name or "").lower()
        if cat == "BDM":
            return "EMR Spark" if "_hive_" in t else "BDM"
        if cat == "CLOUD":
            return "Cloud"
        if cat == "PWC":
            return "Glue" if a in GLUE_APPS else "PWC"
        return "Unclassified"


PLATFORMS = [
    ("EMR Spark", "Apache Hive on AWS EMR", "Hive tasks only (task contains _HIVE_)"),
    ("BDM", "Batch Data Management", "BDM rows without Hive tasks"),
    ("Cloud", "Cloud-native pipelines", "All CLOUD category rows"),
    ("PWC", "PwC platform", "PWC rows excluding SIMPL and YMS"),
    ("Glue", "AWS Glue / SIMPL / YMS", "PWC rows where app is SIMPL or YMS"),
]


def seed_config(conn: sqlite3.Connection) -> None:
    """Idempotent: only fills what is missing."""
    for k, v in DEFAULT_SETTINGS.items():
        conn.execute("INSERT OR IGNORE INTO settings(key, value) VALUES(?, ?)", (k, v))
    if not conn.execute("SELECT 1 FROM root_causes LIMIT 1").fetchone():
        conn.executemany(
            "INSERT INTO root_causes(root_cause, issue_type, resolution_summary, aliases) VALUES(?,?,?,?)",
            SEED_ROOT_CAUSES,
        )
    for a in SEED_APPS:
        conn.execute("INSERT OR IGNORE INTO app_names(name) VALUES(?)", (a,))
    # upgrade: caller_id was removed from MyWizard requests, so drop it from an older saved close body
    row = conn.execute("SELECT value FROM settings WHERE key='close_payload'").fetchone()
    if row and "{caller}" in (row[0] or ""):
        try:
            body = json.loads(row[0])
            body.pop("caller_id", None)
            conn.execute("UPDATE settings SET value=? WHERE key='close_payload'", (json.dumps(body),))
        except ValueError:
            pass
    conn.commit()
