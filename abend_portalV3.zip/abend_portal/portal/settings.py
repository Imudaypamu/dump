"""Runtime settings.

Everything secret (portal password, MyWizard credentials) comes from environment
variables or a local `.env` file -- never from the database or the Excel files.
"""
import os
import secrets
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


def load_dotenv(path: Path) -> None:
    """Tiny .env reader: KEY=VALUE per line, '#' comments, optional quotes."""
    if not path.exists():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        key, val = key.strip(), val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in "\"'":
            val = val[1:-1]
        os.environ.setdefault(key, val)


def _flag(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


def _secret_key(instance_dir: Path) -> str:
    env = os.environ.get("SECRET_KEY")
    if env:
        return env
    instance_dir.mkdir(parents=True, exist_ok=True)
    keyfile = instance_dir / "secret.key"
    if keyfile.exists():
        return keyfile.read_text().strip()
    key = secrets.token_hex(32)
    keyfile.write_text(key)
    try:
        os.chmod(keyfile, 0o600)
    except OSError:
        pass
    return key


def build_config() -> dict:
    load_dotenv(BASE_DIR / ".env")
    return {
        "SECRET_KEY": _secret_key(BASE_DIR / "instance"),
        "DATABASE": os.environ.get("PORTAL_DATA_FILE", str(BASE_DIR / "data" / "Abend_Portal_Data.xlsx")),
        "PORTAL_USER": os.environ.get("PORTAL_USER", "admin"),
        "PORTAL_PASSWORD": os.environ.get("PORTAL_PASSWORD", ""),
        "PORTAL_PASSWORD_HASH": os.environ.get("PORTAL_PASSWORD_HASH", ""),
        "SESSION_COOKIE_HTTPONLY": True,
        "SESSION_COOKIE_SAMESITE": "Lax",
        "SESSION_COOKIE_SECURE": _flag("SESSION_COOKIE_SECURE", False),
        "PERMANENT_SESSION_LIFETIME": int(os.environ.get("SESSION_HOURS", "12")) * 3600,
        "MAX_CONTENT_LENGTH": 8 * 1024 * 1024,
        # optional: create a second (restricted) user on the very first start. Users are managed in the portal afterwards.
        "PORTAL_OPERATOR_USER": os.environ.get("PORTAL_OPERATOR_USER", ""),
        "PORTAL_OPERATOR_PASSWORD": os.environ.get("PORTAL_OPERATOR_PASSWORD", ""),
        "PORTAL_OPERATOR_PASSWORD_HASH": os.environ.get("PORTAL_OPERATOR_PASSWORD_HASH", ""),
    }
