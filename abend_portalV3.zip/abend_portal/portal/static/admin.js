(function () {
  "use strict";
  var add = document.getElementById("add-hdr");
  var tpl = document.getElementById("new-hdr-row");
  var table = document.getElementById("hdr-table");
  if (!add || !tpl || !table) { return; }
  add.addEventListener("click", function () {
    var idx = table.querySelectorAll('input[name="h_name"]').length;
    var node = tpl.content.cloneNode(true);
    node.querySelector('input[name="h_secret"]').value = String(idx);
    table.appendChild(node);
    var names = table.querySelectorAll('input[name="h_name"]');
    names[names.length - 1].focus();
  });
})();
