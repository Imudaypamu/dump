(function () {
  "use strict";
  var boxes = function () { return Array.prototype.slice.call(document.querySelectorAll('#review input[name^="include_"]:not(:disabled)')); };
  var out = document.getElementById("ticked");
  function count() { if (out) { out.textContent = boxes().filter(function (b) { return b.checked; }).length; } }

  document.querySelectorAll("[data-select]").forEach(function (a) {
    a.addEventListener("click", function () {
      var mode = a.getAttribute("data-select");
      boxes().forEach(function (b) {
        b.checked = mode === "all" ? true : mode === "none" ? false : b.getAttribute("data-ready") === "1";
      });
      count();
    });
  });
  document.addEventListener("change", function (e) { if (e.target.name && e.target.name.indexOf("include_") === 0) { count(); } });
  count();
})();
