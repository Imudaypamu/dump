(function () {
  "use strict";
  var raw = document.getElementById("close-data");
  var rows = Array.prototype.slice.call(document.querySelectorAll("#close-queue tr[data-number]"));
  var state = document.getElementById("f-state"), code = document.getElementById("f-code"), notes = document.getElementById("f-notes");
  var btn = document.getElementById("close-btn");
  var pick = document.getElementById("tpl-pick");
  if (pick) {
    pick.addEventListener("change", function () {
      var o = pick.options[pick.selectedIndex];
      if (!o.value) { return; }
      state.value = o.getAttribute("data-state") || state.value;
      code.value = o.getAttribute("data-code");
      notes.value = o.getAttribute("data-notes");
      preview();
    });
  }
  var save = document.getElementById("tpl-save");
  if (save) {
    save.addEventListener("submit", function () {
      save.elements.resolution_code.value = code.value; save.elements.state.value = state.value; save.elements.close_notes.value = notes.value;
    });
  }
  if (!raw || !btn) { return; }
  var data = JSON.parse(raw.textContent);
  var selAll = document.getElementById("sel-all"), pre = document.getElementById("preview");
  function picked() { return rows.filter(function (r) { return r.querySelector(".pick").checked; }); }
  function fill(s, row) {
    return s.replace(/\{(number|short_description|date)\}/g, function (_, k) {
      return k === "number" ? row.getAttribute("data-number") : k === "date" ? new Date().toISOString().slice(0, 10) : row.getAttribute("data-desc");
    });
  }
  function preview() {
    var p = picked();
    if (!p.length) { pre.textContent = "Select at least one incident."; return; }
    var row = p[0];
    var ctx = { number: row.getAttribute("data-number"), state: state.value, resolution_code: code.value,
                close_notes: fill(notes.value, row), short_description: row.getAttribute("data-desc"),
                date: new Date().toISOString().slice(0, 10) };
    try {
      var body = JSON.parse(data.payload_tpl, function (k, v) {
        return typeof v === "string" ? v.replace(/\{(\w+)\}/g, function (m, key) { return key in ctx ? ctx[key] : m; }) : v;
      });
      pre.textContent = "Example for " + ctx.number + " (" + p.length + " selected):\n\n" + JSON.stringify(body, null, 2);
    } catch (e) { pre.textContent = "Close payload on the Config page isn't valid JSON."; }
  }
  function refresh() {
    var n = picked().length;
    document.getElementById("sel-count").textContent = n;
    document.getElementById("close-n").textContent = n;
    btn.disabled = n === 0 || !state.value.trim() || !code.value.trim() || !notes.value.trim();
    selAll.checked = n === rows.length && n > 0;
    preview();
  }
  selAll.addEventListener("change", function () { rows.forEach(function (r) { r.querySelector(".pick").checked = selAll.checked; }); refresh(); });
  rows.forEach(function (r) { r.querySelector(".pick").addEventListener("change", refresh); });
  [state, code, notes].forEach(function (i) { i.addEventListener("input", refresh); });

  function setResult(row, cls, text, title) {
    var c = row.querySelector(".result"); c.textContent = "";
    var chip = document.createElement("span"); chip.className = "chip " + cls; chip.textContent = text;
    if (title) { chip.title = title; }
    c.appendChild(chip);
  }
  var reload = false;
  btn.addEventListener("click", function () {
    if (reload) { window.location.reload(); return; }
    var list = picked();
    if (!list.length) { return; }
    if (!data.dry_run && !window.confirm("Close " + list.length + " incident(s) in MyWizard with these values?")) { return; }
    btn.disabled = true; selAll.disabled = true;
    var line = document.getElementById("status-line"), bar = document.getElementById("bar");
    var i = 0, ok = 0, fail = 0, streak = 0;
    function next() {
      if (i >= list.length) { return finish(""); }
      if (streak >= 5) { return finish(" Stopped after 5 failures in a row."); }
      var row = list[i++];
      setResult(row, "warn", "sending...");
      line.textContent = (data.dry_run ? "Previewing " : "Closing ") + i + " of " + list.length + "...";
      window.postJSON("/incidents/close/run", { number: row.getAttribute("data-number"), state: state.value,
        resolution_code: code.value, close_notes: notes.value }).then(function (res) {
        if (res.ok && res.dry_run) { setResult(row, "info", "preview only", JSON.stringify(res.payload)); ok++; streak = 0; }
        else if (res.ok) { setResult(row, "ok", "closed"); ok++; streak = 0; }
        else { setResult(row, "error", "failed", res.error || ""); fail++; streak++; }
        bar.style.width = Math.round(100 * (ok + fail) / list.length) + "%";
        next();
      }).catch(function (e) { setResult(row, "error", "failed", String(e)); fail++; streak++; next(); });
    }
    function finish(extra) {
      line.textContent = (data.dry_run ? "Preview complete: " : "Finished: ") + ok + " ok" + (fail ? ", " + fail + " failed" : "") + "." + extra;
      selAll.disabled = false; btn.disabled = false;
      if (!data.dry_run) { reload = true; btn.textContent = "Refresh list"; }
    }
    next();
  });
  refresh();
})();
