/* Shared helpers: CSRF-aware fetch, auto-submit selects, confirm prompts, dialog close buttons. */
(function () {
  "use strict";
  var meta = document.querySelector('meta[name="csrf-token"]');
  window.CSRF = meta ? meta.content : "";

  window.postJSON = function (url, body) {
    return fetch(url, {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", "X-CSRF-Token": window.CSRF, "Accept": "application/json" },
      body: JSON.stringify(body)
    }).then(function (r) {
      return r.json().catch(function () { return { ok: false, error: "Unexpected reply (HTTP " + r.status + ")" }; });
    });
  };

  document.addEventListener("change", function (e) {
    var t = e.target;
    if (t.matches && t.matches("[data-autosubmit]") && t.form) { t.form.submit(); }
  });

  document.addEventListener("click", function (e) {
    var c = e.target.closest("[data-confirm]");
    if (c && !window.confirm(c.getAttribute("data-confirm"))) { e.preventDefault(); e.stopPropagation(); return; }
    var x = e.target.closest("[data-close]");
    if (x) { var d = x.closest("dialog"); if (d) { d.close(); } }
  }, true);
})();
