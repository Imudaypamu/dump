(function () {
  "use strict";
  var add = document.getElementById("add-rc");
  var tpl = document.getElementById("new-rc-row");
  var table = document.getElementById("rc-table");
  if (add && tpl && table) {
    add.addEventListener("click", function () {
      table.appendChild(tpl.content.cloneNode(true));
      var inputs = table.querySelectorAll('input[name="new_name"]');
      inputs[inputs.length - 1].focus();
    });
  }
})();
