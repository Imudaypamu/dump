(function () {
  "use strict";
  var raw = document.getElementById("dash-data");
  if (!raw) { return; }
  var data = JSON.parse(raw.textContent);

  function draw() {
    document.querySelectorAll("[data-chart]").forEach(function (host) {
      var series = data[host.getAttribute("data-series")] || [];
      var kind = host.getAttribute("data-chart");
      var limit = parseInt(host.getAttribute("data-limit") || "0", 10) || undefined;
      window.Charts[kind](host, series, limit);
    });
  }
  draw();
  var t;
  window.addEventListener("resize", function () { clearTimeout(t); t = setTimeout(draw, 150); });

  // top-task tabs
  var tabs = document.querySelectorAll("[data-tab]");
  tabs.forEach(function (b) {
    b.addEventListener("click", function () {
      tabs.forEach(function (x) { x.setAttribute("aria-selected", x === b ? "true" : "false"); });
      document.querySelectorAll("[data-panel]").forEach(function (p) { p.hidden = p.getAttribute("data-panel") !== b.getAttribute("data-tab"); });
    });
  });
})();
