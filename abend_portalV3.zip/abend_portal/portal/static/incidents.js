(function () {
  "use strict";
  var raw = document.getElementById("items-data");
  if (!raw) { return; }
  var data = JSON.parse(raw.textContent);
  var items = data.items;
  var bodies = Array.prototype.slice.call(document.querySelectorAll("#queue tbody[data-item]"));
  var selAll = document.getElementById("sel-all");
  var splitAll = document.getElementById("split-all");
  var btn = document.getElementById("create-btn");
  var bar = document.getElementById("bar");
  var line = document.getElementById("status-line");
  var dlg = document.getElementById("payload-dlg");
  var pre = document.getElementById("payload-json");
  var refreshMode = false;

  function itemOf(tb) { return items[parseInt(tb.getAttribute("data-item"), 10)]; }
  function isSplit(tb) { var s = tb.querySelector(".split"); return !!(s && s.checked); }
  function picks() { return bodies.filter(function (tb) { return tb.querySelector(".pick").checked; }); }

  // One "unit" = one incident to create. A split group becomes one unit per task, using the per-row payload rules.
  function unitsFor(tb) {
    var it = itemOf(tb);
    if (isSplit(tb)) { return it.ids.map(function (id) { return { mode: "row", ids: [id] }; }); }
    return [{ mode: data.mode, ids: it.ids }];
  }
  function totalUnits() { return picks().reduce(function (n, tb) { return n + unitsFor(tb).length; }, 0); }

  function refresh() {
    var p = picks().length, n = totalUnits();
    document.getElementById("sel-count").textContent = p;
    document.getElementById("create-n").textContent = n;
    document.getElementById("create-s").textContent = n === 1 ? "" : "s";
    btn.disabled = n === 0;
    selAll.checked = p === bodies.length;
    if (splitAll) {
      var boxes = bodies.map(function (tb) { return tb.querySelector(".split"); }).filter(Boolean);
      splitAll.checked = boxes.length > 0 && boxes.every(function (b) { return b.checked; });
    }
  }
  selAll.addEventListener("change", function () {
    bodies.forEach(function (tb) { tb.querySelector(".pick").checked = selAll.checked; });
    refresh();
  });
  if (splitAll) {
    splitAll.addEventListener("change", function () {
      bodies.forEach(function (tb) { var s = tb.querySelector(".split"); if (s) { s.checked = splitAll.checked; } });
      refresh();
    });
  }
  bodies.forEach(function (tb) {
    tb.querySelector(".pick").addEventListener("change", refresh);
    var s = tb.querySelector(".split");
    if (s) { s.addEventListener("change", refresh); }
    tb.querySelector("[data-preview]").addEventListener("click", function () {
      var it = itemOf(tb);
      var body = isSplit(tb) ? it.ids.map(function (id) { return it.row_payloads[String(id)]; }) : it.payload;
      pre.textContent = (isSplit(tb) ? "// " + it.ids.length + " separate incidents, one per task\n" : "") + JSON.stringify(body, null, 2);
      dlg.showModal();
    });
  });

  function setResult(tb, cls, text, title) {
    var cell = tb.querySelector(".result");
    cell.textContent = "";
    var chip = document.createElement("span");
    chip.className = "chip " + cls + (cls === "ok" && /^INC|^CHECK/i.test(text) ? " mono" : "");
    chip.textContent = text;
    if (title) { chip.title = title; }
    cell.appendChild(chip);
  }

  btn.addEventListener("click", function () {
    if (refreshMode) { window.location.reload(); return; }
    var work = [];
    picks().forEach(function (tb) {
      var us = unitsFor(tb);
      tb._agg = { total: us.length, ok: 0, fail: 0, nums: [], errs: [] };
      us.forEach(function (u) { work.push({ tb: tb, unit: u }); });
    });
    if (!work.length) { return; }
    if (!data.dry_run && !window.confirm("Create " + work.length + " incident(s) in MyWizard now?")) { return; }
    btn.disabled = true; selAll.disabled = true;
    if (splitAll) { splitAll.disabled = true; }
    bodies.forEach(function (tb) { var s = tb.querySelector(".split"); if (s) { s.disabled = true; } });
    var done = 0, okN = 0, failN = 0, i = 0;
    bar.style.width = "0";

    function report(tb) {
      var a = tb._agg, finished = a.ok + a.fail === a.total, label;
      if (a.total === 1) {
        if (a.ok) { return data.dry_run ? setResult(tb, "info", "preview only", "Nothing was sent (dry run).")
                    : setResult(tb, /^CHECK:/.test(a.nums[0]) ? "warn" : "ok", a.nums[0], a.nums[0]); }
        return setResult(tb, "error", "failed", a.errs[0] || "Unknown error");
      }
      if (!finished) { return setResult(tb, "warn", (a.ok + a.fail) + "/" + a.total + "..."); }
      if (a.fail) { return setResult(tb, "error", a.ok + " ok, " + a.fail + " failed", a.errs.join("\n")); }
      label = data.dry_run ? a.total + " previewed" : a.total + " created";
      setResult(tb, data.dry_run ? "info" : "ok", label, a.nums.join(", "));
    }

    function next() {
      if (i >= work.length) { return finish(); }
      var w = work[i++];
      line.textContent = (data.dry_run ? "Previewing " : "Creating ") + i + " of " + work.length + "...";
      if (w.tb._agg.total === 1) { setResult(w.tb, "warn", "sending..."); }
      window.postJSON("/incidents/create", { mode: w.unit.mode, ids: w.unit.ids }).then(function (res) {
        var a = w.tb._agg;
        if (res.ok) { a.ok++; okN++; if (res.incident_no) { a.nums.push(res.incident_no); } }
        else { a.fail++; failN++; a.errs.push(res.error || "Unknown error"); }
        report(w.tb);
        done++;
        bar.style.width = Math.round(100 * done / work.length) + "%";
        next();
      }).catch(function (err) {
        var a = w.tb._agg; a.fail++; failN++; a.errs.push(String(err)); report(w.tb); done++; next();
      });
    }

    function finish() {
      line.textContent = (data.dry_run ? "Preview complete: " : "Finished: ") + okN + " ok" + (failN ? ", " + failN + " failed (fix and run again)" : "") + ".";
      btn.disabled = false; selAll.disabled = false;
      if (data.dry_run) {  // a preview changes nothing, so let the user adjust and preview again
        if (splitAll) { splitAll.disabled = false; }
        bodies.forEach(function (tb) { var sp = tb.querySelector(".split"); if (sp) { sp.disabled = false; } });
      } else { refreshMode = true; btn.textContent = "Refresh queue"; }
    }
    next();
  });
  refresh();
})();
