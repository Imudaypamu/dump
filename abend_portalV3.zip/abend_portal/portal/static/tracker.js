(function () {
  "use strict";
  var dlg = document.getElementById("edit-dlg");
  if (!dlg) { return; }
  var form = document.getElementById("edit-form");
  var map = { task_text: "e-task", app: "e-app", root_cause: "e-rc", action: "e-action", date: "e-date", category: "e-cat",
              assigned_to: "e-assigned", incident_no: "e-inc", incident_status: "e-status", comments: "e-comments" };

  document.querySelectorAll("[data-edit]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var row = JSON.parse(btn.getAttribute("data-edit"));
      Object.keys(map).forEach(function (k) { document.getElementById(map[k]).value = row[k] == null ? "" : row[k]; });
      form.action = "/tracker/" + row.id + "/update";
      document.getElementById("save-btn").formAction = "/tracker/" + row.id + "/update";
      document.getElementById("del-btn").formAction = "/tracker/" + row.id + "/delete";
      dlg.showModal();
    });
  });
})();
