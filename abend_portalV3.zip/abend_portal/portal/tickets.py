"""Incidents and RITMs: what is open, what was closed recently, and bulk closing.

Where the data comes from
  * incidents the portal creates are recorded automatically (open);
  * anything else (other incidents, RITMs raised by other people) arrives by importing a
    ServiceNow export - CSV, Excel or a paste with a header row;
  * closing an incident from the portal records it as closed straight away.

So the numbers are exactly as fresh as your last import / portal action. The dashboard says so.
"""
import csv
import io
import json
import re
from datetime import date, datetime, timedelta
from urllib.parse import quote

import requests
from openpyxl import load_workbook

from . import mywizard
from .db import now, persist
from .intake import History
from .parser import parse_date
from .rules import Rules, clean, norm

OPEN = ("open", "closing")

ALIASES = {
    "number": ["number", "ticket", "ticketnumber", "incident", "ritm", "requestitem"],
    "short_description": ["shortdescription", "briefdescription", "summary"],
    "description": ["description", "details", "comments"],
    "state_text": ["state", "status", "stage"],
    "opened_at": ["opened", "openedat", "created", "createdon", "syscreatedon", "opendate"],
    "closed_at": ["closed", "closedat", "resolved", "resolvedat", "closeddate"],
    "assignment_group": ["assignmentgroup", "group"],
    "assigned_to": ["assignedto", "assignee"],
    "priority": ["priority"],
    "resolution_code": ["closecode", "resolutioncode"],
    "close_notes": ["closenotes", "resolutionnotes", "closurenotes"],
}


def _key(s) -> str:
    return re.sub(r"[^a-z0-9]", "", str(s or "").lower())


def kind_of(number: str) -> str:
    n = (number or "").upper()
    if n.startswith("INC"):
        return "INC"
    if n.startswith("RITM"):
        return "RITM"
    return "OTHER"


def state_of(kind: str, text: str) -> str:
    t = clean(text).lower()
    if not t:
        return "open"
    if re.search(r"closed|resolved|cancel|complete|skipped", t) and "in progress" not in t:
        return "closed"
    if t.isdigit():
        return "closed" if int(t) in ((6, 7, 8) if kind == "INC" else (3, 4, 7)) else "open"
    return "open"


def _dt(v) -> str:
    if isinstance(v, datetime):
        return v.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(v, date):
        return v.isoformat()
    s = clean(v)
    if not s:
        return ""
    m = re.match(r"^(\d{4}-\d{2}-\d{2})(?:[ T](\d{2}:\d{2}(?::\d{2})?))?", s)
    if m:
        return m.group(1) + (" " + m.group(2) if m.group(2) else "")
    iso, _ = parse_date(s.split(" ")[0] if re.match(r"^\d{1,2}[/-]", s) else s)
    return iso or s


# ----------------------------------------------------------------------------- import
def read_table(fileobj, filename: str):
    """-> list of header->value dict rows from CSV or Excel."""
    if filename.lower().endswith((".xlsx", ".xlsm")):
        wb = load_workbook(fileobj, read_only=True, data_only=True)
        rows = list(wb[wb.sheetnames[0]].iter_rows(values_only=True))
        wb.close()
    else:
        text = fileobj.read()
        text = text.decode("utf-8-sig", errors="replace") if isinstance(text, bytes) else text
        rows = _rows_from_text(text)
    return _to_dicts(rows)


def _rows_from_text(text: str):
    text = text.replace("\r\n", "\n").replace("\r", "\n").strip()
    first = text.split("\n", 1)[0]
    delim = "\t" if first.count("\t") >= first.count(",") and "\t" in first else ","
    return list(csv.reader(io.StringIO(text), delimiter=delim))


def _to_dicts(rows):
    rows = [r for r in rows if r and any(clean(c) for c in r)]
    if not rows:
        return []
    header = [_key(h) for h in rows[0]]
    colmap = {}
    for field, names in ALIASES.items():
        for n in names:
            if n in header:
                colmap[field] = header.index(n)
                break
    if "number" not in colmap:
        raise ValueError("No 'Number' column found. The first row must be the header (Number, State, Short description ...).")
    out = []
    for r in rows[1:]:
        d = {f: (r[i] if i < len(r) else None) for f, i in colmap.items()}
        if clean(d.get("number")):
            out.append(d)
    return out


TASK_SENTENCE = re.compile(r"(?:Task\s+)?'[^']+'\s+abnormal\s+in\s+process\s+'[^']+'(?:\s*\(\d+\))?\s*(?:alert)?", re.I)
CAT_PIPE = re.compile(r"^\s*(BDM|PWC|CLOUD)\s*\|\s*([^|]+?)\s*(?:\||$)", re.I)
ENRICH = ["task_text", "task_name", "process", "run_id", "app", "category", "root_cause", "abend_date"]


def enrich(rules: Rules, hist: History, short: str, desc: str, opened: str) -> dict:
    """Work out which task / app / category / root cause a script-raised incident is about.
    Understands this portal's own 'Cat | App | ... | Root cause' short descriptions and the
    "Task '...' abnormal in process '...'" sentence; anything it can't find is left blank to edit."""
    from . import parser
    out = {k: "" for k in ENRICH}
    text = f"{short} {desc}"
    m = TASK_SENTENCE.search(desc) or TASK_SENTENCE.search(short)
    if m:
        out["task_text"] = clean(m.group(0))
        t = parser.parse_task(out["task_text"])
        out.update(task_name=t["task_name"], process=t["process"], run_id=t["run_id"])
    else:
        out["task_text"] = clean(short or desc)[:300]
    cm = CAT_PIPE.match(short)
    if cm:
        out["category"] = cm.group(1).upper()
        out["app"] = rules.canonical_app(cm.group(2).split(",")[0])[0]
    if not out["app"]:
        for name in sorted(rules.apps, key=len, reverse=True):
            if re.search(r"(?<![A-Za-z0-9])" + re.escape(name) + r"(?![A-Za-z0-9])", text, re.I):
                out["app"] = name
                break
    if not out["category"] and out["app"]:
        out["category"] = hist.app_category.get(norm(out["app"]), "")
    names = []
    for row in rules.root_causes:
        names.append((row["root_cause"], row["root_cause"]))
        names += [(a.strip(), row["root_cause"]) for a in re.split(r"[,;\n]", row.get("aliases") or "") if a.strip()]
    for alias, canon in sorted(names, key=lambda x: len(x[0]), reverse=True):
        if alias.lower() in text.lower():
            out["root_cause"] = canon
            break
    out["abend_date"] = (opened or "")[:10]
    return out


def import_rows(conn, rows: list, source="import", rules: Rules = None) -> dict:
    added = updated = 0
    hist = History(conn) if rules else None
    for d in rows:
        number = clean(d["number"]).upper()
        kind = kind_of(number)
        state_text = clean(d.get("state_text"))
        state = state_of(kind, state_text)
        desc = clean(d.get("description"))
        short = clean(d.get("short_description")) or desc[:200]
        vals = {
            "short_description": short, "state_text": state_text, "description": desc,
            "opened_at": _dt(d.get("opened_at")), "closed_at": _dt(d.get("closed_at")),
            "assignment_group": clean(d.get("assignment_group")), "assigned_to": clean(d.get("assigned_to")),
            "priority": clean(d.get("priority")), "resolution_code": clean(d.get("resolution_code")),
            "close_notes": clean(d.get("close_notes")),
        }
        if state == "closed" and not vals["closed_at"]:
            vals["closed_at"] = now()[:10]
        cur = conn.execute("SELECT id, source FROM tickets WHERE number=?", (number,)).fetchone()
        enr = enrich(rules, hist, short, desc, vals["opened_at"]) if (rules and kind == "INC" and source != "portal") else {}
        if cur:
            keep_source = cur["source"] == "portal"          # never demote an incident this portal created
            sets = ", ".join(f"{k}=COALESCE(NULLIF(?, ''), {k})" for k in vals)
            # enrichment never overwrites what a person already corrected
            sets += "".join(f", {k}=COALESCE(NULLIF({k}, ''), ?)" for k in enr)
            conn.execute(f"UPDATE tickets SET {sets}, state=?, kind=?, last_error=NULL, source=?, updated_at=? WHERE id=?",
                         list(vals.values()) + list(enr.values()) + [state, kind, "portal" if keep_source else source,
                                                                      now(), cur["id"]])
            updated += 1
        else:
            allv = {**vals, **enr}
            conn.execute(
                "INSERT INTO tickets(number, kind, state, source, updated_at, " + ",".join(allv) + ") VALUES(?,?,?,?,?,"
                + ",".join("?" * len(allv)) + ")", [number, kind, state, source, now()] + list(allv.values()))
            added += 1
    conn.commit()
    linked = link_abends(conn) if rules else 0
    return {"added": added, "updated": updated, "total": len(rows), "linked": linked}


def link_abends(conn) -> int:
    """Attach script incidents to the tracker row for the same task (same day +-1). The tracker row then shows
    the incident number, exactly as if the portal had created it."""
    n = 0
    for t in conn.execute("SELECT id, number, task_name, abend_date FROM tickets WHERE kind='INC' AND source!='portal' "
                          "AND abend_id IS NULL AND COALESCE(task_name,'')!='' AND COALESCE(abend_date,'')!=''").fetchall():
        a = conn.execute(
            "SELECT id, incident_no FROM abends WHERE lower(task_name)=lower(?) "
            "AND ABS(julianday(date)-julianday(?))<=1 AND id NOT IN (SELECT abend_id FROM tickets WHERE abend_id IS NOT NULL) "
            "ORDER BY ABS(julianday(date)-julianday(?)), id LIMIT 1", (t["task_name"], t["abend_date"], t["abend_date"])).fetchone()
        if not a:
            continue
        conn.execute("UPDATE tickets SET abend_id=? WHERE id=?", (a["id"], t["id"]))
        if not (a["incident_no"] or "").strip():
            conn.execute("UPDATE abends SET incident_no=?, incident_status='created', updated_at=? WHERE id=?",
                         (t["number"], now(), a["id"]))
        n += 1
    conn.commit()
    return n


def script_list(conn, rules: Rules, f) -> list:
    """Incidents raised outside the portal, with the same filters as the tracker."""
    sql, args = "SELECT * FROM tickets WHERE kind='INC' AND source!='portal'", []
    if f.get("from"):
        sql += " AND COALESCE(NULLIF(abend_date,''), substr(opened_at,1,10))>=?"
        args.append(f["from"])
    if f.get("to"):
        sql += " AND COALESCE(NULLIF(abend_date,''), substr(opened_at,1,10))<=?"
        args.append(f["to"])
    if f.get("app"):
        sql += " AND app=? COLLATE NOCASE"
        args.append(f["app"])
    if f.get("category"):
        sql += " AND category=?"
        args.append(f["category"])
    if f.get("state") == "open":
        sql += " AND state IN ('open','closing')"
    elif f.get("state") == "closed":
        sql += " AND state='closed'"
    if f.get("link") == "linked":
        sql += " AND abend_id IS NOT NULL"
    elif f.get("link") == "unlinked":
        sql += " AND abend_id IS NULL"
    if f.get("q"):
        sql += " AND (number LIKE ? OR short_description LIKE ? OR task_name LIKE ? OR root_cause LIKE ?)"
        args += [f"%{f['q']}%"] * 4
    rows = [dict(r) for r in conn.execute(sql + " ORDER BY COALESCE(NULLIF(abend_date,''), substr(opened_at,1,10)) DESC, number DESC", args)]
    for r in rows:
        r["issue_type"] = rules.issue_type(r["root_cause"]) if r["root_cause"] else ""
        r["day"] = r["abend_date"] or (r["opened_at"] or "")[:10]
        r["age"] = _age(r["opened_at"]) if r["state"] != "closed" else ""
    if f.get("type"):
        rows = [r for r in rows if r["issue_type"] == f["type"]]
    return rows


def record_created(conn, number: str, short_description: str, assignment_group: str = "") -> None:
    """Called when the portal creates an incident."""
    if not number or number.upper().startswith("CHECK:"):
        return
    import_rows(conn, [{"number": number, "short_description": short_description, "state_text": "New",
                        "opened_at": now(), "assignment_group": assignment_group}], source="portal")


# ----------------------------------------------------------------------------- dashboard
def _age(opened: str) -> str:
    try:
        d = datetime.strptime((opened or "")[:10], "%Y-%m-%d").date()
    except ValueError:
        return ""
    n = (date.today() - d).days
    return f"{n}d"


def _fetch(conn, kind, state_open, limit, recent_cut=None):
    if state_open:
        sql, args = "SELECT * FROM tickets WHERE kind=? AND state IN ('open','closing') ORDER BY opened_at, number", [kind]
    else:
        sql = "SELECT * FROM tickets WHERE kind=? AND state='closed'"
        args = [kind]
        if recent_cut:
            sql += " AND COALESCE(NULLIF(closed_at,''),'0000') >= ?"
            args.append(recent_cut)
        sql += " ORDER BY closed_at DESC, number"
    rows = [dict(r) for r in conn.execute(sql + f" LIMIT {int(limit)}", args)]
    for r in rows:
        r["age"] = _age(r["opened_at"])
    return rows


def dashboard_block(conn, recent_days=7, limit=15) -> dict:
    cut = (date.today() - timedelta(days=recent_days)).isoformat()

    def n(kind, where, *a):
        return conn.execute(f"SELECT COUNT(*) FROM tickets WHERE kind=? AND {where}", (kind, *a)).fetchone()[0]

    block = {"recent_days": recent_days, "total": conn.execute("SELECT COUNT(*) FROM tickets").fetchone()[0]}
    for kind, key in (("INC", "inc"), ("RITM", "ritm")):
        block[key] = {
            "open_n": n(kind, "state IN ('open','closing')"),
            "closed_recent_n": n(kind, "state='closed' AND COALESCE(NULLIF(closed_at,''),'0000')>=?", cut),
            "closed_n": n(kind, "state='closed'"),
            "open": _fetch(conn, kind, True, limit),
            "closed": _fetch(conn, kind, False, limit, cut),
        }
    last = conn.execute("SELECT MAX(updated_at) FROM tickets WHERE source='import'").fetchone()[0]
    block["last_import"] = last
    return block


def list_tickets(conn, kind="", state="", q="", limit=500):
    sql, args = "SELECT * FROM tickets WHERE 1=1", []
    if kind:
        sql += " AND kind=?"
        args.append(kind)
    if state == "open":
        sql += " AND state IN ('open','closing')"
    elif state:
        sql += " AND state=?"
        args.append(state)
    if q:
        sql += " AND (number LIKE ? OR short_description LIKE ? OR assigned_to LIKE ? OR assignment_group LIKE ?)"
        args += [f"%{q}%"] * 4
    rows = [dict(r) for r in conn.execute(sql + f" ORDER BY COALESCE(NULLIF(opened_at,''),'0') DESC, number LIMIT {int(limit)}", args)]
    for r in rows:
        r["age"] = _age(r["opened_at"]) if r["state"] != "closed" else ""
    return rows


# ----------------------------------------------------------------------------- closing
def _sub(node, ctx):
    if isinstance(node, dict):
        return {k: _sub(v, ctx) for k, v in node.items()}
    if isinstance(node, list):
        return [_sub(v, ctx) for v in node]
    if isinstance(node, str):
        return re.sub(r"\{(\w+)\}", lambda m: str(ctx.get(m.group(1), m.group(0))), node)
    return node


def validate_template(text: str):
    try:
        obj = json.loads(text)
    except ValueError as exc:
        return f"Close payload is not valid JSON: {exc}"
    return None if isinstance(obj, dict) else "Close payload must be a JSON object."


def build_close(rules: Rules, cfg, ticket: dict, fields: dict) -> dict:
    ctx = {"number": ticket["number"], "short_description": ticket["short_description"] or "",
           "date": date.today().isoformat(), "resolution_code": fields["resolution_code"], "state": fields["state"]}
    ctx["close_notes"] = _sub(fields["close_notes"], ctx)
    url = cfg["CLOSE_URL"].replace("{number}", quote(ticket["number"]))
    return {"method": cfg["CLOSE_METHOD"], "url": url,
            "body": _sub(json.loads(rules.settings["close_payload"]), ctx), "close_notes": ctx["close_notes"]}


def close_ticket(conn, rules: Rules, cfg, number: str, fields: dict) -> dict:
    fields = {k: clean(fields.get(k)) if k != "close_notes" else (fields.get(k) or "").strip()
              for k in ("resolution_code", "state", "close_notes")}
    if not fields["resolution_code"] or not fields["close_notes"] or not fields["state"]:
        return {"ok": False, "error": "State, resolution code and close notes are all required."}
    bad = validate_template(rules.settings["close_payload"])
    if bad:
        return {"ok": False, "error": bad}
    t = conn.execute("SELECT * FROM tickets WHERE number=?", (number,)).fetchone()
    if not t or t["kind"] != "INC":
        return {"ok": False, "error": f"{number}: not an incident in the portal."}
    t = dict(t)
    plan = build_close(rules, cfg, t, fields)
    if rules.dry_run:
        return {"ok": True, "dry_run": True, "number": number, "method": plan["method"], "url": plan["url"],
                "payload": plan["body"]}
    missing = mywizard.missing(cfg, "close")
    if missing:
        return {"ok": False, "error": "MyWizard connection incomplete (ask an admin): " + ", ".join(missing)}

    conn.commit()
    conn.execute("BEGIN IMMEDIATE")
    cur = conn.execute("UPDATE tickets SET state='closing', last_error=NULL, updated_at=? WHERE number=? AND state='open'",
                       (now(), number))
    if cur.rowcount != 1:
        conn.rollback()
        return {"ok": False, "error": f"{number} is already closed or being closed - refresh the page."}
    conn.commit()
    persist()

    timeout = cfg["TIMEOUT"]
    try:
        resp = requests.request(plan["method"], plan["url"], data=json.dumps(plan["body"]),
                                headers=mywizard.headers_dict(cfg), timeout=(timeout, timeout), verify=cfg["VERIFY"])
        ok, err = resp.status_code in (200, 201, 202, 204), f"HTTP {resp.status_code} - {(resp.text or '')[:120]}"
    except requests.RequestException as exc:
        ok, err = False, f"{type(exc).__name__}: {exc}"[:300]
    if ok:
        conn.execute("UPDATE tickets SET state='closed', state_text=?, closed_at=?, resolution_code=?, close_notes=?, "
                     "last_error=NULL, updated_at=? WHERE number=?",
                     (fields["state"], now(), fields["resolution_code"], plan["close_notes"], now(), number))
    else:
        conn.execute("UPDATE tickets SET state='open', last_error=?, updated_at=? WHERE number=?", (err, now(), number))
    conn.commit()
    return {"ok": ok, "number": number, "error": None if ok else err}


def reset_closing(conn, numbers) -> int:
    marks = ",".join("?" * len(numbers))
    if not numbers:
        return 0
    cur = conn.execute(f"UPDATE tickets SET state='open', updated_at=? WHERE state='closing' AND number IN ({marks})",
                       [now()] + list(numbers))
    conn.commit()
    return cur.rowcount


# ----------------------------------------------------------------------------- live fetch
LIST_KEYS = ("result", "results", "incidents", "records", "data", "items", "incident")
EXTRA_ALIASES = {"config_item": ["cmdbci", "configurationitem", "configitem", "ci", "cmdb"]}


def _val(v) -> str:
    """ServiceNow reference fields arrive as {'display_value': ..., 'value': ...}."""
    if isinstance(v, dict):
        for k in ("display_value", "displayValue", "name", "value"):
            if v.get(k) not in (None, ""):
                return str(v[k])
        return ""
    return "" if v is None else str(v)


def _extract_list(node):
    if isinstance(node, list):
        return node if all(isinstance(x, dict) for x in node) else []
    if isinstance(node, dict):
        for k in LIST_KEYS:
            if k in node:
                found = _extract_list(node[k])
                if found:
                    return found
        if any(_key(k) in ("number", "incidentnumber") for k in node):
            return [node]          # a single incident
    return []


def _item_to_row(item: dict) -> dict:
    norm_item = {_key(k): v for k, v in item.items()}
    row = {}
    for field, names in {**ALIASES, **EXTRA_ALIASES}.items():
        for n in names:
            if n in norm_item and _val(norm_item[n]) != "":
                row[field] = _val(norm_item[n])
                break
    return row


def fetch_incidents(conn, rules: Rules, cfg) -> dict:
    """Ask MyWizard for the incidents of one configuration item / assignment group and import them.
    Read-only on the MyWizard side, so it also works while dry run is on."""
    bad = mywizard.missing(cfg, "fetch")
    if bad:
        return {"ok": False, "error": "MyWizard connection incomplete (ask an admin): " + ", ".join(bad)}
    try:
        body = json.loads(cfg["FETCH_BODY"])
    except ValueError as exc:
        return {"ok": False, "error": f"Fetch body on the MyWizard page is not valid JSON: {exc}"}
    ctx = {"config_item": cfg["CONFIG_ITEM"], "assignment_group": cfg["ASSIGNMENT_GROUP"]}
    url = re.sub(r"\{(\w+)\}", lambda m: quote(str(ctx.get(m.group(1), m.group(0)))), cfg["FETCH_URL"])
    kwargs = {"headers": mywizard.headers_dict(cfg), "timeout": (cfg["TIMEOUT"], cfg["TIMEOUT"]), "verify": cfg["VERIFY"]}
    if cfg["FETCH_METHOD"] != "GET":
        kwargs["data"] = json.dumps(_sub(body, ctx))
    try:
        resp = requests.request(cfg["FETCH_METHOD"], url, **kwargs)
    except requests.RequestException as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"[:300]}
    if resp.status_code not in (200, 201):
        return {"ok": False, "error": f"HTTP {resp.status_code} - {(resp.text or '')[:160]}"}
    try:
        items = _extract_list(resp.json())
    except ValueError:
        return {"ok": False, "error": "MyWizard did not return JSON: " + (resp.text or "")[:160]}

    want_ci, want_grp = cfg["CONFIG_ITEM"].lower(), cfg["ASSIGNMENT_GROUP"].lower()
    rows = []
    for it in items:
        r = _item_to_row(it)
        if not clean(r.get("number")):
            continue
        ci = r.get("config_item", "")
        who = [x for x in (r.get("assignment_group", ""), r.get("assigned_to", "")) if x]
        if want_ci and ci and want_ci not in ci.lower():
            continue                                    # a different configuration item
        if want_grp and who and not any(want_grp in x.lower() for x in who):
            continue                                    # assigned to someone else
        rows.append(r)
    res = import_rows(conn, rows, source="script", rules=rules)
    return {"ok": True, "fetched": len(items), "kept": len(rows), "dropped": len(items) - len(rows), **res}
