#!/usr/bin/env python3
"""Start the portal.  Uses waitress (production-grade, works on Windows) when installed."""
import os

from portal import create_app

app = create_app()

if __name__ == "__main__":
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "5000"))
    try:
        from waitress import serve
    except ImportError:
        print("waitress not installed - using Flask's development server (fine for one user on localhost).")
        app.run(host=host, port=port)
    else:
        print(f"Abend desk running on http://{host}:{port}  (Ctrl+C to stop)")
        serve(app, host=host, port=port, threads=4)
