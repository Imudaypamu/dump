import re

TOKEN = "Bearer s3cret-token-VALUE"
WL = "wl-secret-VALUE-123"


def csrf(html):
    return re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)


def login(client, user="admin", password="pw"):
    t = csrf(client.get("/login").text)
    return client.post("/login", data={"csrf_token": t, "username": user, "password": password})


def configure(client, port, close_method="PATCH", extra=None):
    """Fill in the admin MyWizard page the way a person would."""
    t = csrf(client.get("/admin/mywizard").text)
    data = {
        "csrf_token": t, "mw_url": f"http://127.0.0.1:{port}/create",
        "h_name": ["Accept", "Content-Type", "X-WL-AUTH", "Authorization"],
        "h_value": ["application/json", "application/json", WL, TOKEN],
        "h_secret": ["2", "3"],
        "mw_timeout": "10", "mw_verify": "true",
        "mw_close_url": f"http://127.0.0.1:{port}/close/{{number}}", "mw_close_method": close_method,
        "mw_fetch_url": f"http://127.0.0.1:{port}/fetch", "mw_fetch_method": "POST",
        "mw_fetch_body": '{"cmdb_ci": "{config_item}", "assignment_group": "{assignment_group}"}',
        "mw_fetch_ci": "Informatica", "mw_fetch_group": "ETL Support",
        "close_payload": '{"number": "{number}", "state": "{state}", "close_code": "{resolution_code}", "close_notes": "{close_notes}"}',
    }
    data.update(extra or {})
    return client.post("/admin/mywizard/save", data=data, follow_redirects=True)
