"""Script incidents: live fetch of Informatica / ETL Support incidents from MyWizard."""
import io, json, os, re, sys, tempfile, threading, http.server, shutil
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _helpers as hp

calls = []
def ref(v): return {"display_value": v, "value": "sys" + v[:3]}
PAYLOAD = {"result": [
  {"number": "INC800001", "short_description": "Abend RKSEIJ9041", "state": "New", "opened_at": "2026-07-29 07:10:00",
   "description": "Task 'RKSEIJ9041_DEALER_reload_Hive_DLR_DTL' abnormal in process 'R_VCD_DEALER_Hive_Process' (23943061)alert - Grid issue",
   "cmdb_ci": ref("Informatica"), "assignment_group": ref("ETL Support"), "assigned_to": ref("Bob")},
  {"number": "INC800002", "short_description": "Abend RKNEW1", "state": "In Progress", "opened_at": "2026-07-30 08:00:00",
   "description": "Task 'RKNEW1_SPS_LOAD' abnormal in process 'R_SPS_Auto_Process' (24000001) Lookup cache issue",
   "cmdb_ci": ref("Informatica"), "assignment_group": ref("ETL Support HNA")},
  {"number": "INC800003", "short_description": "DB down", "state": "New", "opened_at": "2026-07-30 09:00:00",
   "cmdb_ci": ref("Oracle DB"), "assignment_group": ref("ETL Support")},                      # other CI -> dropped
  {"number": "INC800004", "short_description": "Net issue", "state": "New", "opened_at": "2026-07-30 10:00:00",
   "cmdb_ci": ref("Informatica"), "assignment_group": ref("Network Team"), "assigned_to": ref("Eve")},  # other team -> dropped
  {"number": "INC800005", "short_description": "BDM | WBI | Grid issue", "state": "Resolved", "opened_at": "2026-07-30 11:00:00"},  # no CI/team info -> kept
]}
mode = {"v": "ok"}
class H(http.server.BaseHTTPRequestHandler):
    def _reply(self):
        if mode["v"] == "401": self.send_response(401); self.end_headers(); self.wfile.write(b"denied"); return
        if mode["v"] == "html": self.send_response(200); self.end_headers(); self.wfile.write(b"<html>"); return
        self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers()
        self.wfile.write(json.dumps(PAYLOAD).encode())
    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        calls.append(("POST", self.path, json.loads(self.rfile.read(n) or b"{}"), dict(self.headers))); self._reply()
    def do_GET(self):
        calls.append(("GET", self.path, None, dict(self.headers))); self._reply()
    def log_message(self, *a): pass
srv = http.server.HTTPServer(("127.0.0.1", 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()

from portal import create_app, db, intake
from portal.rules import Rules
tmp = tempfile.mkdtemp()
app = create_app({"DATABASE": os.path.join(tmp, "d.xlsx"), "PORTAL_PASSWORD": "pw", "TESTING": True})
conn = db.STORE.conn
txt = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample.txt")).read()
bid = intake.create_batch(conn, Rules(conn), txt, "2026-07-29"); intake.commit(conn, Rules(conn), bid)
c = app.test_client(); hp.login(c); hp.configure(c, srv.server_port)
ok = []
def check(cond, msg): print(("PASS " if cond else "FAIL ") + msg); ok.append(cond)
T = hp.csrf(c.get("/script-incidents").text)
row = lambda n: dict(conn.execute("SELECT * FROM tickets WHERE number=?", (n,)).fetchone())

r = c.post("/script-incidents/fetch", data={"csrf_token": T}, follow_redirects=True)
check("Fetched 5 incident(s) from MyWizard, kept 3: 3 new, 0 updated. 2 belonged" in r.text, "fetch: 5 returned, 3 kept, 2 ignored (other CI / other team)")
m, path, body, h = calls[-1]
check(m == "POST" and path == "/fetch" and body == {"cmdb_ci": "Informatica", "assignment_group": "ETL Support"}, f"request body carries the two filters: {body}")
check(h.get("X-WL-AUTH") == hp.WL and h.get("Authorization") == hp.TOKEN and "X-API-Key" not in h, "same curl-style headers on fetch")
ids = {r_[0] for r_ in conn.execute("SELECT number FROM tickets")}
check(ids == {"INC800001", "INC800002", "INC800005"}, f"stored only the right incidents: {sorted(ids)}")
a = row("INC800001")
check((a["app"], a["category"], a["root_cause"], a["task_name"], a["assigned_to"]) == ("VCD", "BDM", "Grid issue", "RKSEIJ9041_DEALER_reload_Hive_DLR_DTL", "Bob"), "reference fields + enrichment read correctly")
check(a["abend_id"] is not None and conn.execute("SELECT incident_no FROM abends WHERE id=?", (a["abend_id"],)).fetchone()[0] == "INC800001", "linked to the tracker row, which now shows the INC")
check(row("INC800005")["state"] == "closed" and row("INC800005")["app"] == "WBI", "title format 'BDM | WBI | Grid issue' understood; Resolved => closed")

page = c.get("/script-incidents").text
check("INC800001" in page and "INC800003" not in page and "INC800004" not in page, "page lists only fetched Informatica / ETL Support incidents")
q = lambda s: c.get("/script-incidents?" + s).text
check("INC800002" in q("app=SPS") and "INC800001" not in q("app=SPS"), "filter: app")
check("INC800005" in q("state=closed") and "INC800002" not in q("state=closed"), "filter: state")
check("INC800002" in q("type=Other+Issue") and "INC800001" not in q("type=Other+Issue"), "filter: issue type")
check("INC800002" in q("from=2026-07-30") and "INC800001" not in q("from=2026-07-30"), "filter: date")
check("INC800001" in q("category=BDM") and "INC800002" not in q("category=BDM"), "filter: category")
check(c.get("/export/script_incidents.xlsx").data[:2] == b"PK", "xlsx export")

r = c.post("/script-incidents/fetch", data={"csrf_token": T}, follow_redirects=True)
check("0 new, 3 updated" in r.text, "fetch again updates, no duplicates")
mode["v"] = "401"; r = c.post("/script-incidents/fetch", data={"csrf_token": T}, follow_redirects=True)
check("Fetch failed: HTTP 401" in r.text, "HTTP error shown")
mode["v"] = "html"; r = c.post("/script-incidents/fetch", data={"csrf_token": T}, follow_redirects=True)
check("did not return JSON" in r.text, "non-JSON reply explained")
mode["v"] = "ok"
# GET mode with placeholders in the URL
hp.configure(c, srv.server_port, extra={"mw_fetch_method": "GET", "mw_fetch_url": f"http://127.0.0.1:{srv.server_port}/q?ci={{config_item}}&grp={{assignment_group}}"})
c.post("/script-incidents/fetch", data={"csrf_token": T})
check(calls[-1][0] == "GET" and calls[-1][1] == "/q?ci=Informatica&grp=ETL%20Support", f"GET url filled in: {calls[-1][1]}")
# import fallback still works
csv = "Number,Short description,State,Opened\nINC800009,BDM | FQR | Grid issue,New,2026-07-31 08:00:00\n"
r = c.post("/script-incidents/import", data={"csrf_token": T, "file": (io.BytesIO(csv.encode()), "s.csv")}, content_type="multipart/form-data", follow_redirects=True)
check("Imported 1 incident(s)" in r.text and row("INC800009")["app"] == "FQR", "import fallback works")
# the removed features are really gone
check(c.post("/script-incidents/INC800001/update", data={"csrf_token": T}).status_code == 404, "edit/log/relink routes removed")
print("FAILURES:", ok.count(False)); shutil.rmtree(tmp)
