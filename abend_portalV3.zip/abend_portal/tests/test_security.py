"""Two roles: admin sees/changes the MyWizard connection and users; operator can't."""
import html as _html, os, re, shutil, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _helpers as hp
from openpyxl import load_workbook
from portal import create_app, db, mywizard
from portal.rules import Rules

tmp = tempfile.mkdtemp(); path = os.path.join(tmp, "d.xlsx")
app = create_app({"DATABASE": path, "PORTAL_PASSWORD": "adminpass1", "TESTING": True,
                  "PORTAL_OPERATOR_USER": "ops", "PORTAL_OPERATOR_PASSWORD": "operpass1"})
ok = []
def check(c, m): print(("PASS " if c else "FAIL ") + m); ok.append(c)
conn = db.STORE.conn
setting = lambda k: conn.execute("SELECT value FROM settings WHERE key=?", (k,)).fetchone()[0]

admin = app.test_client(); hp.login(admin, "admin", "adminpass1")
op = app.test_client(); r = hp.login(op, "ops", "operpass1")
check(r.status_code == 302, "operator created from .env on first start can sign in")
check(app.test_client().post("/login", data={"csrf_token": "x", "username": "ops", "password": "operpass1"}).status_code == 400, "login without CSRF refused")
check(conn.execute("SELECT role FROM users WHERE username='ops'").fetchone()[0] == "operator", "role = operator")
check("operpass1" not in open(path, "rb").read().decode("latin1") and conn.execute("SELECT password_hash FROM users WHERE username='ops'").fetchone()[0].startswith(("scrypt:", "pbkdf2:")), "passwords stored hashed")

# --- admin configures; secrets protected
r = hp.configure(admin, 9999)
check("MyWizard connection saved" in r.text, "admin saves the connection")
check(hp.TOKEN not in r.text and hp.WL not in r.text, "secret values never shown back to the admin")
check(hp.TOKEN not in admin.get("/admin/mywizard").text and "set - leave blank" in admin.get("/admin/mywizard").text, "admin page shows 'set', not the value")
wb = load_workbook(path); blob = " ".join(str(c.value) for ws in wb for row in ws.iter_rows() for c in row if c.value)
check(hp.TOKEN not in blob and hp.WL not in blob and "enc:" in blob, "workbook holds the secrets encrypted only")
R = Rules(conn); cfg = mywizard.load(R, app.config["SECRET_KEY"])
check(dict((n, v) for n, v, _ in cfg["HEADERS"])["Authorization"] == hp.TOKEN, "decrypts correctly for use")
hp.configure(admin, 9999, extra={"h_value": ["application/json", "application/json", "", ""]})   # blank secrets = keep
cfg = mywizard.load(Rules(conn), app.config["SECRET_KEY"])
check(dict((n, v) for n, v, _ in cfg["HEADERS"])["X-WL-AUTH"] == hp.WL, "blank secret on re-save keeps the stored value")
hp.configure(admin, 9999, extra={"h_value": ["application/json", "application/json", "new-wl", ""]})
cfg = mywizard.load(Rules(conn), app.config["SECRET_KEY"])
check(dict((n, v) for n, v, _ in cfg["HEADERS"])["X-WL-AUTH"] == "new-wl", "typing a value replaces it")
check(mywizard.load(Rules(conn), "a-different-secret-key")["UNREADABLE"] == ["X-WL-AUTH", "Authorization"], "wrong key => flagged unreadable, not garbage")
hp.configure(admin, 9999)

# --- operator is locked out
for p in ["/admin/mywizard", "/admin/users"]:
    check(op.get(p).status_code == 403, f"operator GET {p} -> 403")
T = hp.csrf(op.get("/config").text)
before = {k: setting(k) for k in ["mw_url", "mw_headers", "close_payload", "dry_run", "mw_fetch_ci", "itsm_impact"]}
for url, data in [("/admin/mywizard/save", {"mw_url": "http://evil/", "h_name": ["X"], "h_value": ["y"]}),
                  ("/admin/mywizard/mode", {"mode": "live", "confirm": "1"}),
                  ("/admin/users/add", {"username": "hack", "password": "hackpass123", "role": "admin"}),
                  ("/admin/users/1/password", {"password": "hackedpass1"}),
                  ("/admin/users/1/delete", {})]:
    check(op.post(url, data={"csrf_token": T, **data}).status_code == 403, f"operator POST {url} -> 403")
op.post("/config/save", data={"csrf_token": T, "mw_url": "http://evil/", "mw_headers": "[]", "close_payload": "{}", "dry_run": "0",
                              "mw_fetch_ci": "x", "itsm_impact": "2 - Medium"})
after = {k: setting(k) for k in before}
check(all(after[k] == before[k] for k in before if k != "itsm_impact") and after["itsm_impact"] == "2 - Medium",
      "crafted /config/save can't touch connection keys or dry_run (but ITSM defaults still editable)")
check(conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 2, "no user was added/removed by the operator")
html = " ".join(op.get(p).text for p in ["/dashboard", "/config", "/incidents", "/incidents/close", "/script-incidents", "/tickets", "/tracker"])
check(hp.TOKEN not in html and hp.WL not in html and "9999" not in html and "enc:" not in html and "mw_headers" not in html, "no connection detail (URL, tokens, ciphertext) in any operator page")
check("/admin/" not in op.get("/dashboard").text, "operator nav has no admin links")
check("/admin/mywizard" in admin.get("/dashboard").text, "admin nav has them")
for p in ["/dashboard", "/intake", "/tracker", "/incidents", "/incidents/close", "/tickets", "/script-incidents", "/config", "/account"]:
    check(op.get(p).status_code == 200, f"operator can use {p}")

# --- user management
T = hp.csrf(admin.get("/admin/users").text)
r = admin.post("/admin/users/add", data={"csrf_token": T, "username": "sam", "password": "short", "role": "operator"}, follow_redirects=True)
check("at least 8" in r.text, "short password refused")
r = admin.post("/admin/users/add", data={"csrf_token": T, "username": "bad name!", "password": "longenough1", "role": "operator"}, follow_redirects=True)
check("Username:" in r.text, "bad username refused")
r = admin.post("/admin/users/add", data={"csrf_token": T, "username": "sam", "password": "longenough1", "role": "operator"}, follow_redirects=True)
check("User 'sam' created as operator" in _html.unescape(r.text), "admin adds an operator")
check("already exists" in admin.post("/admin/users/add", data={"csrf_token": T, "username": "SAM", "password": "longenough1"}, follow_redirects=True).text, "duplicate username (any case) refused")
sam = app.test_client(); check(hp.login(sam, "sam", "longenough1").status_code == 302, "new operator can sign in")
uid = {r_[1]: r_[0] for r_ in conn.execute("SELECT id, username FROM users")}
check("You can't delete the account" in _html.unescape(admin.post(f"/admin/users/{uid['admin']}/delete", data={"csrf_token": T}, follow_redirects=True).text), "admin can't delete themselves")
admin.post("/admin/users/add", data={"csrf_token": T, "username": "boss2", "password": "longenough1", "role": "admin"})
boss = app.test_client(); hp.login(boss, "boss2", "longenough1")
Tb = hp.csrf(boss.get("/admin/users").text)
boss.post(f"/admin/users/{uid['admin']}/delete", data={"csrf_token": Tb})
b2 = {r_[1]: r_[0] for r_ in conn.execute("SELECT id, username FROM users")}
check("admin" not in b2, "another admin can delete the first admin")
check("You can't delete the account" in _html.unescape(boss.post(f"/admin/users/{b2['boss2']}/delete", data={"csrf_token": Tb}, follow_redirects=True).text)
      and conn.execute("SELECT COUNT(*) FROM users WHERE role='admin'").fetchone()[0] == 1, "the last admin can't remove themselves, so an admin always exists")
conn.execute("UPDATE users SET role='operator' WHERE username='ops'"); conn.commit()
# session of a deleted user dies immediately
Tb = hp.csrf(boss.get("/admin/users").text)
boss.post(f"/admin/users/{b2['sam']}/delete", data={"csrf_token": Tb})
check(sam.get("/dashboard").status_code == 302 and "/login" in sam.get("/dashboard").location, "deleted user's open session is ended")
boss.post(f"/admin/users/{b2['ops']}/password", data={"csrf_token": Tb, "password": "resetpass12"})
check(hp.login(app.test_client(), "ops", "resetpass12").status_code == 302 and hp.login(app.test_client(), "ops", "operpass1").status_code == 401, "admin password reset works")

# --- own password
op2 = app.test_client(); hp.login(op2, "ops", "resetpass12"); T2 = hp.csrf(op2.get("/account").text)
check("current password is wrong" in op2.post("/account", data={"csrf_token": T2, "current": "nope", "new": "brandnew123", "repeat": "brandnew123"}, follow_redirects=True).text, "wrong current password refused")
check("Password changed" in op2.post("/account", data={"csrf_token": T2, "current": "resetpass12", "new": "brandnew123", "repeat": "brandnew123"}, follow_redirects=True).text, "operator changes own password")
check(hp.login(app.test_client(), "ops", "brandnew123").status_code == 302, "new password works")

# --- restart keeps users and encrypted settings; env passwords no longer matter
app2 = create_app({"DATABASE": path, "PORTAL_PASSWORD": "different-env-pw", "TESTING": True})
c2 = app2.test_client()
check(hp.login(c2, "ops", "brandnew123").status_code == 302 and hp.login(app2.test_client(), "admin", "different-env-pw").status_code == 401, "after restart: users persist; .env password ignored")
check(mywizard.load(Rules(db.STORE.conn), app2.config["SECRET_KEY"])["UNREADABLE"] == [], "encrypted headers still readable after restart")
print("FAILURES:", ok.count(False)); shutil.rmtree(tmp)
