import json, re, threading, http.server, os, sys, tempfile, shutil
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

SAMPLE = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample.txt")).read()
calls = []

closes = []

class H(http.server.BaseHTTPRequestHandler):
    def do_PATCH(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        closes.append((self.path, body, dict(self.headers)))
        self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers()
        self.wfile.write(b"{}")

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        calls.append((dict(self.headers), body))
        self.send_response(201); self.send_header("Content-Type", "application/json"); self.end_headers()
        self.wfile.write(json.dumps({"result": {"number": f"INC90000{len(calls)}"}}).encode())
    def log_message(self, *a): pass

srv = http.server.HTTPServer(("127.0.0.1", 0), H)
threading.Thread(target=srv.serve_forever, daemon=True).start()

tmp = tempfile.mkdtemp()
from portal import create_app
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _helpers as hp
app = create_app({"DATABASE": os.path.join(tmp, "data.xlsx"), "PORTAL_PASSWORD": "pw", "TESTING": True})
c = app.test_client()

def tok(html): return re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)
def check(cond, msg):
    print(("PASS " if cond else "FAIL ") + msg)
    if not cond: check.bad += 1
check.bad = 0

r = c.get("/dashboard"); check(r.status_code == 302 and "/login" in r.location, "dashboard requires login")
t = tok(c.get("/login").text)
r = c.post("/login", data={"csrf_token": t, "username": "admin", "password": "bad"}); check(r.status_code == 401, "bad password rejected")
r = c.post("/login", data={"username": "admin", "password": "pw"}); check(r.status_code == 400, "login without CSRF rejected")
t = tok(c.get("/login").text)
r = c.post("/login", data={"csrf_token": t, "username": "admin", "password": "pw"}); check(r.status_code == 302, "login ok")
r = hp.configure(c, srv.server_port); check("MyWizard connection saved" in r.text, "admin saved the MyWizard connection in the portal")

for p in ["/dashboard", "/intake", "/tracker", "/incidents", "/config"]:
    r = c.get(p); check(r.status_code == 200, f"GET {p} -> {r.status_code}")

t = tok(c.get("/intake").text)
r = c.post("/intake/parse", data={"csrf_token": t, "raw_text": SAMPLE, "default_date": "2026-07-29"})
check(r.status_code == 302, "parse -> redirect"); burl = r.location
r = c.get(burl); check(r.status_code == 200 and "RKH01J02" in r.text and "23941963" in r.text, "review page shows extracted fields")
t = tok(r.text)
ids = re.findall(r'name="include_(\d+)"', r.text)
form = {"csrf_token": t, "then": "incidents"}
for i in ids:
    form[f"include_{i}"] = "1"
    for k in ("app", "root_cause", "action", "date", "category", "assigned_to", "task_text", "comments"):
        m = re.search(rf'name="{k}_{i}"[^>]*value="([^"]*)"', r.text)
        if m: form[f"{k}_{i}"] = m.group(1).replace("&#39;", "'")
    # selects
    for k in ("action", "category"):
        m = re.search(rf'<select name="{k}_{i}".*?</select>', r.text, re.S)
        sel = re.search(r"<option selected>([^<]*)</option>", m.group(0))
        form[f"{k}_{i}"] = sel.group(1) if sel else ""
r = c.post(burl.replace("/intake/batch/", "/intake/batch/") + "/commit", data=form)
check(r.status_code == 302 and "/incidents" in r.location, "commit -> incidents")
r = c.get("/incidents"); check("6 logged abend" in r.text, "incident queue shows 6 rows")
check("BDM | VCD, CDK | Grid issue" in r.text, "grouped short description")

r = c.get("/dashboard?month=2026-07"); check(r.status_code == 200 and "Category summary" in r.text, "dashboard renders data")
r = c.get("/tracker"); check("RKH01J02" in r.text, "tracker lists row")
r = c.get("/export/tracker.xlsx"); check(r.status_code == 200 and r.data[:2] == b"PK", "tracker export xlsx")
r = c.get("/export/abends_data.xlsx"); check(r.data[:2] == b"PK", "abends_data export xlsx")

hdr = {"X-CSRF-Token": tok(c.get("/config").text), "Content-Type": "application/json"}
open_ids = [int(x) for x in re.findall(r'"ids": ?\[([^\]]*)\]', c.get("/incidents").text)[0].split(",")] if False else None
from portal import db, incidents
conn = db.STORE.conn; rows = incidents.open_rows(conn)
ids_ = [r_["id"] for r_ in rows]
r = c.post("/incidents/create", json={"mode": "group", "ids": ids_[:1]}, headers=hdr)
j = r.get_json(); check(j.get("dry_run") is True and not calls, f"dry run sends nothing ({j.get('error')})")

c.post("/admin/mywizard/mode", data={"csrf_token": hdr["X-CSRF-Token"], "mode": "live", "confirm": "1"})
from portal.rules import Rules
check(not Rules(conn).dry_run, "live mode switched on")
# one group = rows sharing key
from portal.rules import Rules as R
items = incidents.build_items(R(conn), rows, "group")
for it in items:
    j = c.post("/incidents/create", json={"mode": "group", "ids": it["ids"]}, headers=hdr).get_json()
    check(j.get("ok") and j["incident_no"].startswith("INC"), f"created {it['label']} -> {j.get('incident_no')} {j.get('error')}")
check(len(calls) == len(items), f"{len(calls)} API calls for {len(items)} groups")
h, body = calls[0]
check(h.get("X-WL-AUTH") == hp.WL and h.get("Authorization") == hp.TOKEN and h.get("Accept") == "application/json" and h.get("Content-Type") == "application/json", "curl-style headers sent")
check("X-API-Key" not in h and "Message-Id" not in h, "no X-API-Key / Message-Id")
check(list(body)[:3] == ["short_description", "description", "category"] and "caller_id" not in body, "payload keys/order, no caller_id")
j = c.post("/incidents/create", json={"mode": "group", "ids": items[0]["ids"]}, headers=hdr).get_json()
check(not j["ok"] and len(calls) == len(items), "second create of same rows refused (no twin)")
check("INC9" in c.get("/tracker").text, "incident numbers on tracker")

# ---------------- tickets / bulk close
from portal import tickets
r = c.get("/tickets"); check(all(f"INC90000{i}" in r.text for i in (1, 2, 3)), "created incidents recorded as tickets")
csv_data = ("Number,Short description,State,Opened,Closed,Assignment group\n"
            "RITM0010001,Access request,Open,2026-10-01 09:00:00,,ETL\n"
            "RITM0010002,Laptop,Closed Complete,2026-09-20 09:00:00,2026-10-18 10:00:00,IT\n"
            "INC0099001,Old incident,In Progress,2026-09-01 09:00:00,,ETL\n"
            "INC0099002,Done incident,Resolved,2026-09-01 09:00:00,%s 08:00:00,ETL\n")
from datetime import date
csv_data = csv_data % date.today().isoformat()
import io
r = c.post("/tickets/import", data={"csrf_token": hdr["X-CSRF-Token"], "file": (io.BytesIO(csv_data.encode()), "ex.csv")},
           content_type="multipart/form-data", follow_redirects=True)
check("Imported 4 ticket(s): 4 new" in r.text, "CSV import (INC + RITM)")
r = c.get("/dashboard?month=2026-07")
check("Open RITMs" in r.text and "RITM0010001" in r.text and "INC0099001" in r.text and "INC0099002" in r.text, "dashboard shows open/closed INC + RITM")
tk = tickets.dashboard_block(conn)
check(tk["ritm"]["open_n"] == 1 and tk["ritm"]["closed_n"] == 1 and tk["inc"]["open_n"] == 4 and tk["inc"]["closed_recent_n"] == 1,
      f"counts: {tk['inc']['open_n']} open INC, {tk['ritm']['open_n']} open RITM")

fields = {"state": "Resolved", "resolution_code": "Solved (Permanently)", "close_notes": "Rerun ok for {number} on {date}"}
c.post("/admin/mywizard/mode", data={"csrf_token": hdr["X-CSRF-Token"], "mode": "dry"})
j = c.post("/incidents/close/run", json={"number": "INC900001", **fields}, headers=hdr).get_json()
check(j.get("dry_run") and j["payload"]["number"] == "INC900001" and j["payload"]["close_code"] == "Solved (Permanently)" and not closes,
      "dry-run close previews payload, sends nothing")
c.post("/admin/mywizard/mode", data={"csrf_token": hdr["X-CSRF-Token"], "mode": "live", "confirm": "1"})
nums = ["INC900001", "INC900002", "INC900003", "INC0099001"]
res = [c.post("/incidents/close/run", json={"number": n, **fields}, headers=hdr).get_json() for n in nums]
check(all(x["ok"] for x in res) and len(closes) == 4, f"bulk close live: {len(closes)} PATCH calls")
path, body, h = closes[0]
check(path == "/close/INC900001" and body["close_notes"].startswith("Rerun ok for INC900001 on ") and "caller_id" not in body
      and h.get("X-WL-AUTH") == hp.WL, "close URL/payload/headers correct")
j = c.post("/incidents/close/run", json={"number": "INC900001", **fields}, headers=hdr).get_json()
check(not j["ok"] and len(closes) == 4, "closing an already-closed incident is refused")
j = c.post("/incidents/close/run", json={"number": "INC900001", "state": "", "resolution_code": "", "close_notes": ""}, headers=hdr).get_json()
check(not j["ok"], "close requires state, code and notes")
tk = tickets.dashboard_block(conn)
check(tk["inc"]["open_n"] == 0 and tk["inc"]["closed_recent_n"] == 5, "dashboard counts after closing")
c.post("/incidents/close/template", data={"csrf_token": hdr["X-CSRF-Token"], "name": "Grid rerun", "resolution_code": "X", "state": "Resolved", "close_notes": "n"})
check("Grid rerun" in c.get("/incidents/close").text, "template saved")
bad = hp.configure(c, srv.server_port, extra={"close_payload": "{not json"})
check("not valid JSON" in bad.text, "invalid close payload rejected on Config")

# data survives a restart (it is all in the workbook)
n = conn.execute("SELECT COUNT(*) FROM abends WHERE incident_no LIKE 'INC9%'").fetchone()[0]
app2 = create_app({"DATABASE": os.path.join(tmp, "data.xlsx"), "PORTAL_PASSWORD": "pw", "TESTING": True})
n2 = db.STORE.conn.execute("SELECT COUNT(*) FROM abends WHERE incident_no LIKE 'INC9%'").fetchone()[0]
st2 = db.STORE
check(st2.conn.execute("SELECT COUNT(*) FROM root_causes").fetchone()[0] == 8, "all 8 root causes survive a restart")
check(st2.conn.execute("SELECT COUNT(*) FROM staging").fetchone()[0] == conn.execute("SELECT COUNT(*) FROM staging").fetchone()[0] > 0, "staging rows survive a restart")
check(st2.load_notes == [], f"nothing skipped while loading: {st2.load_notes}")
check(st2.conn.execute("SELECT COUNT(*) FROM tickets").fetchone()[0] == conn.execute("SELECT COUNT(*) FROM tickets").fetchone()[0], "tickets survive a restart")
check(n == 6 and n2 == 6, f"data reloaded from the workbook after restart ({n2} rows with incident numbers)")
check(sorted(f for f in os.listdir(tmp)) == ["data.xlsx"], f"only the workbook on disk: {os.listdir(tmp)}")
print("FAILURES:", check.bad)
shutil.rmtree(tmp)
