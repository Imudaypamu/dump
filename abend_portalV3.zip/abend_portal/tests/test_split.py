"""Mixed run: some groups as one incident, one group split into one incident per task."""
import json, os, sys, tempfile, threading, http.server, shutil
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
calls = []
class H(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        calls.append(json.loads(self.rfile.read(int(self.headers["Content-Length"]))))
        self.send_response(201); self.end_headers(); self.wfile.write(json.dumps({"number": f"INC7{len(calls):05d}"}).encode())
    def log_message(self, *a): pass
srv = http.server.HTTPServer(("127.0.0.1", 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
tmp = tempfile.mkdtemp()
from portal import create_app, db, incidents, intake
from portal.rules import Rules
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _helpers as hp
app = create_app({"DATABASE": os.path.join(tmp, "d.xlsx"), "PORTAL_PASSWORD": "pw", "TESTING": True})
cl = app.test_client(); hp.login(cl); hp.configure(cl, srv.server_port)
conn = db.STORE.conn
txt = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample.txt")).read()
bid = intake.create_batch(conn, Rules(conn), txt, "2026-07-29"); intake.commit(conn, Rules(conn), bid)
conn.execute("UPDATE abends SET incident_status='pending'"); conn.commit()
conn.execute("UPDATE settings SET value='0' WHERE key='dry_run'"); conn.commit()
from portal import mywizard
R = Rules(conn); cfg = mywizard.load(R, app.config["SECRET_KEY"])
items = incidents.build_items(R, incidents.open_rows(conn), "group")
ok = []
def check(c, m): print(("PASS " if c else "FAIL ") + m); ok.append(c)
check(len(items) == 3, f"{len(items)} groups")
big = max(items, key=lambda i: i["count"])
check(set(big["row_payloads"]) == {str(i) for i in big["ids"]}, "row payloads for every task in the group")
check(all(p["short_description"].count("|") == 2 for p in big["row_payloads"].values()), "row payload has per-task short description")
with app.app_context():
    for it in items:
        if it is big:
            for i in it["ids"]:
                r = incidents.create_incident(conn, R, cfg, "row", [i]); check(r["ok"], f"split task {i} -> {r.get('incident_no')}")
        else:
            r = incidents.create_incident(conn, R, cfg, "group", it["ids"]); check(r["ok"], f"grouped -> {r.get('incident_no')}")
n_expected = big["count"] + 2
check(len(calls) == n_expected, f"{len(calls)} API calls (= {big['count']} split + 2 grouped)")
check(incidents.open_rows(conn) == [], "queue empty afterwards")
nums = [r[0] for r in conn.execute("SELECT DISTINCT incident_no FROM abends")]
check(len(nums) == n_expected, f"{len(nums)} distinct incident numbers on the tracker")
print("FAILURES:", ok.count(False)); shutil.rmtree(tmp)
