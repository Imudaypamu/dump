"""WSGI entry point.

  Windows / Linux:  waitress-serve --listen=127.0.0.1:5000 wsgi:application
  Linux:            gunicorn -w 1 --threads 4 -b 127.0.0.1:5000 wsgi:application

IMPORTANT: run exactly ONE worker process. The portal keeps the data workbook in memory,
so several worker processes would overwrite each other's changes.
"""
from portal import create_app

application = create_app()
app = application  # some hosts look for `app`
