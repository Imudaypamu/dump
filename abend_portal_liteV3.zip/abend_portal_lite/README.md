# Abend desk Lite

The same portal without MyWizard: dashboard, raw intake, tracker, incidents (recorded by hand), config and users.
No API details are needed anywhere.

## Setup (Windows or Linux, Python 3.10+)
```
pip install -r requirements.txt
copy .env.example .env        (cp on Linux)  -> set PORTAL_USER / PORTAL_PASSWORD (and optionally PORTAL_OPERATOR_*)
python run.py                 # http://127.0.0.1:5000
```
`data/Abend_Portal_Data.xlsx` ships pre-loaded with your history. There is no database and no other setup.

## Daily flow
1. **Raw intake**: paste the text (tab separated: app, task text, root cause, action, date, category).
2. **Review**: every extracted field (task, process, run id, alert, issue type, platform, short description) is shown and
   editable. Unknown root causes can be added in one click; duplicates are unticked. **Discard batch** (or **Undo
   logging** once logged) is in the batch list and on the review page.
3. **Log ticked rows**: they appear on the Tracker and Dashboard.
4. **Record incidents**: you create each incident in ServiceNow yourself, then record its number here.
   * **Fields** opens a window with every field to paste (short description, description, category, subcategory,
     configuration item, assignment group, impact, urgency, close notes, resolution code, application, root cause,
     action taken), each with a Copy button, or **Copy everything**.
   * Shapes: grouped (category + issue type + action), one per abend, or a mix (tick **One per task** on any group, or
     *Split every group*). **Download as Excel** gives one row per incident with all those fields and an empty
     "Incident number" column.
   * Type the number(s) and press **Save numbers**. Numbers are checked (letters then digits, e.g. INC1234567),
     normalised (`inc 123` -> `INC...`) and applied to every abend in that incident. It is all-or-nothing: if any
     number is wrong nothing is saved, and the bad box is highlighted.
   * One incident number for several incidents: tick them, type the number, **Use for selected**, then Save (the
     "same number is intended" box is ticked for you). A number already used somewhere else is refused unless you tick it.
   * **No incident needed for selected** takes rows off the list; they stay on the dashboard and show "no incident".
   * Change or clear a number later with **Edit** in the Tracker (clearing it puts the row back in the list).

## Dashboard (broad analysis of abends)
Responsive: three cards across on wide screens, two on tablets, one on phones; the menu becomes a scrolling top bar on small
screens; wide tables scroll sideways with their first column pinned; charts redraw to their card's width.

Filters: month, from/to, +-7 days, issue scope, category, application. Everything below follows them.
* **Key figures** (12): total with **change vs the previous period** (the same number of days just before), average per
  day, distinct tasks, applications hit, **repeat rate**, grid share, **top-10 tasks' share**, **top-3 apps' share**,
  **weekend share**, top category, top root cause, busiest weekday and date.
* **Trend**: daily abends with a 7-day moving average (weekly when the range is long), and a **running total against the
  previous period**, day by day.
* **When failures happen**: a weekday-by-week calendar heatmap.
* **Mix over time**: category mix and root-cause mix (top 5 + other), per month, or per week when the range is one or
  two months.
* **Breakdowns**: day of week, category, issue group, application, root cause and **top processes**.
* **Tables**: category by issue group, **worst days** (the five busiest dates, with the most-hit app and main cause),
  application by month/week heatmap.
* **What changed**: which applications got worse or better than the previous period.
* **Tasks**: newly failing tasks (first ever failure inside the range), repeat offenders (with longest streak of
  consecutive days and average days between failures), category summary (BDM / PWC / CLOUD with the EMR Spark and Glue
  split underneath) and top tasks per category.
* A note lists root causes found in the data that aren't in Config yet.
* There is deliberately no action-taken analysis.

## Users
* **admin**: everything, plus the **Users** page (add users, reset passwords, delete).
* **operator**: everything except the Users page.
* The admin (and an optional operator) are created from `.env` on the very first start. After that, users are managed on
  the Users page and the `.env` passwords are ignored. Everyone can change their own password under their name.
* Sign-in locks out an address for 5 minutes after 5 wrong passwords.

## Production (WSGI)
`wsgi.py` exposes `application`. Always ONE worker (the data is held in memory):
```
waitress-serve --listen=127.0.0.1:5000 wsgi:application          # Windows or Linux
gunicorn -w 1 --threads 4 -b 127.0.0.1:5000 wsgi:application      # Linux only
```
Put HTTPS (IIS / nginx / Caddy) in front and set SESSION_COOKIE_SECURE=true.

## Where the data lives
No database. Everything is in `data/Abend_Portal_Data.xlsx` (sheets Abends, Root Causes, Applications, Settings, Users,
Batches, Staging), rewritten after every change. Back it up by copying it. Don't edit it by hand while the portal is
running. If Excel has it open, the portal shows a red banner and saves on the next change once you close it.

## Tests
`python tests/test_smoke.py`, `test_incidents_manual.py`, `test_dashboard.py`, `test_users.py`, `test_batches.py`.
Optional, with a browser installed (`pip install playwright`, `playwright install chromium`): `python tests/check_responsive.py http://127.0.0.1:5000 admin <password>` loads every page at eight screen widths and reports overflow.
