"""Everything the dashboard shows, computed from the abends table in one call.

Beyond the original Excel dashboard (month / weekday / app / issue type / category / top tasks) this adds:
period-over-period change (with a cumulative comparison line), a 7-day moving average, category and root-cause
mix over time, a weekday x week calendar, concentration (how few tasks/apps cause most abends), top processes,
worst days, category x issue-group matrix, an application x month/week heatmap, "what changed" per application, newly failing tasks,
repeat rate, and a list of root causes that aren't in Config yet.
"""
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta

from .rules import CATEGORIES, ISSUE_TYPES, PLATFORMS, Rules, norm

WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def _d(s):
    return datetime.strptime(s, "%Y-%m-%d").date()


def month_bounds(ym: str):
    y, m = int(ym[:4]), int(ym[5:7])
    first = date(y, m, 1)
    nxt = date(y + (m == 12), (m % 12) + 1, 1)
    return first, nxt - timedelta(days=1)


def resolve_range(filters: dict, all_dates: list):
    """Month dropdown / From / To / +-7 days, exactly as the Excel controls behaved."""
    months = sorted({d[:7] for d in all_dates})
    month = filters.get("month") or (months[-1] if months else "All Months")
    lo, hi = filters.get("from"), filters.get("to")
    if not lo or not hi:
        if month != "All Months" and month in months:
            f, l = month_bounds(month)
        elif all_dates:
            f, l = _d(min(all_dates)), _d(max(all_dates))
        else:
            f = l = date.today()
        lo, hi = lo or f.isoformat(), hi or l.isoformat()
    buffer = filters.get("buffer") == "Yes"
    eff_lo, eff_hi = _d(lo), _d(hi)
    if buffer:
        eff_lo -= timedelta(days=7)
        eff_hi += timedelta(days=7)
    return {"month": month, "months": months, "from": lo, "to": hi, "buffer": buffer,
            "eff_from": eff_lo.isoformat(), "eff_to": eff_hi.isoformat()}


def _ranked(counter: Counter, limit=None):
    items = sorted(counter.items(), key=lambda kv: (-kv[1], str(kv[0]).lower()))
    return items[:limit] if limit else items


def _change(cur, prev):
    """% change vs the previous period (None when there is nothing to compare with)."""
    return None if not prev else (cur - prev) / prev * 100


def _task_key(r):
    return norm(r["task_name"]) or norm(r["task_text"])


def compute(conn, rules: Rules, filters: dict) -> dict:
    all_rows = [dict(r) for r in conn.execute("SELECT * FROM abends ORDER BY date, id")]
    rng = resolve_range(filters, [r["date"] for r in all_rows])
    scope = filters.get("scope") or "all"
    cat_f, app_f = filters.get("category") or "", filters.get("app") or ""

    def select(lo: str, hi: str) -> list:
        out = []
        for r in all_rows:
            if not (lo <= r["date"] <= hi):
                continue
            r = dict(r)
            r["issue_type_dash"] = rules.dashboard_issue_type(r["root_cause"])
            if scope == "grid" and r["issue_type_dash"] != "Grid Issue":
                continue
            if cat_f and r["category"] != cat_f:
                continue
            if app_f and norm(r["app"]) != norm(app_f):
                continue
            r["group"] = rules.issue_type(r["root_cause"])
            r["weekday"] = WEEKDAYS[_d(r["date"]).weekday()]
            r["month"] = r["date"][:7]
            r["week"] = (_d(r["date"]) - timedelta(days=_d(r["date"]).weekday())).isoformat()
            r["platform"] = rules.platform(r["category"], r["app"], r["task_name"])
            out.append(r)
        return out

    lo, hi = _d(rng["eff_from"]), _d(rng["eff_to"])
    rows = select(rng["eff_from"], rng["eff_to"])
    n_days = (hi - lo).days + 1
    prev_hi = lo - timedelta(days=1)
    prev_lo = prev_hi - timedelta(days=n_days - 1)
    prev_rows = select(prev_lo.isoformat(), prev_hi.isoformat())

    total, prev_total = len(rows), len(prev_rows)
    by_month = Counter(r["month"] for r in rows)
    by_day = Counter(r["weekday"] for r in rows)
    by_app = Counter(r["app"] for r in rows)
    by_cat = Counter(r["category"] for r in rows)
    by_type = Counter(r["issue_type_dash"] for r in rows)
    by_group = Counter(r["group"] for r in rows)
    by_date = Counter(r["date"] for r in rows)
    by_task = Counter(_task_key(r) for r in rows)

    def top(counter):
        if not counter:
            return ("-", 0)
        return _ranked(counter)[0]

    elapsed = max(1, (min(hi, date.today()) - lo).days + 1)
    repeat_rows = sum(c for c in by_task.values() if c > 1)

    # ---- trend: daily (+ 7-day moving average) or weekly when the range is long
    trend, trend_unit = [], "day"
    if rows:
        # the whole selected range (quiet days included), but not days that haven't happened yet
        first = lo
        last = min(hi, max(date.today(), _d(max(by_date))))
        if (last - first).days <= 400:
            vals = [by_date.get((first + timedelta(days=i)).isoformat(), 0) for i in range((last - first).days + 1)]
            for i, v in enumerate(vals):
                window = vals[max(0, i - 6): i + 1]
                trend.append({"label": (first + timedelta(days=i)).isoformat(), "value": v,
                              "ma": round(sum(window) / len(window), 2)})
        else:
            trend_unit = "week"
            wk = Counter()
            for d, c in by_date.items():
                dd = _d(d)
                wk[(dd - timedelta(days=dd.weekday())).isoformat()] += c
            trend = [{"label": k, "value": v} for k, v in sorted(wk.items())]

    # ---- columns for the mix chart and the heatmap: months, or weeks when the range is only one or two months
    months = sorted(by_month)
    unit = "week" if len(months) <= 2 else "month"
    cols = sorted({r[unit] for r in rows})[-12:]
    mix = {"unit": unit, "labels": cols,
           "series": [{"name": c, "values": [sum(1 for r in rows if r[unit] == col and r["category"] == c) for col in cols]}
                      for c in CATEGORIES]}

    # ---- matrices
    def matrix(cols, key):
        body = []
        for c in CATEGORIES:
            cells = [sum(1 for r in rows if r["category"] == c and r[key] == col) for col in cols]
            body.append({"label": c, "cells": cells, "total": sum(cells)})
        col_totals = [sum(b["cells"][i] for b in body) for i in range(len(cols))]
        mx = max([x for b in body for x in b["cells"]] or [0])
        return {"cols": cols, "rows": body, "col_totals": col_totals, "total": sum(col_totals), "max": mx}

    cat_group = matrix(ISSUE_TYPES, "group")

    # ---- application x month (or week) heatmap, top 15 applications
    hm_apps = [a for a, _ in _ranked(Counter(r["app"] for r in rows if r[unit] in cols), 15)]
    cell = Counter((r["app"], r[unit]) for r in rows)
    heat = {"unit": unit, "cols": cols, "max": max([cell[(a, m)] for a in hm_apps for m in cols] or [0]),
            "rows": [{"app": a, "cells": [cell[(a, m)] for m in cols], "total": sum(cell[(a, m)] for m in cols)}
                     for a in hm_apps]}

    # ---- cumulative abends this period vs the previous one (day by day)
    cur_day, prev_day = Counter(r["date"] for r in rows), Counter(r["date"] for r in prev_rows)
    upto = max(1, min(n_days, (min(hi, max(date.today(), _d(max(by_date)) if by_date else date.today())) - lo).days + 1))
    compare, cc, pc = [], 0, 0
    for i in range(upto):
        cc += cur_day.get((lo + timedelta(days=i)).isoformat(), 0)
        pc += prev_day.get((prev_lo + timedelta(days=i)).isoformat(), 0)
        compare.append({"label": f"Day {i + 1}", "date": (lo + timedelta(days=i)).isoformat(), "cur": cc, "prev": pc})

    # ---- calendar: weekday x week (last 26 weeks of the range)
    weeks = sorted({r["week"] for r in rows})[-26:]
    cal_cell = Counter((r["weekday"], r["week"]) for r in rows)
    calendar = {"weeks": weeks, "max": max([cal_cell[(d, w)] for d in WEEKDAYS for w in weeks] or [0]),
                "rows": [{"day": d, "cells": [cal_cell[(d, w)] for w in weeks], "total": sum(cal_cell[(d, w)] for w in weeks)}
                         for d in WEEKDAYS]}

    # ---- concentration + processes + worst days
    ranked_tasks = _ranked(by_task)
    top10_share = (sum(c for _, c in ranked_tasks[:10]) / total * 100) if total else 0
    top3_apps_share = (sum(c for _, c in _ranked(by_app)[:3]) / total * 100) if total else 0
    weekend_share = ((by_day.get("Sat", 0) + by_day.get("Sun", 0)) / total * 100) if total else 0
    by_process = Counter(r["process"] for r in rows if r["process"])
    worst_days = []
    for d, n in _ranked(by_date, 5):
        day_rows = [r for r in rows if r["date"] == d]
        worst_days.append({"date": d, "weekday": WEEKDAYS[_d(d).weekday()], "count": n,
                           "apps": len({r["app"] for r in day_rows}),
                           "top_app": _ranked(Counter(r["app"] for r in day_rows))[0][0],
                           "top_cause": _ranked(Counter(r["issue_type_dash"] for r in day_rows))[0][0]})

    # ---- root cause mix over time (top 5 causes + other), same columns as the category mix
    top_causes = [k for k, _ in _ranked(by_type, 5)]
    cause_series = [{"name": k, "values": [sum(1 for r in rows if r[unit] == col and r["issue_type_dash"] == k) for col in cols]}
                    for k in top_causes]
    if len(by_type) > len(top_causes):
        cause_series.append({"name": "Other", "values": [sum(1 for r in rows if r[unit] == col and r["issue_type_dash"] not in top_causes)
                                                         for col in cols]})
    cause_mix = {"unit": unit, "labels": cols, "series": cause_series}

    # ---- what changed vs the previous period, per application
    prev_app = Counter(r["app"] for r in prev_rows)
    deltas = []
    for a in set(by_app) | set(prev_app):
        cur, prv = by_app.get(a, 0), prev_app.get(a, 0)
        if cur != prv:
            deltas.append({"app": a, "cur": cur, "prev": prv, "delta": cur - prv, "pct": _change(cur, prv)})
    up = sorted([x for x in deltas if x["delta"] > 0], key=lambda x: (-x["delta"], x["app"].lower()))[:6]
    down = sorted([x for x in deltas if x["delta"] < 0], key=lambda x: (x["delta"], x["app"].lower()))[:6]
    changes = {"up": up, "down": down, "prev_from": prev_lo.isoformat(), "prev_to": prev_hi.isoformat(),
               "prev_total": prev_total}

    # ---- tasks that never failed before this range
    first_seen = {}
    for r in all_rows:
        first_seen.setdefault(_task_key(r), r["date"])
    new_tasks = []
    has_history = bool(all_rows) and rng["eff_from"] > min(r["date"] for r in all_rows)
    if has_history:
        meta = {}
        for r in rows:
            meta.setdefault(_task_key(r), r)
        new_tasks = [{"task": meta[k]["task_name"] or meta[k]["task_text"], "app": meta[k]["app"],
                      "category": meta[k]["category"], "first": first_seen[k], "count": c}
                     for k, c in _ranked(by_task) if first_seen[k] >= rng["eff_from"]][:10]

    # ---- top tasks per category + repeat offenders
    top_tasks = {}
    for cat in ("BDM", "CLOUD", "PWC"):
        c, meta = Counter(), {}
        for r in rows:
            if r["category"] == cat:
                k = _task_key(r)
                c[k] += 1
                meta.setdefault(k, (r["task_name"] or r["task_text"], r["process"], r["app"]))
        top_tasks[cat] = [{"task": meta[k][0], "process": meta[k][1], "app": meta[k][2], "count": v}
                          for k, v in _ranked(c, 50)]
    rep_meta, rep_days = {}, defaultdict(set)
    for r in rows:
        k = _task_key(r)
        rep_meta.setdefault(k, r)
        rep_days[k].add(r["date"])
    def streak_gap(days):
        ds = sorted(_d(x) for x in days)
        best = run = 1
        for a, b in zip(ds, ds[1:]):
            run = run + 1 if (b - a).days == 1 else 1
            best = max(best, run)
        gap = round((ds[-1] - ds[0]).days / (len(ds) - 1), 1) if len(ds) > 1 else None
        return best, gap

    repeat = []
    for k, v in _ranked(by_task, 10):
        if v < 2:
            continue
        streak, gap = streak_gap(rep_days[k])
        repeat.append({"task": rep_meta[k]["task_name"] or rep_meta[k]["task_text"], "app": rep_meta[k]["app"],
                       "category": rep_meta[k]["category"], "count": v, "days": len(rep_days[k]), "streak": streak, "gap": gap})

    # ---- category summary (platform split shown underneath, derived)
    notes = {name: stack for name, stack, _ in PLATFORMS}
    cat_total = sum(by_cat.values())
    cat_summary = []
    for cat in CATEGORIES:
        crow = [r for r in rows if r["category"] == cat]
        cm = Counter(r["month"] for r in crow)
        plats = Counter(r["platform"] for r in crow)
        parts = []
        if any(p.lower() != cat.lower() for p in plats):
            parts = [{"platform": p, "stack": notes.get(p, ""), "count": c} for p, c in _ranked(plats)]
        cat_summary.append({"category": cat, "count": len(crow), "pct": (len(crow) / cat_total * 100) if cat_total else 0,
                            "peak": _ranked(cm)[0][0] if cm else "-",
                            "apps": ", ".join(sorted({r["app"] for r in crow}, key=str.lower)), "parts": parts})

    unconfigured = _ranked(Counter(r["root_cause"] for r in rows if not rules.root_cause_row(r["root_cause"])), 8)

    return {
        "range": rng,
        "filters": {"scope": scope, "category": cat_f, "app": app_f},
        "kpis": {
            "total": total, "prev_total": prev_total, "delta_pct": _change(total, prev_total),
            "unique_apps": len(by_app), "distinct_tasks": len(by_task),
            "avg_per_day": round(total / elapsed, 1), "active_days": len(by_date), "days": n_days,
            "repeat_pct": (repeat_rows / total * 100) if total else 0,
            "top_issue": top(by_type), "top_category": top(by_cat),
            "busiest_weekday": top(by_day), "busiest_date": top(by_date),
            "grid_pct": (by_group.get("Grid Issue", 0) / total * 100) if total else 0,
            "grid_n": by_group.get("Grid Issue", 0),
            "top10_share": top10_share, "top3_apps_share": top3_apps_share, "weekend_share": weekend_share,
        },
        "by_month": [{"label": k, "value": by_month[k]} for k in months],
        "by_day": [{"label": d, "value": by_day.get(d, 0)} for d in WEEKDAYS],
        "by_app": [{"label": k, "value": v} for k, v in _ranked(by_app)],
        "by_category": [{"label": k, "value": v} for k, v in _ranked(by_cat)],
        "by_type": [{"label": k, "value": v} for k, v in _ranked(by_type)],
        "by_group": [{"label": g, "value": by_group[g]} for g in ISSUE_TYPES if by_group.get(g)],
        "trend": trend, "trend_unit": trend_unit, "mix": mix, "cause_mix": cause_mix, "compare": compare,
        "calendar": calendar, "worst_days": worst_days,
        "by_process": [{"label": k, "value": v} for k, v in _ranked(by_process)],
        "cat_group": cat_group, "heat": heat, "changes": changes,
        "new_tasks": new_tasks, "has_history": has_history,
        "top_tasks": top_tasks, "repeat": repeat, "cat_summary": cat_summary, "unconfigured": unconfigured,
        "apps_all": sorted({r["app"] for r in all_rows}, key=str.lower),
    }
