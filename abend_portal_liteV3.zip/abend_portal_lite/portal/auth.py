"""Users and roles.

  admin     everything, including user management (add users, reset passwords, delete)
  operator  everything else (dashboard, intake, tracker, incidents, config tables) but cannot manage users

Users live in the workbook (Users sheet, password hashes only). The very first start creates the admin from
PORTAL_USER / PORTAL_PASSWORD in .env (and, optionally, an operator from PORTAL_OPERATOR_USER / _PASSWORD);
after that users are managed on the Users page and the .env passwords are no longer used.
"""
import hmac
import re
import secrets
import time
from functools import wraps

from flask import (Blueprint, abort, current_app, flash, g, redirect, render_template, request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

from .db import get_db, now

bp = Blueprint("auth", __name__)

MAX_FAILS = 5
LOCK_SECONDS = 300
MIN_PASSWORD = 8
USERNAME_RE = re.compile(r"^[A-Za-z0-9._-]{3,40}$")
_fails = {}  # ip -> [count, locked_until]
_DUMMY_HASH = generate_password_hash("not-a-real-password")


def ensure_users(conn, cfg) -> bool:
    """First start only: create the admin (and optional operator) from .env. True if users were created."""
    if conn.execute("SELECT 1 FROM users LIMIT 1").fetchone():
        return False

    def hashed(plain_key, hash_key):
        return cfg.get(hash_key) or (generate_password_hash(cfg[plain_key]) if cfg.get(plain_key) else "")

    admin_hash = hashed("PORTAL_PASSWORD", "PORTAL_PASSWORD_HASH")
    if not admin_hash:
        raise RuntimeError(
            "No admin password configured. Copy .env.example to .env and set PORTAL_PASSWORD "
            "(or PORTAL_PASSWORD_HASH from `python manage.py hash-password`). It is only used on the first start.")
    conn.execute("INSERT INTO users(username, password_hash, role, created_at) VALUES(?,?,?,?)",
                 (cfg["PORTAL_USER"], admin_hash, "admin", now()))
    op_user = (cfg.get("PORTAL_OPERATOR_USER") or "").strip()
    op_hash = hashed("PORTAL_OPERATOR_PASSWORD", "PORTAL_OPERATOR_PASSWORD_HASH")
    if op_user and op_hash and op_user.lower() != cfg["PORTAL_USER"].lower():
        conn.execute("INSERT INTO users(username, password_hash, role, created_at) VALUES(?,?,?,?)",
                     (op_user, op_hash, "operator", now()))
    conn.commit()
    return True


def init_auth(app):
    app.register_blueprint(bp)
    app.jinja_env.globals["csrf_token"] = csrf_token

    @app.before_request
    def gate():
        g.role, g.user = None, None
        if request.endpoint in (None, "static"):
            return None
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            sent = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token") or ""
            good = session.get("csrf", "")
            if not good or not hmac.compare_digest(sent, good):
                abort(400, "Missing or invalid CSRF token. Reload the page and try again.")
        if request.endpoint == "auth.login":
            return None
        row = None
        if session.get("user"):
            row = get_db().execute("SELECT username, role FROM users WHERE username=?", (session["user"],)).fetchone()
        if not row:   # not signed in, or the account was deleted while signed in
            session.clear()
            if request.accept_mimetypes.best == "application/json" or request.is_json:
                return {"ok": False, "error": "Session expired - sign in again."}, 401
            return redirect(url_for("auth.login", next=request.full_path.rstrip("?")))
        g.user, g.role = row["username"], row["role"]
        return None

    @app.after_request
    def headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "same-origin"
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; "
            "img-src 'self' data:; form-action 'self'; frame-ancestors 'none'"
        )
        resp.headers["Cache-Control"] = "no-store"
        return resp


def admin_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if g.get("role") != "admin":
            if request.is_json or request.accept_mimetypes.best == "application/json":
                return {"ok": False, "error": "Only an admin can do that."}, 403
            return render_template("error.html", code=403, message="Only an admin can open this page."), 403
        return fn(*a, **kw)
    return wrapper


def csrf_token() -> str:
    if "csrf" not in session:
        session["csrf"] = secrets.token_urlsafe(32)
    return session["csrf"]


def _safe_next(target: str) -> str:
    if target and target.startswith("/") and not target.startswith("//") and "\\" not in target:
        return target
    return url_for("main.dashboard")


@bp.route("/login", methods=["GET", "POST"])
def login():
    ip = request.remote_addr or "?"
    if request.method == "POST":
        count, until = _fails.get(ip, [0, 0])
        if until > time.time():
            flash(f"Too many failed attempts. Try again in {int(until - time.time()) // 60 + 1} minute(s).", "error")
            return render_template("login.html"), 429
        row = get_db().execute("SELECT * FROM users WHERE username=?", (request.form.get("username", "").strip(),)).fetchone()
        good = check_password_hash(row["password_hash"] if row else _DUMMY_HASH, request.form.get("password", ""))
        if row and good:
            _fails.pop(ip, None)
            session.clear()
            session["user"] = row["username"]
            session["csrf"] = secrets.token_urlsafe(32)
            session.permanent = True
            return redirect(_safe_next(request.args.get("next", "")))
        count += 1
        _fails[ip] = [count, time.time() + LOCK_SECONDS if count >= MAX_FAILS else 0]
        flash("Wrong username or password.", "error")
        return render_template("login.html"), 401
    csrf_token()
    return render_template("login.html")


@bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("auth.login"))


# ----------------------------------------------------------------------------- own password
@bp.route("/account", methods=["GET", "POST"])
def account():
    if request.method == "POST":
        row = get_db().execute("SELECT * FROM users WHERE username=?", (g.user,)).fetchone()
        new = request.form.get("new", "")
        if not check_password_hash(row["password_hash"], request.form.get("current", "")):
            flash("Your current password is wrong.", "error")
        elif len(new) < MIN_PASSWORD:
            flash(f"Use at least {MIN_PASSWORD} characters.", "error")
        elif new != request.form.get("repeat", ""):
            flash("The two new passwords differ.", "error")
        else:
            get_db().execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new), row["id"]))
            get_db().commit()
            flash("Password changed.", "ok")
        return redirect(url_for("auth.account"))
    return render_template("account.html")
