"""Excel in / out.

In : any sheet shaped like 'Raw Abend Log', 'Abends_data' or 'Abend Tracker' (cols A-F) is
     converted to the same tab-separated text you paste, so it goes through the same
     review page as a daily paste.
Out: the Abend Tracker (cols A-Q, same headings as the workbook), an Incident Summary sheet
     built the way the macro built it, and an Abends_data-compatible sheet.
"""
from collections import OrderedDict
from datetime import date, datetime, timedelta

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from .rules import CATEGORIES, Rules, norm

PREFERRED_SHEETS = ["Raw Abend Log", "Abends_data", "Abend Tracker"]

HEADER_FILL = PatternFill("solid", fgColor="1F3864")
TYPE_FILL = {
    "Grid Issue": "E6F5E9", "Data Issue": "FFEBEB", "Network Issue": "FFF3CD", "Other Issue": "EBF1FB",
}
FONT = "Calibri"


def _cell_text(v) -> str:
    if v is None:
        return ""
    if isinstance(v, datetime):
        return v.date().isoformat()
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return str(v).replace("\t", " ").replace("\r", " ").replace("\n", " ").strip()


def workbook_to_text(fileobj, sheet=None):
    """-> (tab separated text, sheet name used, data rows found)

    Columns A-F are always application, task, root cause, action, date, category.
    Column G is read as Comments on 'Raw Abend Log' and as Assigned To on 'Abend Tracker'.
    """
    wb = load_workbook(fileobj, read_only=True, data_only=True)
    if sheet is None or sheet not in wb.sheetnames:
        sheet = next((n for n in PREFERRED_SHEETS if n in wb.sheetnames), wb.sheetnames[0])
    ws = wb[sheet]
    lines = []
    for row in ws.iter_rows(values_only=True):
        cells = list(row) + [None] * 7
        first = _cell_text(cells[0])
        if not first or first.lower() in ("application", "app") or first.startswith("\u2190"):
            continue
        fields = [_cell_text(c) for c in cells[:6]]
        if not any(fields[1:]):
            continue  # note / footer rows such as the "PASTE GUIDE" line carry nothing but column A
        if sheet == "Raw Abend Log":
            fields.append(_cell_text(cells[6]))                    # comments
        elif sheet == "Abend Tracker":
            fields += ["", _cell_text(cells[6])]                   # comments (none), assigned to
        lines.append("\t".join(fields))
    wb.close()
    return "\n".join(lines), sheet, len(lines)


# ----------------------------------------------------------------------------- exports
def _header(ws, headers, widths):
    ws.row_dimensions[1].height = 28
    for i, (h, w) in enumerate(zip(headers, widths), start=1):
        c = ws.cell(row=1, column=i, value=h)
        c.fill, c.font = HEADER_FILL, Font(name=FONT, size=10, bold=True, color="FFFFFF")
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}1"


def tracker_workbook(rules: Rules, rows: list) -> Workbook:
    wb = Workbook()
    ws = wb.active
    ws.title = "Abend Tracker"
    headers = ["Application", "Description", "Root Cause / Error", "Action Taken", "Date", "Category",
               "Assigned To", "Short Description", "Resolution Code", "Resolution Summary", "Incident#",
               "Impact", "Urgency", "ITSM Category", "ITSM Subcategory", "Config Item", "Assignment Group"]
    widths = [14, 60, 22, 14, 12, 10, 18, 44, 30, 60, 16, 10, 10, 28, 14, 14, 18]
    _header(ws, headers, widths)
    for i, r in enumerate(rows, start=2):
        rules.decorate(r)
        vals = [r["app"], r["task_text"], r["root_cause"], r["action"], r["date"], r["category"],
                r["assigned_to"] or "", r["short_description"], r["resolution_code"], r["resolution_summary"],
                r["incident_no"] or "", r["impact"], r["urgency"], r["itsm_category"], r["itsm_subcategory"],
                r["config_item"], r["assignment_group"]]
        fill = PatternFill("solid", fgColor=TYPE_FILL[r["issue_type"]])
        for c, v in enumerate(vals, start=1):
            cell = ws.cell(row=i, column=c, value=v)
            cell.fill = fill
            cell.font = Font(name=FONT, size=10, bold=(c == 11 and bool(v)),
                             color=("1E7E34" if c == 11 and v and not str(v).startswith("CHECK") else "000000"))
            cell.alignment = Alignment(vertical="top", wrap_text=c in (2, 8, 10))
    summary_sheet(wb, rules, rows)
    return wb


def summary_rows(rules: Rules, rows: list) -> list:
    groups = OrderedDict()
    for r in rows:
        key = (r["category"], rules.issue_type(r["root_cause"]), r["action"])
        g = groups.setdefault(key, {"apps": [], "count": 0, "rcs": [], "action": r["action"], "inc": []})
        if r["app"] not in g["apps"]:
            g["apps"].append(r["app"])
        g["count"] += 1
        if r["root_cause"] not in g["rcs"]:
            g["rcs"].append(r["root_cause"])
        inc = (r.get("incident_no") or "").strip()
        if inc and inc not in g["inc"]:
            g["inc"].append(inc)
    return list(groups.values())


def summary_sheet(wb: Workbook, rules: Rules, rows: list) -> None:
    ws = wb.create_sheet("Incident Summary")
    _header(ws, ["Application(s)", "Count of Failures", "Root Cause / Error Message", "Action Taken", "Incident#"],
            [35, 18, 38, 16, 22])
    for i, g in enumerate(summary_rows(rules, rows), start=2):
        green = g["action"].lower() == "rerun"
        fill = PatternFill("solid", fgColor="E6F5E9" if green else "FFEBEB")
        inc = ", ".join(g["inc"]) if g["inc"] else "Pending"
        vals = [", ".join(g["apps"]), g["count"], " / ".join(g["rcs"]), g["action"], inc]
        for c, v in enumerate(vals, start=1):
            cell = ws.cell(row=i, column=c, value=v)
            cell.fill = fill
            cell.font = Font(name=FONT, size=10, bold=c in (2, 5))
            if c in (2, 4, 5):
                cell.alignment = Alignment(horizontal="center")


def abends_data_workbook(rules: Rules, rows: list) -> Workbook:
    """Same A-O columns as Abends_data in Grid_Issues_Analsys (formula columns written as values)."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Abends_data"
    headers = ["Application", "Task", "Root cause/Error message", "Action Taken", "Date", "Category", "IsGridIssue",
               "DateClean", "Month", "DayOfWeek", "IssueType", "WeekStart", "Week", "CatTaskKey", "CategoryNorm"]
    _header(ws, headers, [14, 70, 24, 14, 12, 10, 11, 12, 10, 11, 22, 12, 12, 40, 12])
    for i, r in enumerate(rows, start=2):
        d = datetime.strptime(r["date"], "%Y-%m-%d").date()
        week_start = d - timedelta(days=d.weekday())
        itype = rules.dashboard_issue_type(r["root_cause"])
        vals = [r["app"], r["task_text"], r["root_cause"], r["action"], d, r["category"],
                1 if itype == "Grid Issue" else 0, d, r["date"][:7], d.strftime("%a"), itype, week_start, week_start,
                f"{r['category']}\u2666{r['task_text']}", r["category"].upper()]
        for c, v in enumerate(vals, start=1):
            cell = ws.cell(row=i, column=c, value=v)
            cell.font = Font(name=FONT, size=10)
            if isinstance(v, date):
                cell.number_format = "yyyy-mm-dd"
    return wb


def incidents_workbook(items: list) -> Workbook:
    """The incidents still to raise, one row each, with every field you paste into ServiceNow."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Incidents to create"
    keys = ["short_description", "description", "category", "subcategory", "cmdb_ci", "assignment_group", "impact",
            "urgency", "close_notes", "resolution_code", "application", "root_cause", "action_taken"]
    _header(ws, ["Abends"] + keys + ["Incident number (fill in)"], [8, 46, 60, 28, 14, 14, 18, 10, 10, 60, 30, 18, 22, 14, 22])
    for i, it in enumerate(items, start=2):
        fill = PatternFill("solid", fgColor=TYPE_FILL.get(it["issue_type"], "FFFFFF"))
        vals = [it["count"]] + [it["payload"][k] for k in keys] + [""]
        for c, v in enumerate(vals, start=1):
            cell = ws.cell(row=i, column=c, value=v)
            cell.fill, cell.font = fill, Font(name=FONT, size=10)
            cell.alignment = Alignment(vertical="top", wrap_text=c in (2, 3, 10))
    return wb
