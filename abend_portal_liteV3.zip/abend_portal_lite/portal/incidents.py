"""Incidents recorded by hand.

You create each incident in ServiceNow yourself. This page prepares everything you need to paste (the same
fields your macro used to send) and records the incident number you get back against the abend rows, one by
one or in bulk.

Shapes (same as before):
  group  one incident per Category + Issue Type + Action
  row    one incident per abend row
and any group can be split into one incident per task.
"""
import re
from collections import OrderedDict

from .db import now
from .rules import CATEGORIES, Rules

NUMBER_RE = re.compile(r"^[A-Z]{3,6}\d{5,12}$")


def normalise_number(raw) -> str:
    return re.sub(r"\s+", "", str(raw or "")).upper()


# --------------------------------------------------------------------------- the fields to paste
def _payload(rules: Rules, short, desc, rc, summary, app, action) -> "OrderedDict":
    itsm = rules.itsm()
    p = OrderedDict()
    p["short_description"] = short
    p["description"] = desc
    p["category"] = itsm["category"]
    p["subcategory"] = itsm["subcategory"]
    p["cmdb_ci"] = itsm["config_item"]
    p["assignment_group"] = itsm["assignment_group"]
    p["impact"] = itsm["impact"]
    p["urgency"] = itsm["urgency"]
    p["close_notes"] = summary
    p["resolution_code"] = rules.resolution_code
    p["application"] = app
    p["root_cause"] = rc
    p["action_taken"] = action
    return p


def _row_payload(rules, r):
    return _payload(
        rules,
        short=rules.short_description(r["category"], r["app"], r["root_cause"]),
        desc=r["task_text"], rc=r["root_cause"],
        summary=rules.resolution_summary(r["root_cause"]),
        app=r["app"], action=r["action"],
    )


def _group_payload(rules, rows):
    apps = list(OrderedDict.fromkeys(r["app"] for r in rows))
    rcs = list(OrderedDict.fromkeys(r["root_cause"] for r in rows))
    cat = rows[0]["category"]
    itype = rules.issue_type(rows[0]["root_cause"])
    rc_text = " / ".join(rcs)
    app_text = ", ".join(apps)
    short = f"{cat} | {app_text} | {rc_text}" if itype == "Grid Issue" else f"{cat} | {app_text} | {itype} | {rc_text}"
    dates = sorted({r["date"] for r in rows})
    lines = [f"{len(rows)} task(s) abended on {', '.join(dates)}:"]
    lines += [f"- {r['app']}: {r['task_text']}" for r in rows]
    if len(rcs) == 1:
        summary = rules.resolution_summary(rcs[0])
    else:
        summary = "\n".join(f"{rc}: {rules.resolution_summary(rc)}" for rc in rcs)
    return _payload(rules, short, "\n".join(lines), rc_text, summary, app_text, rows[0]["action"])


def build_items(rules: Rules, rows: list, mode: str) -> list:
    """rows: dict rows from abends -> list of incidents to raise."""
    items = []
    if mode == "row":
        for r in rows:
            p = _row_payload(rules, r)
            items.append(_item(f"row:{r['id']}", mode, p["short_description"], [r], p, rules))
    else:
        groups = OrderedDict()
        for r in rows:
            key = f"{r['category']}|{rules.issue_type(r['root_cause'])}|{r['action']}"
            groups.setdefault(key, []).append(r)
        order = {c: i for i, c in enumerate(CATEGORIES)}
        for key in sorted(groups, key=lambda k: (order.get(k.split("|")[0], 9), k)):
            g = groups[key]
            p = _group_payload(rules, g)
            it = _item(key, mode, p["short_description"], g, p, rules)
            # what each task would look like as its own incident (for the "one per task" toggle)
            it["row_payloads"] = {str(r["id"]): _row_payload(rules, r) for r in g}
            items.append(it)
    return items


def _item(key, mode, label, rows, payload, rules):
    return {
        "key": key, "mode": mode, "label": label,
        "ids": [r["id"] for r in rows], "count": len(rows),
        "apps": list(OrderedDict.fromkeys(r["app"] for r in rows)),
        "category": rows[0]["category"], "action": rows[0]["action"],
        "issue_type": rules.issue_type(rows[0]["root_cause"]),
        "tasks": [{"id": r["id"], "app": r["app"], "task": r["task_name"] or r["task_text"], "date": r["date"],
                   "root_cause": r["root_cause"]} for r in rows],
        "payload": payload,
    }


# --------------------------------------------------------------------------- queue
def open_rows(conn, date_from="", date_to=""):
    sql = "SELECT * FROM abends WHERE incident_status='pending' AND COALESCE(incident_no,'')=''"
    args = []
    if date_from:
        sql += " AND date>=?"
        args.append(date_from)
    if date_to:
        sql += " AND date<=?"
        args.append(date_to)
    return [dict(r) for r in conn.execute(sql + " ORDER BY date, id", args)]


def record_numbers(conn, entries, allow_same=False) -> dict:
    """entries = [{"ids": [abend ids], "number": "INC123..."}]. All-or-nothing: if anything is wrong nothing is saved."""
    if not isinstance(entries, list) or not entries:
        return {"ok": False, "error": "Type at least one incident number."}
    clean_entries, errors, seen_ids, seen_numbers = [], [], set(), {}
    for i, e in enumerate(entries):
        ids = e.get("ids") if isinstance(e, dict) else None
        number = normalise_number(e.get("number") if isinstance(e, dict) else "")
        if not isinstance(ids, list) or not ids or not all(isinstance(x, int) for x in ids):
            errors.append({"index": i, "error": "No rows."})
            continue
        if not NUMBER_RE.match(number):
            errors.append({"index": i, "error": f"'{number or 'blank'}' doesn't look like an incident number (e.g. INC1234567)."})
            continue
        if seen_ids & set(ids):
            errors.append({"index": i, "error": "The same rows were supplied twice."})
            continue
        seen_ids |= set(ids)
        if number in seen_numbers and not allow_same:
            errors.append({"index": i, "error": f"{number} is used for more than one incident here. Tick 'same number is intended' if that's right."})
            continue
        seen_numbers[number] = True
        clean_entries.append({"ids": ids, "number": number})
    if errors:
        return {"ok": False, "error": errors[0]["error"], "errors": errors}

    all_ids = [x for e in clean_entries for x in e["ids"]]
    marks = ",".join("?" * len(all_ids))
    ok_rows = conn.execute(f"SELECT COUNT(*) FROM abends WHERE id IN ({marks}) AND incident_status='pending' "
                           "AND COALESCE(incident_no,'')=''", all_ids).fetchone()[0]
    if ok_rows != len(all_ids):
        return {"ok": False, "error": "Some of those rows already have an incident or no longer exist - refresh the page."}
    if not allow_same:
        for e in clean_entries:
            em = ",".join("?" * len(e["ids"]))
            used = conn.execute(f"SELECT COUNT(*) FROM abends WHERE incident_no=? AND id NOT IN ({em})",
                                [e["number"]] + e["ids"]).fetchone()[0]
            if used:
                return {"ok": False, "error": f"{e['number']} is already recorded on {used} other row(s). "
                                              "Tick 'same number is intended' if you want to reuse it."}
    for e in clean_entries:
        em = ",".join("?" * len(e["ids"]))
        conn.execute(f"UPDATE abends SET incident_no=?, incident_status='created', incident_error=NULL, updated_at=? "
                     f"WHERE id IN ({em})", [e["number"], now()] + e["ids"])
    conn.commit()
    return {"ok": True, "saved": len(clean_entries), "rows": len(all_ids)}


def mark_no_incident(conn, ids) -> int:
    marks = ",".join("?" * len(ids))
    cur = conn.execute(f"UPDATE abends SET incident_status='historical', updated_at=? WHERE id IN ({marks}) "
                       "AND incident_status='pending' AND COALESCE(incident_no,'')=''", [now()] + list(ids))
    conn.commit()
    return cur.rowcount


def recent(conn, rules: Rules, limit=12) -> list:
    out = []
    for r in conn.execute(
            "SELECT incident_no, COUNT(*) n, MAX(updated_at) t, GROUP_CONCAT(DISTINCT app) apps FROM abends "
            "WHERE COALESCE(incident_no,'')!='' AND source!='excel:Abend Tracker' GROUP BY incident_no "
            "ORDER BY MAX(updated_at) DESC LIMIT ?", (limit,)):
        out.append(dict(r))
    return out
