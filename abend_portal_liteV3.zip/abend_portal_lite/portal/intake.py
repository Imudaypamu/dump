"""Raw intake: paste -> staging rows -> review -> commit.

Nothing reaches the tracker, the dashboard or the incident queue until a batch is
committed from the review page.
"""
import json
import sqlite3
from collections import Counter, defaultdict
from datetime import date

from . import parser
from .db import now
from .rules import CATEGORIES, Rules, clean, norm

EDITABLE = ["app", "task_text", "root_cause", "action", "date", "category", "comments", "assigned_to"]


def _issue(level, field, msg, code=""):
    d = {"level": level, "field": field, "msg": msg}
    if code:
        d["code"] = code
    return d


class History:
    """What is already in the tracker -- used for category inference and duplicates."""

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        counts = defaultdict(Counter)
        for r in conn.execute("SELECT app, category, COUNT(*) n FROM abends GROUP BY app, category"):
            counts[norm(r["app"])][r["category"]] += r["n"]
        self.app_category = {a: c.most_common(1)[0][0] for a, c in counts.items()}
        self._runs = defaultdict(set)
        self._loaded = set()

    def runs_for(self, iso_date, task_name):
        if iso_date and iso_date not in self._loaded:
            self._loaded.add(iso_date)
            for r in self.conn.execute("SELECT task_name, run_id FROM abends WHERE date=?", (iso_date,)):
                self._runs[(iso_date, norm(r["task_name"]))].add(r["run_id"] or "")
        return self._runs.get((iso_date, norm(task_name)), set())


def process_row(raw: dict, rules: Rules, default_date: str, hist: History) -> dict:
    """Normalise one row and attach validation issues. `raw` has the EDITABLE fields."""
    issues = []
    row = {k: clean(raw.get(k, "")) if k != "task_text" else clean(raw.get("task_text", "")) for k in EDITABLE}

    # application
    if not row["app"]:
        issues.append(_issue("error", "app", "Application is missing."))
    else:
        row["app"], known = rules.canonical_app(row["app"])
        if not known:
            issues.append(_issue("info", "app", f"'{row['app']}' is a new application - it will be added to the list.",
                                 "new_app"))

    # task sentence -> task / process / run id / alert
    if not row["task_text"]:
        issues.append(_issue("error", "task_text", "Task / alert text is missing."))
    t = parser.parse_task(row["task_text"])
    row.update(task_name=t["task_name"], process=t["process"], run_id=t["run_id"], alert=t["alert"])

    # root cause
    if not row["root_cause"]:
        issues.append(_issue("error", "root_cause", "Root cause is missing."))
    else:
        row["root_cause"], known = rules.canonical_root_cause(row["root_cause"])
        if not known:
            issues.append(_issue(
                "warn", "root_cause",
                f"'{row['root_cause']}' is not in Config Table 2, so it counts as 'Other Issue' with the "
                "fallback resolution text. Add it below.", "unknown_rc"))

    # action
    if not row["action"]:
        issues.append(_issue("error", "action", "Action taken is missing."))
    else:
        row["action"], known = rules.canonical_action(row["action"])
        if not known:
            issues.append(_issue("error", "action",
                                 f"'{row['action']}' is not a known action. Pick Rerun, Set to normal or Yet to take."))

    # date
    iso, note = parser.parse_date(row["date"])
    if not row["date"]:
        iso = default_date
        issues.append(_issue("info", "date", f"No date on the line - using the batch default {default_date}."))
    elif iso is None:
        issues.append(_issue("error", "date", f"'{row['date']}' is not a recognisable date. Use YYYY-MM-DD."))
    elif note:
        issues.append(_issue("warn", "date", note))
    row["date"] = iso or row["date"]

    # category
    if not row["category"]:
        guess = hist.app_category.get(norm(row["app"]))
        if guess:
            row["category"] = guess
            issues.append(_issue("warn", "category",
                                 f"No category on the line - {guess} inferred from earlier {row['app']} rows."))
        else:
            issues.append(_issue("error", "category", "Category is missing (BDM, PWC or CLOUD)."))
    else:
        row["category"], known = rules.canonical_category(row["category"])
        if not known:
            issues.append(_issue("error", "category", f"'{row['category']}' is not valid. Use BDM, PWC or CLOUD."))

    if not row["assigned_to"]:
        row["assigned_to"] = rules.settings.get("default_assigned_to", "")

    row["issues"] = issues
    return row


def _flag_duplicates(rows: list, hist: History, force_include: bool) -> None:
    """Sets row['dup'] and (only on first parse) row['include']."""
    seen = defaultdict(list)  # (date, task) -> run ids already seen in this batch
    for row in rows:
        row["dup"] = ""
        if not row.get("date") or not row.get("task_name") or row.get("committed"):
            continue
        key = (row["date"], norm(row["task_name"]))
        run = row["run_id"] or ""
        db_runs = hist.runs_for(row["date"], row["task_name"])
        if run and run in db_runs:
            row["dup"] = "exact"
            row["issues"].append(_issue("warn", "task_text",
                                        "Already in the tracker (same task, date and run id). Unticked by default."))
        elif db_runs and not (run and all(db_runs)):
            row["dup"] = "possible"
            row["issues"].append(_issue("warn", "task_text",
                                        "This task already has an entry on this date and the run id can't tell "
                                        "them apart. Unticked by default - tick it if it is a second abend."))
        else:
            prior = seen[key]
            if run and run in prior:
                row["dup"] = "exact"
                row["issues"].append(_issue("warn", "task_text", "Same line appears twice in this paste."))
            elif prior and not (run and all(prior)):
                row["dup"] = "batch"
                row["issues"].append(_issue("warn", "task_text",
                                            "Same task and date appear earlier in this paste (no run id to compare)."))
        seen[key].append(run)
        if row.get("_first_pass") and not force_include and row["dup"] in ("exact", "possible"):
            row["include"] = 0


def _load_staging(conn, batch_id):
    return [dict(r) for r in conn.execute("SELECT * FROM staging WHERE batch_id=? ORDER BY line_no, id", (batch_id,))]


def _save_row(conn, row):
    conn.execute(
        """UPDATE staging SET include=?, app=?, task_text=?, task_name=?, process=?, run_id=?, alert=?,
           root_cause=?, action=?, date=?, category=?, comments=?, assigned_to=?, issues=?, dup=? WHERE id=?""",
        (row["include"], row["app"], row["task_text"], row["task_name"], row["process"], row["run_id"],
         row["alert"], row["root_cause"], row["action"], row["date"], row["category"], row["comments"],
         row["assigned_to"], json.dumps(row["issues"]), row["dup"], row["id"]),
    )


def revalidate(conn, rules: Rules, batch_id: int, first_pass=False, force_include=False) -> None:
    batch = conn.execute("SELECT * FROM batches WHERE id=?", (batch_id,)).fetchone()
    default_date = batch["default_date"] or date.today().isoformat()
    hist = History(conn)
    rows = _load_staging(conn, batch_id)
    processed = []
    for r in rows:
        if r["committed"]:
            r["issues"] = json.loads(r["issues"] or "[]")
            processed.append(r)
            continue
        new = process_row(r, rules, default_date, hist)
        new.update(id=r["id"], include=r["include"], committed=0, _first_pass=first_pass)
        processed.append(new)
    _flag_duplicates(processed, hist, force_include)
    for r in processed:
        if not r.get("committed"):
            _save_row(conn, r)
    conn.execute("UPDATE batches SET row_count=? WHERE id=?", (len(processed), batch_id))
    conn.commit()


def create_batch(conn, rules: Rules, raw_text: str, default_date: str = "", historical=False,
                 source="paste", force_include=False) -> int:
    default_date = parser.parse_date(default_date)[0] or date.today().isoformat()
    lines = parser.extract_lines(raw_text)
    cur = conn.execute(
        "INSERT INTO batches(created_at, source, raw_text, default_date, historical, status, row_count) "
        "VALUES(?,?,?,?,?,?,?)",
        (now(), source, raw_text, default_date, 1 if historical else 0, "staged", len(lines)),
    )
    batch_id = cur.lastrowid
    for line_no, line in lines:
        f = parser.split_line(line)
        conn.execute(
            "INSERT INTO staging(batch_id, line_no, raw_line, app, task_text, root_cause, action, date, category,"
            " comments, assigned_to) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (batch_id, line_no, line, f["app"], f["task_text"], f["root_cause"], f["action"], f["date"],
             f["category"], f["comments"], f["assigned_to"]),
        )
    conn.commit()
    revalidate(conn, rules, batch_id, first_pass=True, force_include=force_include)
    return batch_id


def apply_form(conn, rules: Rules, batch_id: int, form) -> None:
    """Save the edits made on the review page, then re-validate."""
    for r in conn.execute("SELECT id FROM staging WHERE batch_id=? AND committed=0", (batch_id,)).fetchall():
        sid = r["id"]
        if f"app_{sid}" not in form:
            continue
        vals = {k: form.get(f"{k}_{sid}", "") for k in EDITABLE}
        include = 1 if form.get(f"include_{sid}") else 0
        conn.execute(
            "UPDATE staging SET app=?, task_text=?, root_cause=?, action=?, date=?, category=?, comments=?, "
            "assigned_to=?, include=? WHERE id=?",
            (vals["app"], vals["task_text"], vals["root_cause"], vals["action"], vals["date"], vals["category"],
             vals["comments"], vals["assigned_to"], include, sid),
        )
    conn.commit()
    revalidate(conn, rules, batch_id)


def batch_rows(conn, batch_id):
    rows = _load_staging(conn, batch_id)
    for r in rows:
        r["issues"] = json.loads(r["issues"] or "[]")
        r["errors"] = [i for i in r["issues"] if i["level"] == "error"]
        r["status"] = ("committed" if r["committed"] else "error" if r["errors"]
                       else "warn" if any(i["level"] == "warn" for i in r["issues"]) else "ok")
    return rows


def commit(conn, rules: Rules, batch_id: int) -> dict:
    batch = conn.execute("SELECT * FROM batches WHERE id=?", (batch_id,)).fetchone()
    if not batch or batch["status"] in ("discarded", "committed"):
        return {"committed": 0, "blocked": 0, "skipped": 0, "error": "Batch is not open."}
    rows = batch_rows(conn, batch_id)
    status = "historical" if batch["historical"] else "pending"
    committed = blocked = skipped = 0
    new_apps = set()
    for r in rows:
        if r["committed"]:
            continue
        if not r["include"]:
            skipped += 1
            continue
        if r["errors"]:
            blocked += 1
            continue
        if not rules.canonical_app(r["app"])[1]:
            new_apps.add(r["app"])
        conn.execute(
            """INSERT INTO abends(batch_id, line_no, app, task_text, task_name, process, run_id, alert, root_cause,
               action, date, category, comments, assigned_to, incident_status, source, created_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (batch_id, r["line_no"], r["app"], r["task_text"], r["task_name"], r["process"], r["run_id"],
             r["alert"], r["root_cause"], r["action"], r["date"], r["category"], r["comments"], r["assigned_to"],
             status, batch["source"], now()),
        )
        conn.execute("UPDATE staging SET committed=1, include=0 WHERE id=?", (r["id"],))
        committed += 1
    for a in new_apps:
        conn.execute("INSERT OR IGNORE INTO app_names(name) VALUES(?)", (a,))
    open_rows = conn.execute("SELECT COUNT(*) FROM staging WHERE batch_id=? AND committed=0 AND include=1",
                             (batch_id,)).fetchone()[0]
    total_committed = conn.execute("SELECT COUNT(*) FROM staging WHERE batch_id=? AND committed=1",
                                   (batch_id,)).fetchone()[0]
    new_status = "partial" if open_rows else ("committed" if total_committed else "staged")
    conn.execute("UPDATE batches SET status=?, committed_count=?, committed_at=? WHERE id=?",
                 (new_status, total_committed, now() if committed else batch["committed_at"], batch_id))
    conn.commit()
    return {"committed": committed, "blocked": blocked, "skipped": skipped, "new_apps": sorted(new_apps)}


def discard(conn, batch_id: int) -> None:
    conn.execute("UPDATE batches SET status='discarded' WHERE id=? AND status IN ('staged','partial')", (batch_id,))
    conn.commit()


def undo(conn, batch_id: int) -> dict:
    """Take back what a batch logged. Rows that already have (or are creating) an incident are kept."""
    batch = conn.execute("SELECT * FROM batches WHERE id=?", (batch_id,)).fetchone()
    if not batch:
        return {"removed": 0, "kept": 0}
    cur = conn.execute("DELETE FROM abends WHERE batch_id=? AND incident_status IN ('pending','historical','failed') "
                       "AND COALESCE(incident_no,'')=''", (batch_id,))
    removed = cur.rowcount
    kept = conn.execute("SELECT COUNT(*) FROM abends WHERE batch_id=?", (batch_id,)).fetchone()[0]
    if kept == 0:
        conn.execute("UPDATE batches SET status='discarded', committed_count=0 WHERE id=?", (batch_id,))
    else:
        conn.execute("UPDATE batches SET committed_count=? WHERE id=?", (kept, batch_id))
    conn.commit()
    return {"removed": removed, "kept": kept}


def unknown_root_causes(rows):
    seen = {}
    for r in rows:
        if r["committed"]:
            continue
        for i in r["issues"]:
            if i.get("code") == "unknown_rc":
                seen.setdefault(norm(r["root_cause"]), r["root_cause"])
    return list(seen.values())


def summary(rows):
    c = Counter(r["status"] for r in rows)
    return {"total": len(rows), "ok": c["ok"], "warn": c["warn"], "error": c["error"],
            "committed": c["committed"], "included": sum(1 for r in rows if r["include"] and not r["committed"])}
