import io
import json
import re
import sqlite3
from datetime import date

from flask import (Blueprint, Response, abort, flash, g, jsonify, redirect, render_template, request,
                   url_for)

from werkzeug.security import generate_password_hash

from . import analytics, excel_io, incidents, intake
from .auth import MIN_PASSWORD, USERNAME_RE, admin_required
from .db import get_db, now, q, q1, run
from .rules import (ACTIONS, CATEGORIES, DEFAULT_SETTINGS, EDITABLE_SETTINGS, ISSUE_TYPE_HELP, ISSUE_TYPES, TYPE_CLASS, Rules, clean,
                    norm)

bp = Blueprint("main", __name__)


def rules() -> Rules:
    return Rules(get_db())


def register_filters(app):
    app.jinja_env.filters["pct"] = lambda v: f"{v:.0f}%"
    app.jinja_env.filters["num"] = lambda v: f"{int(v):,}"
    app.jinja_env.filters["fromjson"] = lambda v: json.loads(v) if v else {}
    app.jinja_env.globals.update(CATEGORIES=CATEGORIES, ACTIONS=ACTIONS, ISSUE_TYPES=ISSUE_TYPES,
                                 TYPE_CLASS=TYPE_CLASS)

    @app.context_processor
    def inject():
        try:
            pending = q1("SELECT COUNT(*) c FROM abends WHERE incident_status='pending'")["c"]
            staged = q1("SELECT COUNT(*) c FROM batches WHERE status IN ('staged','partial')")["c"]
        except sqlite3.Error:
            pending = staged = 0
        from . import db as _db
        return {"nav_pending": pending, "nav_staged": staged,
                "is_admin": g.get("role") == "admin", "user_name": g.get("user"),
                "save_error": _db.STORE.save_error if _db.STORE else None}

    @app.errorhandler(400)
    def bad_request(e):
        if request.is_json or request.accept_mimetypes.best == "application/json":
            return jsonify(ok=False, error=getattr(e, "description", "Bad request")), 400
        return render_template("error.html", code=400, message=getattr(e, "description", "Bad request")), 400

    @app.errorhandler(404)
    def not_found(e):
        return render_template("error.html", code=404, message="That page doesn't exist."), 404


@bp.route("/")
def index():
    return redirect(url_for("main.dashboard"))


# ============================================================================ dashboard
@bp.route("/dashboard")
def dashboard():
    r = rules()
    filters = {k: request.args.get(k, "") for k in ("month", "from", "to", "buffer", "scope", "category", "app")}
    data = analytics.compute(get_db(), r, filters)
    return render_template("dashboard.html", d=data, f=filters)


# ============================================================================ raw intake
@bp.route("/intake")
def intake_home():
    batches = q("SELECT * FROM batches WHERE status!='discarded' ORDER BY id DESC LIMIT 30")
    return render_template("intake.html", batches=batches, today=date.today().isoformat())


@bp.route("/intake/parse", methods=["POST"])
def intake_parse():
    text = request.form.get("raw_text", "")
    if not text.strip():
        flash("Paste the abend text first.", "error")
        return redirect(url_for("main.intake_home"))
    bid = intake.create_batch(get_db(), rules(), text, request.form.get("default_date", ""),
                              historical=bool(request.form.get("historical")))
    return redirect(url_for("main.batch_view", batch_id=bid))


@bp.route("/intake/upload", methods=["POST"])
def intake_upload():
    f = request.files.get("xlsx")
    if not f or not f.filename.lower().endswith((".xlsx", ".xlsm")):
        flash("Choose an .xlsx or .xlsm file.", "error")
        return redirect(url_for("main.intake_home"))
    try:
        text, sheet, n = excel_io.workbook_to_text(f.stream)
    except Exception as exc:  # corrupt / password protected workbook
        flash(f"Couldn't read that workbook: {exc}", "error")
        return redirect(url_for("main.intake_home"))
    if not n:
        flash("No data rows found. Expected columns: Application, Task, Root cause, Action, Date, Category.", "error")
        return redirect(url_for("main.intake_home"))
    bid = intake.create_batch(get_db(), rules(), text, request.form.get("default_date", ""),
                              historical=bool(request.form.get("historical")), source=f"excel:{sheet}")
    flash(f"Read {n} rows from sheet '{sheet}'.", "ok")
    return redirect(url_for("main.batch_view", batch_id=bid))


def _batch_or_404(batch_id):
    b = q1("SELECT * FROM batches WHERE id=?", (batch_id,))
    if not b:
        abort(404)
    return b


@bp.route("/intake/batch/<int:batch_id>")
def batch_view(batch_id):
    b = _batch_or_404(batch_id)
    r = rules()
    rows = intake.batch_rows(get_db(), batch_id)
    for row in rows:
        row["platform"] = r.platform(row["category"], row["app"], row["task_name"])
        row["issue_type"] = r.issue_type(row["root_cause"])
        row["type_class"] = TYPE_CLASS[row["issue_type"]]
        row["short_description"] = (r.short_description(row["category"], row["app"], row["root_cause"])
                                    if row["category"] and row["app"] and row["root_cause"] else "")
    return render_template("batch.html", b=b, rows=rows, summary=intake.summary(rows),
                           unknown_rcs=intake.unknown_root_causes(rows), apps=r.apps,
                           root_causes=[x["root_cause"] for x in r.root_causes])


@bp.route("/intake/batch/<int:batch_id>/save", methods=["POST"])
def batch_save(batch_id):
    _batch_or_404(batch_id)
    intake.apply_form(get_db(), rules(), batch_id, request.form)
    flash("Edits saved and every row re-checked.", "ok")
    return redirect(url_for("main.batch_view", batch_id=batch_id))


@bp.route("/intake/batch/<int:batch_id>/commit", methods=["POST"])
def batch_commit(batch_id):
    _batch_or_404(batch_id)
    intake.apply_form(get_db(), rules(), batch_id, request.form)
    res = intake.commit(get_db(), rules(), batch_id)
    if res.get("error"):
        flash(res["error"], "error")
        return redirect(url_for("main.intake_home"))
    msg = f"{res['committed']} row(s) logged to the tracker and dashboard."
    if res["blocked"]:
        msg += f" {res['blocked']} ticked row(s) still have errors and were left in the batch."
    flash(msg, "ok" if res["committed"] else "error")
    if request.form.get("then") == "incidents" and res["committed"]:
        return redirect(url_for("main.incidents_home"))
    return redirect(url_for("main.batch_view", batch_id=batch_id))


@bp.route("/intake/batch/<int:batch_id>/discard", methods=["POST"])
def batch_discard(batch_id):
    _batch_or_404(batch_id)
    intake.discard(get_db(), batch_id)
    flash("Batch discarded. Nothing was logged.", "ok")
    return redirect(url_for("main.intake_home"))


@bp.route("/intake/batch/<int:batch_id>/undo", methods=["POST"])
def batch_undo(batch_id):
    _batch_or_404(batch_id)
    res = intake.undo(get_db(), batch_id)
    msg = f"{res['removed']} logged row(s) removed from the tracker and dashboard."
    if res["kept"]:
        msg += f" {res['kept']} row(s) kept because they already have an incident."
    flash(msg, "ok")
    return redirect(url_for("main.batch_view", batch_id=batch_id) if res["kept"] else url_for("main.intake_home"))


@bp.route("/intake/batch/<int:batch_id>/add-root-cause", methods=["POST"])
def batch_add_root_cause(batch_id):
    _batch_or_404(batch_id)
    name = clean(request.form.get("root_cause", ""))
    itype = request.form.get("issue_type", "")
    if not name or itype not in ISSUE_TYPES:
        flash("Give the root cause a name and an issue type.", "error")
    else:
        try:
            get_db().execute(
                "INSERT INTO root_causes(root_cause, issue_type, resolution_summary) VALUES(?,?,?)",
                (name, itype, request.form.get("resolution_summary", "").strip()))
            get_db().commit()
            flash(f"'{name}' added to Config Table 2 as {itype}.", "ok")
        except sqlite3.IntegrityError:
            flash(f"'{name}' already exists in Config Table 2.", "error")
    intake.revalidate(get_db(), rules(), batch_id)
    return redirect(url_for("main.batch_view", batch_id=batch_id))


# ============================================================================ tracker
@bp.route("/tracker")
def tracker():
    r = rules()
    a = request.args
    sql, args = "SELECT * FROM abends WHERE 1=1", []
    if a.get("from"):
        sql += " AND date>=?"
        args.append(a["from"])
    if a.get("to"):
        sql += " AND date<=?"
        args.append(a["to"])
    if a.get("app"):
        sql += " AND app=? COLLATE NOCASE"
        args.append(a["app"])
    if a.get("category"):
        sql += " AND category=?"
        args.append(a["category"])
    if a.get("status"):
        sql += " AND incident_status=?"
        args.append(a["status"])
    if a.get("q"):
        sql += " AND (task_text LIKE ? OR root_cause LIKE ? OR COALESCE(incident_no,'') LIKE ?)"
        args += [f"%{a['q']}%"] * 3
    rows = [r.decorate(dict(x)) for x in get_db().execute(sql + " ORDER BY date DESC, id DESC", args)]
    if a.get("type"):
        rows = [x for x in rows if x["issue_type"] == a["type"]]
    per = 100
    page = max(1, int(a.get("page", 1) or 1))
    pages = max(1, (len(rows) + per - 1) // per)
    page = min(page, pages)
    apps = [x["app"] for x in q("SELECT DISTINCT app FROM abends ORDER BY app COLLATE NOCASE")]
    qs = {k: v for k, v in a.items() if k != "page" and v}
    return render_template("tracker.html", rows=rows[(page - 1) * per: page * per], total=len(rows), page=page,
                           pages=pages, apps=apps, f=a, qs=qs, statuses=["pending", "created", "historical"],
                           root_causes=[x["root_cause"] for x in r.root_causes])


@bp.route("/tracker/<int:row_id>/update", methods=["POST"])
def tracker_update(row_id):
    cur = q1("SELECT * FROM abends WHERE id=?", (row_id,))
    if not cur:
        abort(404)
    r = rules()
    from .intake import History, process_row
    f = request.form
    raw = {k: f.get(k, "") for k in intake.EDITABLE}
    new = process_row(raw, r, cur["date"], History(get_db()))
    errs = [i["msg"] for i in new["issues"] if i["level"] == "error"]
    if errs:
        flash("Not saved: " + " ".join(errs), "error")
        return redirect(request.referrer or url_for("main.tracker"))
    inc_no = clean(f.get("incident_no", ""))
    status = f.get("incident_status", cur["incident_status"])
    if status not in ("pending", "created", "historical"):
        status = cur["incident_status"]
    if inc_no and status == "pending":
        status = "created"          # typing an incident number means it exists
    if not inc_no and status == "created":
        status = "pending"          # no number -> back in the queue
    get_db().execute(
        """UPDATE abends SET app=?, task_text=?, task_name=?, process=?, run_id=?, alert=?, root_cause=?, action=?,
           date=?, category=?, comments=?, assigned_to=?, incident_no=?, incident_status=?, incident_error=NULL,
           updated_at=? WHERE id=?""",
        (new["app"], new["task_text"], new["task_name"], new["process"], new["run_id"], new["alert"],
         new["root_cause"], new["action"], new["date"], new["category"], new["comments"], f.get("assigned_to", "").strip(),
         inc_no or None, status, now(), row_id))
    get_db().commit()
    flash("Row updated.", "ok")
    return redirect(request.referrer or url_for("main.tracker"))


@bp.route("/tracker/<int:row_id>/delete", methods=["POST"])
def tracker_delete(row_id):
    cur = q1("SELECT incident_status FROM abends WHERE id=?", (row_id,))
    if not cur:
        abort(404)
    if cur["incident_status"] == "created":
        flash("This row has an incident. Clear the incident number first if you really want to delete it.", "error")
    else:
        run("DELETE FROM abends WHERE id=?", (row_id,))
        flash("Row deleted.", "ok")
    return redirect(request.referrer or url_for("main.tracker"))


# ============================================================================ incidents (recorded by hand)
@bp.route("/incidents")
def incidents_home():
    r = rules()
    mode = "row" if request.args.get("mode") == "row" else "group"
    d_from, d_to = request.args.get("from", ""), request.args.get("to", "")
    rows = incidents.open_rows(get_db(), d_from, d_to)
    items = incidents.build_items(r, rows, mode)
    return render_template("incidents.html", items=items, mode=mode, n_rows=len(rows), d_from=d_from, d_to=d_to,
                           recent=incidents.recent(get_db(), r))


@bp.route("/incidents/record", methods=["POST"])
def incidents_record():
    d = request.get_json(silent=True) or {}
    return jsonify(incidents.record_numbers(get_db(), d.get("entries"), bool(d.get("allow_same"))))


@bp.route("/incidents/skip", methods=["POST"])
def incidents_skip():
    ids = (request.get_json(silent=True) or {}).get("ids") or []
    if not isinstance(ids, list) or not all(isinstance(i, int) for i in ids) or not ids:
        return jsonify(ok=False, error="No rows supplied."), 400
    return jsonify(ok=True, changed=incidents.mark_no_incident(get_db(), ids))


@bp.route("/export/incidents.xlsx")
def export_incidents():
    r = rules()
    mode = "row" if request.args.get("mode") == "row" else "group"
    items = incidents.build_items(r, incidents.open_rows(get_db(), request.args.get("from", ""), request.args.get("to", "")), mode)
    return _xlsx_response(excel_io.incidents_workbook(items), f"Incidents_to_create_{date.today()}.xlsx")


# ============================================================================ config
@bp.route("/config")
def config_home():
    r = rules()
    return render_template("config.html", r=r, issue_help=ISSUE_TYPE_HELP, apps="\n".join(r.apps))


@bp.route("/config/save", methods=["POST"])
def config_save():
    f = request.form
    db = get_db()
    problems = []
    # Table 2 - existing rows
    for row in db.execute("SELECT id FROM root_causes").fetchall():
        i = row["id"]
        if f.get(f"rc_del_{i}"):
            db.execute("DELETE FROM root_causes WHERE id=?", (i,))
            continue
        name, itype = clean(f.get(f"rc_name_{i}", "")), f.get(f"rc_type_{i}", "")
        if not name or itype not in ISSUE_TYPES:
            problems.append(f"Row {i}: name and issue type are required.")
            continue
        try:
            db.execute("UPDATE root_causes SET root_cause=?, issue_type=?, aliases=?, resolution_summary=? WHERE id=?",
                       (name, itype, f.get(f"rc_alias_{i}", "").strip(), f.get(f"rc_sum_{i}", "").strip(), i))
        except sqlite3.IntegrityError:
            problems.append(f"'{name}' is listed twice.")
    # Table 2 - new rows
    for name, itype, alias, summ in zip(f.getlist("new_name"), f.getlist("new_type"), f.getlist("new_alias"),
                                        f.getlist("new_sum")):
        name = clean(name)
        if not name:
            continue
        if itype not in ISSUE_TYPES:
            problems.append(f"'{name}': pick an issue type.")
            continue
        try:
            db.execute("INSERT INTO root_causes(root_cause, issue_type, aliases, resolution_summary) VALUES(?,?,?,?)",
                       (name, itype, alias.strip(), summ.strip()))
        except sqlite3.IntegrityError:
            problems.append(f"'{name}' already exists.")
    # Table 3
    for k in EDITABLE_SETTINGS:      # an explicit allow-list of the settings this page may write
        if k in f:
            db.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                       (k, f.get(k, "").strip()))
    # apps
    if "apps" in f:
        wanted = [clean(a) for a in f.get("apps", "").splitlines() if clean(a)]
        db.execute("DELETE FROM app_names")
        for a in wanted:
            db.execute("INSERT OR IGNORE INTO app_names(name) VALUES(?)", (a,))
    db.commit()
    for p in problems:
        flash(p, "error")
    if not problems:
        flash("Configuration saved. Every tracker row picked up the change.", "ok")
    return redirect(url_for("main.config_home"))


# ============================================================================ admin (users)


@bp.route("/admin/users")
@admin_required
def admin_users():
    return render_template("admin_users.html", users=q("SELECT id, username, role, created_at FROM users ORDER BY id"),
                           min_pw=MIN_PASSWORD)


def _admin_count():
    return q1("SELECT COUNT(*) c FROM users WHERE role='admin'")["c"]


@bp.route("/admin/users/add", methods=["POST"])
@admin_required
def admin_users_add():
    name, pw = request.form.get("username", "").strip(), request.form.get("password", "")
    role = "admin" if request.form.get("role") == "admin" else "operator"
    if not USERNAME_RE.match(name):
        flash("Username: 3-40 letters, digits, dot, dash or underscore.", "error")
    elif len(pw) < MIN_PASSWORD:
        flash(f"Use at least {MIN_PASSWORD} characters for the password.", "error")
    elif q1("SELECT 1 FROM users WHERE username=?", (name,)):
        flash("That username already exists.", "error")
    else:
        run("INSERT INTO users(username, password_hash, role, created_at) VALUES(?,?,?,?)",
            (name, generate_password_hash(pw), role, now()))
        flash(f"User '{name}' created as {role}.", "ok")
    return redirect(url_for("main.admin_users"))


@bp.route("/admin/users/<int:uid>/password", methods=["POST"])
@admin_required
def admin_users_password(uid):
    pw = request.form.get("password", "")
    if len(pw) < MIN_PASSWORD:
        flash(f"Use at least {MIN_PASSWORD} characters.", "error")
    elif not q1("SELECT 1 FROM users WHERE id=?", (uid,)):
        abort(404)
    else:
        run("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(pw), uid))
        flash("Password reset.", "ok")
    return redirect(url_for("main.admin_users"))


@bp.route("/admin/users/<int:uid>/delete", methods=["POST"])
@admin_required
def admin_users_delete(uid):
    u = q1("SELECT * FROM users WHERE id=?", (uid,))
    if not u:
        abort(404)
    if u["username"] == g.user:
        flash("You can't delete the account you're signed in with.", "error")
    elif u["role"] == "admin" and _admin_count() <= 1:
        flash("There must always be at least one admin.", "error")
    else:
        run("DELETE FROM users WHERE id=?", (uid,))
        flash(f"User '{u['username']}' deleted.", "ok")
    return redirect(url_for("main.admin_users"))


# ============================================================================ exports
def _xlsx_response(wb, name):
    buf = io.BytesIO()
    wb.save(buf)
    return Response(buf.getvalue(), mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="{name}"'})


def _export_rows():
    a = request.args
    sql, args = "SELECT * FROM abends WHERE 1=1", []
    if a.get("from"):
        sql += " AND date>=?"
        args.append(a["from"])
    if a.get("to"):
        sql += " AND date<=?"
        args.append(a["to"])
    return [dict(x) for x in get_db().execute(sql + " ORDER BY date, id", args)]


@bp.route("/export/tracker.xlsx")
def export_tracker():
    return _xlsx_response(excel_io.tracker_workbook(rules(), _export_rows()), f"Abend_Tracker_{date.today()}.xlsx")


@bp.route("/export/abends_data.xlsx")
def export_abends_data():
    return _xlsx_response(excel_io.abends_data_workbook(rules(), _export_rows()), f"Abends_data_{date.today()}.xlsx")
