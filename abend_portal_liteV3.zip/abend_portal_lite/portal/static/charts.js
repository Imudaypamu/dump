/* Tiny dependency-free SVG charts (bar, horizontal bar, line, donut).
   No CDN, so the dashboard works on a locked-down network. Each chart redraws on resize. */
(function () {
  "use strict";
  var NS = "http://www.w3.org/2000/svg";
  var PALETTE = ["#0a5c8c", "#1b998b", "#e3a008", "#d1495b", "#6c5b9e", "#7a8ca0", "#3c8d40", "#b8693d"];
  var TYPE_COLORS = { "Grid Issue": "#2e9e4a" };

  function el(name, attrs, text) {
    var n = document.createElementNS(NS, name);
    for (var k in attrs) { if (Object.prototype.hasOwnProperty.call(attrs, k)) { n.setAttribute(k, attrs[k]); } }
    if (text !== undefined) { n.textContent = text; }
    return n;
  }
  function svg(w, h) { return el("svg", { viewBox: "0 0 " + w + " " + h, role: "img", width: w, height: h }); }
  function niceMax(v) {
    // return a max divisible by 4 so the four gridlines land on whole numbers
    var step = Math.max(1, v / 4);
    var p = Math.pow(10, Math.floor(Math.log(step) / Math.LN10));
    var f = step / p;
    var n = f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10;
    return 4 * n * p;
  }
  function short(l) { l = String(l); return /^\d{4}-\d{2}-\d{2}$/.test(l) ? l.slice(5) : l; }   // 2026-03-02 -> 03-02 (tooltip keeps the full date)
  function labelEvery(labels, pw) {
    var w = Math.max.apply(null, labels.map(function (l) { return short(l).length; })) * 6.4 + 12;
    return Math.max(1, Math.ceil(labels.length / Math.max(1, Math.floor(pw / w))));
  }
  function trunc(s, n) { s = String(s); return s.length > n ? s.slice(0, n - 1) + "\u2026" : s; }
  function tip(node, text) { node.appendChild(el("title", {}, text)); return node; }
  function empty(host) { host.innerHTML = '<div class="empty">No data in this range.</div>'; }

  function gridAndAxis(s, left, top, w, h, max) {
    var ticks = 4;
    for (var i = 0; i <= ticks; i++) {
      var y = top + h - (h * i / ticks);
      s.appendChild(el("line", { x1: left, x2: left + w, y1: y, y2: y, "class": i ? "grid" : "axis" }));
      s.appendChild(el("text", { x: left - 6, y: y + 4, "text-anchor": "end" }, Math.round(max * i / ticks)));
    }
  }

  function bar(host, data) {
    if (!data.length) { return empty(host); }
    var W = Math.max(host.clientWidth, 280), H = 230, L = 34, T = 10, B = 40, R = 8;
    var pw = W - L - R, ph = H - T - B;
    var max = niceMax(Math.max.apply(null, data.map(function (d) { return d.value; })));
    var s = svg(W, H);
    gridAndAxis(s, L, T, pw, ph, max);
    var slot = pw / data.length, bw = Math.min(46, slot * 0.64);
    var every = labelEvery(data.map(function (d) { return d.label; }), pw);
    data.forEach(function (d, i) {
      var h = ph * d.value / max, x = L + slot * i + (slot - bw) / 2, y = T + ph - h;
      s.appendChild(tip(el("rect", { x: x, y: y, width: bw, height: Math.max(h, d.value ? 1 : 0), rx: 2, fill: PALETTE[0], "class": "bar" }),
        d.label + ": " + d.value));
      if (i % every === 0) {
        s.appendChild(el("text", { x: x + bw / 2, y: T + ph + 16, "text-anchor": "middle" }, trunc(short(d.label), 10)));
      }
      if (d.value && data.length <= 14) {
        s.appendChild(el("text", { x: x + bw / 2, y: y - 4, "text-anchor": "middle" }, d.value));
      }
    });
    host.innerHTML = ""; host.appendChild(s);
  }

  function hbar(host, data, limit) {
    if (!data.length) { return empty(host); }
    var rows = data.slice(0, limit || 12), rest = data.slice(limit || 12);
    if (rest.length) {
      rows = rows.concat([{ label: "Other (" + rest.length + ")", value: rest.reduce(function (a, d) { return a + d.value; }, 0) }]);
    }
    var W = Math.max(host.clientWidth, 300), rowH = 26, T = 4, L = Math.min(215, W * 0.44), R = 40;
    var H = T + rows.length * rowH + 6;
    var max = Math.max.apply(null, rows.map(function (d) { return d.value; }));
    var s = svg(W, H);
    rows.forEach(function (d, i) {
      var y = T + i * rowH, w = (W - L - R) * d.value / max;
      s.appendChild(tip(el("text", { x: L - 8, y: y + 16, "text-anchor": "end" }, trunc(d.label, Math.floor((L - 12) / 7.2))), d.label));
      s.appendChild(tip(el("rect", { x: L, y: y + 3, width: Math.max(w, d.value ? 1 : 0), height: rowH - 8, rx: 2,
        fill: TYPE_COLORS[d.label] || PALETTE[0], "class": "bar" }), d.label + ": " + d.value));
      s.appendChild(el("text", { x: L + w + 6, y: y + 16 }, d.value));
    });
    host.innerHTML = ""; host.appendChild(s);
  }

  function line(host, data) {
    if (!data.length) { return empty(host); }
    var W = Math.max(host.clientWidth, 320), H = 240, L = 34, T = 12, B = 38, R = 12;
    var pw = W - L - R, ph = H - T - B;
    var hasMa = data[0].ma !== undefined;
    var max = niceMax(Math.max.apply(null, data.map(function (d) { return Math.max(d.value, d.ma || 0); })));
    var s = svg(W, H);
    gridAndAxis(s, L, T, pw, ph, max);
    var n = data.length, step = n > 1 ? pw / (n - 1) : 0;
    function X(i) { return n > 1 ? L + step * i : L + pw / 2; }
    function Y(v) { return T + ph - ph * v / max; }
    var pts = data.map(function (d, i) { return X(i) + "," + Y(d.value); });
    s.appendChild(el("polygon", { points: X(0) + "," + (T + ph) + " " + pts.join(" ") + " " + X(n - 1) + "," + (T + ph),
      fill: "#0a5c8c", "fill-opacity": 0.1 }));
    s.appendChild(el("polyline", { points: pts.join(" "), fill: "none", stroke: PALETTE[0], "stroke-width": 1.6, "stroke-linejoin": "round" }));
    if (hasMa) {
      s.appendChild(el("polyline", { points: data.map(function (d, i) { return X(i) + "," + Y(d.ma); }).join(" "),
        fill: "none", stroke: PALETTE[2], "stroke-width": 2.4, "stroke-linejoin": "round" }));
    }
    var labelEvery = Math.ceil(n / Math.max(2, Math.floor(pw / 72)));
    data.forEach(function (d, i) {
      if (n <= 60 || d.value === max) {
        s.appendChild(tip(el("circle", { cx: X(i), cy: Y(d.value), r: 3, fill: "#fff", stroke: PALETTE[0], "stroke-width": 1.5 }),
          d.label + ": " + d.value + (hasMa ? " (7-day average " + d.ma + ")" : "")));
      }
      if (i % labelEvery === 0) {
        s.appendChild(el("text", { x: X(i), y: T + ph + 16, "text-anchor": "middle" }, d.label.slice(5)));
      }
    });
    host.innerHTML = ""; host.appendChild(s);
    if (hasMa) {
      var lg = document.createElement("div"); lg.className = "legend";
      lg.innerHTML = '<span><i style="background:' + PALETTE[0] + '"></i>Abends per day</span><span><i style="background:' + PALETTE[2] + '"></i>7-day average</span>';
      host.appendChild(lg);
    }
  }

  // stacked columns: spec = { labels: [...], series: [{ name, values: [...] }] }
  function stack(host, spec) {
    var totals = spec.labels.map(function (_, i) { return spec.series.reduce(function (a, s) { return a + s.values[i]; }, 0); });
    if (!spec.labels.length || !Math.max.apply(null, totals)) { return empty(host); }
    var W = Math.max(host.clientWidth, 280), H = 240, L = 34, T = 10, B = 40, R = 8;
    var pw = W - L - R, ph = H - T - B, max = niceMax(Math.max.apply(null, totals));
    var s = svg(W, H);
    gridAndAxis(s, L, T, pw, ph, max);
    var slot = pw / spec.labels.length, bw = Math.min(46, slot * 0.64);
    var every = labelEvery(spec.labels, pw);
    spec.labels.forEach(function (lab, i) {
      var x = L + slot * i + (slot - bw) / 2, yBase = T + ph;
      spec.series.forEach(function (ser, k) {
        var h = ph * ser.values[i] / max;
        if (!h) { return; }
        yBase -= h;
        s.appendChild(tip(el("rect", { x: x, y: yBase, width: bw, height: h, fill: PALETTE[k % PALETTE.length], "class": "bar" }),
          lab + " - " + ser.name + ": " + ser.values[i]));
      });
      if (i % every === 0) {
        s.appendChild(el("text", { x: x + bw / 2, y: T + ph + 16, "text-anchor": "middle" }, trunc(short(lab), 10)));
      }
      if (totals[i] && spec.labels.length <= 14) {
        s.appendChild(el("text", { x: x + bw / 2, y: yBase - 4, "text-anchor": "middle" }, totals[i]));
      }
    });
    host.innerHTML = ""; host.appendChild(s);
    var lg = document.createElement("div"); lg.className = "legend";
    spec.series.forEach(function (ser, k) {
      var item = document.createElement("span"), sw = document.createElement("i");
      sw.style.background = PALETTE[k % PALETTE.length];
      item.appendChild(sw); item.appendChild(document.createTextNode(ser.name));
      lg.appendChild(item);
    });
    host.appendChild(lg);
  }

  function donut(host, data) {
    data = data.filter(function (d) { return d.value > 0; });
    if (!data.length) { return empty(host); }
    var total = data.reduce(function (a, d) { return a + d.value; }, 0);
    var size = 150, r = 58, c = size / 2, sw = 26, circ = 2 * Math.PI * r, off = 0;
    var s = svg(size, size);
    s.style.maxWidth = size + "px"; s.style.margin = "0 auto";
    data.forEach(function (d, i) {
      var len = circ * d.value / total;
      s.appendChild(tip(el("circle", { cx: c, cy: c, r: r, fill: "none", stroke: PALETTE[i % PALETTE.length], "stroke-width": sw,
        "stroke-dasharray": len + " " + (circ - len), "stroke-dashoffset": -off, transform: "rotate(-90 " + c + " " + c + ")" }),
        d.label + ": " + d.value + " (" + Math.round(100 * d.value / total) + "%)"));
      off += len;
    });
    s.appendChild(el("text", { x: c, y: c + 5, "text-anchor": "middle", style: "font-size:18px;font-weight:600" }, total));
    host.innerHTML = ""; host.appendChild(s);
    var lg = document.createElement("div"); lg.className = "legend";
    data.forEach(function (d, i) {
      var item = document.createElement("span");
      var sw2 = document.createElement("i"); sw2.style.background = PALETTE[i % PALETTE.length];
      item.appendChild(sw2);
      item.appendChild(document.createTextNode(d.label + " " + d.value + " (" + Math.round(100 * d.value / total) + "%)"));
      lg.appendChild(item);
    });
    host.appendChild(lg);
  }

  // cumulative comparison: points = [{ label, date, cur, prev }]
  function compare(host, pts) {
    if (!pts.length) { return empty(host); }
    var W = Math.max(host.clientWidth, 280), H = 240, L = 34, T = 12, B = 38, R = 12;
    var pw = W - L - R, ph = H - T - B;
    var max = niceMax(Math.max.apply(null, pts.map(function (p) { return Math.max(p.cur, p.prev); })));
    var s = svg(W, H);
    gridAndAxis(s, L, T, pw, ph, max);
    var n = pts.length, step = n > 1 ? pw / (n - 1) : 0;
    function X(i) { return n > 1 ? L + step * i : L + pw / 2; }
    function Y(v) { return T + ph - ph * v / max; }
    s.appendChild(el("polyline", { points: pts.map(function (p, i) { return X(i) + "," + Y(p.prev); }).join(" "),
      fill: "none", stroke: "#7a8ca0", "stroke-width": 2, "stroke-dasharray": "5 4" }));
    s.appendChild(el("polyline", { points: pts.map(function (p, i) { return X(i) + "," + Y(p.cur); }).join(" "),
      fill: "none", stroke: PALETTE[0], "stroke-width": 2.6, "stroke-linejoin": "round" }));
    var every = Math.ceil(n / Math.max(2, Math.floor(pw / 72)));
    pts.forEach(function (p, i) {
      var hit = el("rect", { x: X(i) - Math.max(step / 2, 3), y: T, width: Math.max(step, 6), height: ph, fill: "transparent" });
      hit.appendChild(el("title", {}, p.date + " (" + p.label + "): " + p.cur + " now, " + p.prev + " before"));
      s.appendChild(hit);
      if (i % every === 0) { s.appendChild(el("text", { x: X(i), y: T + ph + 16, "text-anchor": "middle" }, p.date.slice(5))); }
    });
    s.appendChild(el("circle", { cx: X(n - 1), cy: Y(pts[n - 1].cur), r: 3.6, fill: PALETTE[0] }));
    host.innerHTML = ""; host.appendChild(s);
    var lg = document.createElement("div"); lg.className = "legend";
    lg.innerHTML = '<span><i style="background:' + PALETTE[0] + '"></i>This period: ' + pts[n - 1].cur +
      '</span><span><i style="background:#7a8ca0"></i>Previous period: ' + pts[n - 1].prev + '</span>';
    host.appendChild(lg);
  }

  window.Charts = { bar: bar, hbar: hbar, line: line, donut: donut, stack: stack, compare: compare };
})();
