(function () {
  "use strict";
  var raw = document.getElementById("dash-data");
  if (!raw) { return; }
  var data = JSON.parse(raw.textContent);
  var hosts = Array.prototype.slice.call(document.querySelectorAll("[data-chart]"));
  var widths = new Map();

  function draw(host) {
    var series = data[host.getAttribute("data-series")] || [];
    var limit = parseInt(host.getAttribute("data-limit") || "0", 10) || undefined;
    window.Charts[host.getAttribute("data-chart")](host, series, limit);
    widths.set(host, host.clientWidth);
  }
  hosts.forEach(draw);

  // charts are drawn at their real pixel width, so redraw whenever a card changes width
  // (window resize, phone rotation, sidebar wrapping, a grid column appearing or disappearing)
  var timer;
  function redrawChanged() {
    clearTimeout(timer);
    timer = setTimeout(function () {
      hosts.forEach(function (h) { if (Math.abs(h.clientWidth - (widths.get(h) || 0)) > 2) { draw(h); } });
    }, 120);
  }
  if (window.ResizeObserver) {
    var ro = new ResizeObserver(redrawChanged);
    hosts.forEach(function (h) { ro.observe(h); });
  } else {
    window.addEventListener("resize", redrawChanged);
  }

  // top-task tabs
  var tabs = document.querySelectorAll("[data-tab]");
  tabs.forEach(function (b) {
    b.addEventListener("click", function () {
      tabs.forEach(function (x) { x.setAttribute("aria-selected", x === b ? "true" : "false"); });
      document.querySelectorAll("[data-panel]").forEach(function (p) { p.hidden = p.getAttribute("data-panel") !== b.getAttribute("data-tab"); });
    });
  });
})();
