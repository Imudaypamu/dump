(function () {
  "use strict";
  var raw = document.getElementById("items-data");
  if (!raw) { return; }
  var data = JSON.parse(raw.textContent), items = data.items;
  var bodies = Array.prototype.slice.call(document.querySelectorAll("#queue tbody[data-item]"));
  var selAll = document.getElementById("sel-all"), splitAll = document.getElementById("split-all");
  var saveBtn = document.getElementById("save-btn"), line = document.getElementById("status-line");
  var allowSame = document.getElementById("allow-same"), bulk = document.getElementById("bulk-number");
  var dlg = document.getElementById("fields-dlg");

  var itemOf = function (tb) { return items[parseInt(tb.getAttribute("data-item"), 10)]; };
  var isSplit = function (tb) { var s = tb.querySelector(".split"); return !!(s && s.checked); };
  var picked = function () { return bodies.filter(function (tb) { return tb.querySelector(".pick").checked; }); };

  // ---- what the user has typed -> entries to save
  function entries() {
    var out = [];
    bodies.forEach(function (tb) {
      var it = itemOf(tb);
      if (isSplit(tb)) {
        it.ids.forEach(function (id) {
          var inp = tb.querySelector('.num-task[data-id="' + id + '"]');
          if (inp && inp.value.trim()) { out.push({ ids: [id], number: inp.value, el: inp }); }
        });
      } else {
        var inp = tb.querySelector(".num-item");
        if (inp.value.trim()) { out.push({ ids: it.ids, number: inp.value, el: inp }); }
      }
    });
    return out;
  }
  function refresh() {
    var n = entries().length;
    document.getElementById("save-n").textContent = n;
    saveBtn.disabled = n === 0;
    document.getElementById("sel-count").textContent = picked().length;
    selAll.checked = picked().length === bodies.length && bodies.length > 0;
    if (splitAll) {
      var boxes = bodies.map(function (tb) { return tb.querySelector(".split"); }).filter(Boolean);
      splitAll.checked = boxes.length > 0 && boxes.every(function (b) { return b.checked; });
    }
  }
  function setSplit(tb) {
    var on = isSplit(tb);
    tb.querySelector(".num-item").disabled = on;
    if (on) { tb.querySelector(".num-item").value = ""; tb.querySelector("details.tasks").open = true; }
    tb.querySelectorAll(".split-only").forEach(function (c) { c.hidden = !on; });
    if (!on) { tb.querySelectorAll(".num-task").forEach(function (i) { i.value = ""; }); }
  }

  selAll.addEventListener("change", function () { bodies.forEach(function (tb) { tb.querySelector(".pick").checked = selAll.checked; }); refresh(); });
  if (splitAll) {
    splitAll.addEventListener("change", function () {
      bodies.forEach(function (tb) { var s = tb.querySelector(".split"); if (s) { s.checked = splitAll.checked; setSplit(tb); } });
      refresh();
    });
  }
  bodies.forEach(function (tb) {
    tb.querySelector(".pick").addEventListener("change", refresh);
    var s = tb.querySelector(".split");
    if (s) { s.addEventListener("change", function () { setSplit(tb); refresh(); }); }
    tb.addEventListener("input", function (e) { if (e.target.matches("input[type=text]")) { e.target.classList.remove("bad"); refresh(); } });
  });

  // ---- one number for everything selected (filled in, reviewed, then saved)
  document.getElementById("bulk-apply").addEventListener("click", function () {
    var v = bulk.value.trim(), sel = picked();
    if (!v) { line.textContent = "Type the incident number first."; return; }
    if (!sel.length) { line.textContent = "Tick the incidents it applies to."; return; }
    var targets = 0;
    sel.forEach(function (tb) {
      var boxes = isSplit(tb) ? tb.querySelectorAll(".num-task") : [tb.querySelector(".num-item")];
      Array.prototype.forEach.call(boxes, function (i) { i.value = v; targets++; });
    });
    if (targets > 1) { allowSame.checked = true; }
    line.textContent = "Filled in " + targets + " place(s). Review, then press Save numbers.";
    refresh();
  });
  document.getElementById("bulk-skip").addEventListener("click", function () {
    var sel = picked();
    if (!sel.length) { line.textContent = "Tick the incidents that need no incident."; return; }
    var ids = [];
    sel.forEach(function (tb) { ids = ids.concat(itemOf(tb).ids); });
    if (!window.confirm("Mark " + ids.length + " abend(s) as needing no incident? They leave this list and stay on the dashboard.")) { return; }
    window.postJSON("/incidents/skip", { ids: ids }).then(function (r) {
      if (r.ok) { window.location.reload(); } else { line.textContent = r.error || "Couldn't save."; }
    });
  });

  // ---- save
  saveBtn.addEventListener("click", function () {
    var es = entries();
    if (!es.length) { return; }
    saveBtn.disabled = true; line.textContent = "Saving...";
    window.postJSON("/incidents/record", { entries: es.map(function (e) { return { ids: e.ids, number: e.number }; }), allow_same: allowSame.checked })
      .then(function (r) {
        if (r.ok) { line.textContent = "Saved " + r.saved + " incident number(s) on " + r.rows + " abend(s)."; window.location.reload(); return; }
        line.textContent = r.error || "Couldn't save.";
        (r.errors || []).forEach(function (e) { if (es[e.index]) { es[e.index].el.classList.add("bad"); } });
        saveBtn.disabled = false;
      });
  });

  // ---- fields to copy
  function copyText(text, btn) {
    function done() { var old = btn.textContent; btn.textContent = "Copied"; setTimeout(function () { btn.textContent = old; }, 1200); }
    if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(text).then(done, fallback); } else { fallback(); }
    function fallback() {
      var ta = document.createElement("textarea"); ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.select();
      try { document.execCommand("copy"); done(); } catch (e) { btn.textContent = "Select and copy"; }
      document.body.removeChild(ta);
    }
  }
  var current = null;
  function showFields(title, payload) {
    current = payload;
    document.getElementById("fields-title").textContent = title;
    var body = document.getElementById("fields-body"); body.textContent = "";
    Object.keys(payload).forEach(function (k) {
      var row = document.createElement("div"); row.className = "field";
      var head = document.createElement("div"); head.style.cssText = "display:flex;justify-content:space-between;align-items:center;gap:8px";
      var lab = document.createElement("label"); lab.textContent = k; lab.style.margin = "0";
      var b = document.createElement("button"); b.type = "button"; b.className = "btn secondary small"; b.textContent = "Copy";
      b.addEventListener("click", function () { copyText(String(payload[k]), b); });
      head.appendChild(lab); head.appendChild(b);
      var pre = document.createElement("pre"); pre.className = "json"; pre.style.maxHeight = "9em"; pre.textContent = payload[k];
      row.appendChild(head); row.appendChild(pre); body.appendChild(row);
    });
    dlg.showModal();
  }
  document.getElementById("copy-all").addEventListener("click", function (e) {
    if (!current) { return; }
    copyText(Object.keys(current).map(function (k) { return k + ": " + current[k]; }).join("\n"), e.target);
  });
  bodies.forEach(function (tb) {
    var it = itemOf(tb);
    tb.querySelector("[data-fields]").addEventListener("click", function () { showFields(it.label, it.payload); });
    tb.querySelectorAll("[data-task-fields]").forEach(function (b) {
      b.addEventListener("click", function () {
        var id = b.getAttribute("data-id");
        showFields(it.row_payloads[id].short_description, it.row_payloads[id]);
      });
    });
  });
  refresh();
})();
