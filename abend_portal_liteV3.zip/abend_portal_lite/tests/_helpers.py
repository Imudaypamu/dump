import re


def csrf(html):
    return re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)


def login(client, user="admin", password="pw"):
    t = csrf(client.get("/login").text)
    return client.post("/login", data={"csrf_token": t, "username": user, "password": password})
