"""Optional browser check (needs `pip install playwright` + `playwright install chromium`).
Loads the pages at several screen widths and reports horizontal overflow, columns per card row and chart widths.
Usage: python tests/check_responsive.py http://127.0.0.1:5000 admin password"""
import sys
from playwright.sync_api import sync_playwright

base = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:5000"
user = sys.argv[2] if len(sys.argv) > 2 else "admin"
pw = sys.argv[3] if len(sys.argv) > 3 else "pw"
WIDTHS = [1600, 1366, 1100, 900, 768, 600, 414, 360]
PAGES = ["/dashboard?month=2026-03", "/dashboard?month=All+Months", "/intake", "/tracker", "/incidents", "/config"]
JS = """() => {
  const vw = document.documentElement.clientWidth, out = {vw, scroll: document.documentElement.scrollWidth, bad: [], rows: [], charts: 0, chartBad: []};
  document.querySelectorAll('main *').forEach(e => {
    if (e.closest('.table-wrap') || e.closest('pre') || e.closest('dialog') || e.closest('[hidden]') || e.closest('details:not([open])')) return;
    const r = e.getBoundingClientRect();
    if (r.width && r.right > vw + 1) out.bad.push((e.className || e.tagName).toString().slice(0, 40) + ' right=' + Math.round(r.right));
  });
  document.querySelectorAll('.cards').forEach(c => {
    const tops = new Set([...c.children].map(k => Math.round(k.getBoundingClientRect().top)));
    out.rows.push([...c.children].length + ' cards in ' + tops.size + ' row(s)');
  });
  document.querySelectorAll('.chart').forEach(h => {
    const s = h.querySelector('svg'); if (!s) return; out.charts++;
    if (s.getBoundingClientRect().width > h.getBoundingClientRect().width + 1) out.chartBad.push('svg wider than card');
  });
  return out;
}"""
with sync_playwright() as p:
    b = p.chromium.launch(); problems = 0
    for w in WIDTHS:
        pg = b.new_page(viewport={"width": w, "height": 900}); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.goto(base + "/login"); pg.fill("#u", user); pg.fill("#p", pw); pg.click("button[type=submit]")
        for path in PAGES:
            pg.goto(base + path); pg.wait_for_timeout(350)
            r = pg.evaluate(JS)
            bad = (r["scroll"] > r["vw"] + 1) or r["bad"] or r["chartBad"] or errs
            problems += 1 if bad else 0
            note = "" if not bad else f"  <-- scroll {r['scroll']}>{r['vw']} {r['bad'][:3]} {r['chartBad'][:2]} {errs[:1]}"
            if path.startswith("/dashboard?month=2026-03"):
                note = f"  rows: {r['rows'][:6]}" + note
            print(f"{w:>5}px {path:<28} {'OK ' if not bad else 'BAD'} charts={r['charts']}{note}")
        pg.close()
    b.close()
print("PROBLEMS:", problems)
