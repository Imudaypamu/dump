"""Discarding a batch and undoing a logged one."""
import os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _helpers as hp
from portal import create_app, db, intake
from portal.rules import Rules

app = create_app({"DATABASE": os.path.join(tempfile.mkdtemp(), "d.xlsx"), "PORTAL_PASSWORD": "pw", "TESTING": True})
c = app.test_client(); hp.login(c); conn = db.STORE.conn
txt = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample.txt")).read()
ok = []
def check(x, m): print(("PASS " if x else "FAIL ") + m); ok.append(x)
b = intake.create_batch(conn, Rules(conn), txt, "2026-07-29"); T = hp.csrf(c.get("/intake").text)
check("Discard</button>" in c.get("/intake").text, "list shows Discard for an open batch")
intake.commit(conn, Rules(conn), b)
page = c.get("/intake").text
check("Discard</button>" not in page and "Undo logging" in page, "after logging: list offers Undo logging instead")
check("Undo logging" in c.get(f"/intake/batch/{b}").text, "review page offers Undo logging")
conn.execute("UPDATE abends SET incident_no='INC1', incident_status='created' WHERE id=(SELECT MIN(id) FROM abends)"); conn.commit()
r = c.post(f"/intake/batch/{b}/undo", data={"csrf_token": T}, follow_redirects=True)
n = conn.execute("SELECT COUNT(*) FROM abends").fetchone()[0]
check(n == 1 and "5 logged row(s) removed" in r.text and "1 row(s) kept" in r.text, f"undo removed 5, kept the row with an incident ({n} left)")
b2 = intake.create_batch(conn, Rules(conn), txt, "2026-08-01"); c.post(f"/intake/batch/{b2}/discard", data={"csrf_token": T})
check(conn.execute("SELECT status FROM batches WHERE id=?", (b2,)).fetchone()[0] == "discarded", "discard leaves nothing logged")
b3 = intake.create_batch(conn, Rules(conn), txt, "2026-08-02"); intake.commit(conn, Rules(conn), b3)
c.post(f"/intake/batch/{b3}/undo", data={"csrf_token": T})
check(conn.execute("SELECT COUNT(*) FROM abends WHERE batch_id=?", (b3,)).fetchone()[0] == 0, "full undo removes every row")
print("FAILURES:", ok.count(False))
