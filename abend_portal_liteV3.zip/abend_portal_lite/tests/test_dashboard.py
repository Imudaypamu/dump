"""The broader dashboard, checked against your real history (157 abends, Dec 2025 - Jul 2026)."""
import os, re, shutil, sys, tempfile, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _helpers as hp
from portal import create_app, db, analytics
from portal.rules import Rules

root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
tmp = tempfile.mkdtemp(); wb = os.path.join(tmp, "d.xlsx"); shutil.copy(os.path.join(root, "data", "Abend_Portal_Data.xlsx"), wb)
app = create_app({"DATABASE": wb, "PORTAL_PASSWORD": "pw", "TESTING": True})
conn = db.STORE.conn; R = Rules(conn)
c = app.test_client(); hp.login(c)
ok = []
def check(x, m): print(("PASS " if x else "FAIL ") + m); ok.append(x)
A = lambda **f: analytics.compute(conn, R, f)

d = A(month="2026-03"); k = d["kpis"]
check(k["total"] == 26 and k["prev_total"] == 22 and round(k["delta_pct"]) == 18, f"March: 26 abends vs 22 before (+18%): {k['total']}/{k['prev_total']}")
check(d["range"]["eff_from"] == "2026-03-01" and d["changes"]["prev_from"] == "2026-01-29" and d["changes"]["prev_to"] == "2026-02-28", "previous period = the 31 days before")
raw = [dict(r) for r in conn.execute("SELECT * FROM abends WHERE date BETWEEN '2026-03-01' AND '2026-03-31'")]
check(k["total"] == len(raw) and k["unique_apps"] == len({r["app"] for r in raw}), "totals agree with the raw rows")
check(k["distinct_tasks"] == len({(r["task_name"] or "").lower() for r in raw}), "distinct tasks agree")
tasks = {}
for r in raw: tasks[(r["task_name"] or "").lower()] = tasks.get((r["task_name"] or "").lower(), 0) + 1
check(round(k["repeat_pct"], 1) == round(sum(v for v in tasks.values() if v > 1) / len(raw) * 100, 1), "repeat rate agrees")
t = d["trend"]
check(len(t) == 31 and sum(x["value"] for x in t) == 26 and all("ma" in x for x in t), "daily trend: 31 days, sums to total, has moving average")
i = 10; w = [x["value"] for x in t[max(0, i - 6): i + 1]]
check(abs(t[i]["ma"] - sum(w) / len(w)) < 0.01, "7-day moving average is correct")
check(d["mix"]["unit"] == "week" and len(d["mix"]["labels"]) >= 5 and sum(sum(s["values"]) for s in d["mix"]["series"]) == 26, f"one month -> weekly mix ({len(d['mix']['labels'])} weeks), sums to total")
m6 = A(month="All Months"); check(m6["mix"]["unit"] == "month" and sum(sum(s["values"]) for s in m6["mix"]["series"]) == 157 and len(m6["mix"]["labels"]) == len({r[0][:7] for r in conn.execute("SELECT date FROM abends")}), "long range -> monthly mix, all 157 counted")
cg = d["cat_group"]; check(cg["total"] == 26 and sum(r["total"] for r in cg["rows"]) == 26 and sum(cg["col_totals"]) == 26, "category x issue-group matrix is consistent")
h = d["heat"]; check(sum(r["total"] for r in h["rows"]) == sum(x for r in h["rows"] for x in r["cells"]) and h["rows"], "heatmap rows add up")
up = d["changes"]["up"]; down = d["changes"]["down"]
check(all(x["delta"] > 0 and x["cur"] - x["prev"] == x["delta"] for x in up) and all(x["delta"] < 0 for x in down), "what-changed lists have the right signs")
cur = {}; prev = {}
for r in conn.execute("SELECT app, date FROM abends"):
    if "2026-03-01" <= r["date"] <= "2026-03-31": cur[r["app"]] = cur.get(r["app"], 0) + 1
    if "2026-01-29" <= r["date"] <= "2026-02-28": prev[r["app"]] = prev.get(r["app"], 0) + 1
best = max(set(cur) | set(prev), key=lambda a: cur.get(a, 0) - prev.get(a, 0))
check(up and up[0]["delta"] == cur.get(best, 0) - prev.get(best, 0), f"biggest increase is right ({up[0]['app'] if up else None} +{up[0]['delta'] if up else 0})")
check(d["has_history"] is True, "March has earlier history, so 'newly failing' is meaningful")
first = {}
for r in conn.execute("SELECT task_name, date FROM abends ORDER BY date"): first.setdefault((r["task_name"] or "").lower(), r["date"])
for nt in d["new_tasks"]: check(first[nt["task"].lower()] >= "2026-03-01" and nt["first"] == first[nt["task"].lower()], f"new task really first failed in March: {nt['task'][:30]}")
check(A(month="All Months")["has_history"] is False and A(month="All Months")["new_tasks"] == [], "all-time view doesn't call every task 'new'")
check(A(month="All Months")["kpis"]["total"] == 157, "all months = 157")
check(A(month="2026-03", category="BDM")["kpis"]["total"] == sum(1 for r in raw if r["category"] == "BDM"), "category filter")
check(A(month="2026-03", app="VCD")["kpis"]["total"] == sum(1 for r in raw if r["app"] == "VCD"), "application filter")
check(A(month="2026-03", scope="grid")["kpis"]["grid_pct"] == 100.0, "grid-only scope")
check(A(month="2026-03", buffer="Yes")["range"]["eff_from"] == "2026-02-22", "+-7 days widens the range")
check(A(**{"month": "2026-03", "from": "2026-03-10", "to": "2026-03-12"})["kpis"]["days"] == 3, "custom from/to")
e = A(month="2026-03", app="ZZZ"); check(e["kpis"]["total"] == 0 and e["trend"] == [] and e["kpis"]["delta_pct"] is None, "empty selection is safe")
check(A(month="2026-07")["kpis"]["avg_per_day"] > 0, "avg per day works for the latest month")

pg = c.get("/dashboard?month=2026-03").text
for needle in ["Category mix by week", "Application by week", "By issue group", "Category by issue group", "What changed",
               "Newly failing tasks", "Repeat offenders", "Top tasks by category", "Category summary", "7-day average", "Repeat rate", "Average per day", "Distinct tasks", "This period against the previous one", "When failures happen", "Root cause mix by week", "Top processes", "Worst days", "Top 10 tasks cause", "Top 3 apps cause", "Weekend share"]:
    check(needle in pg, f"dashboard shows: {needle}")
check("Service desk" not in pg and "RITM" not in pg and "Waiting for incident" not in pg and "Open incidents" not in pg, "no incident analysis on the dashboard")
data = json.loads(re.search(r'id="dash-data">(.*?)</script>', pg, re.S).group(1))
check({"trend", "mix", "cause_mix", "compare", "by_day", "by_app", "by_type", "by_category", "by_group", "by_process"} <= set(data) and "by_action" not in data and "ma" in data["trend"][0] and data["mix"]["unit"] == "week", "chart data present")
check(c.get("/dashboard?month=2026-03&app=NOPE").status_code == 200 and "No abends in this range" in c.get("/dashboard?month=2026-03&app=NOPE").text, "empty state renders")
check(c.get("/dashboard").status_code == 200 and c.get("/dashboard?month=All+Months").status_code == 200, "default and all-months render")

# ---- new analytics, each checked against the raw rows
import datetime as _dt
from collections import Counter
cnt = Counter(((r["task_name"] or "").lower()) for r in raw)
top10 = sum(v for _, v in cnt.most_common(10)) / len(raw) * 100
check(abs(k["top10_share"] - top10) < 0.01, f"top-10 tasks share = {k['top10_share']:.1f}%")
apps3 = sum(v for _, v in Counter(r["app"] for r in raw).most_common(3)) / len(raw) * 100
check(abs(k["top3_apps_share"] - apps3) < 0.01, "top-3 apps share")
wk = sum(1 for r in raw if _dt.date.fromisoformat(r["date"]).weekday() >= 5) / len(raw) * 100
check(abs(k["weekend_share"] - wk) < 0.01, "weekend share")
cmpd = d["compare"]
check(cmpd[-1]["cur"] == 26 and cmpd[-1]["prev"] == 22 and len(cmpd) == 31 and all(cmpd[i]["cur"] <= cmpd[i + 1]["cur"] for i in range(30)), "cumulative comparison ends at 26 vs 22 and never decreases")
cal = d["calendar"]
check(sum(r["total"] for r in cal["rows"]) == 26 and [r["day"] for r in cal["rows"]] == ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], "calendar adds up to the total")
mon = sum(1 for r in raw if _dt.date.fromisoformat(r["date"]).weekday() == 0)
check(cal["rows"][0]["total"] == mon, f"calendar Monday total = {mon}")
bp = {x["label"]: x["value"] for x in d["by_process"]}
rawp = Counter(r["process"] for r in raw if r["process"])
check(bp == dict(rawp), "top processes match the raw rows")
wd = d["worst_days"]; rawd = Counter(r["date"] for r in raw)
check(wd[0]["count"] == max(rawd.values()) and all(wd[i]["count"] >= wd[i + 1]["count"] for i in range(len(wd) - 1)) and len(wd) == 5, "worst days are the busiest, in order")
check(all(w["apps"] == len({r["app"] for r in raw if r["date"] == w["date"]}) for w in wd), "worst-day app counts are right")
cm = d["cause_mix"]; check(sum(sum(s["values"]) for s in cm["series"]) == 26 and cm["labels"] == d["mix"]["labels"], "root cause mix sums to total and shares the weekly columns")
long = A(month="All Months")["cause_mix"]; check(sum(sum(s["values"]) for s in long["series"]) == 157, "root cause mix counts all 157 over a long range")
# repeat offenders: streak and gap computed independently
days = {}
for r in raw: days.setdefault((r["task_name"] or "").lower(), set()).add(r["date"])
def streak(ds):
    ds = sorted(_dt.date.fromisoformat(x) for x in ds); best = run = 1
    for a, b in zip(ds, ds[1:]):
        run = run + 1 if (b - a).days == 1 else 1; best = max(best, run)
    return best
for rp in d["repeat"][:6]:
    ds = days[rp["task"].lower()]
    check(rp["streak"] == streak(ds) and rp["days"] == len(ds), f"repeat offender streak/days right: {rp['task'][:28]} streak {rp['streak']}")
check(d["repeat"][0]["gap"] is None or d["repeat"][0]["gap"] > 0, "average gap is positive")
# action analysis is gone everywhere
check("by_action" not in d and "cat_action" not in d and "set_normal" not in k and "rerun" not in k, "no action analysis in the data")
check("Action taken" not in pg and "Rerun" not in pg and "Set to normal" not in pg and "set-to-normal" not in pg, "no action analysis on the page")
# responsive hooks present
css = open(os.path.join(root, "portal", "static", "app.css")).read()
check("@media (max-width: 900px)" in css and "@media (max-width: 600px)" in css and ".cards.c2" in css and ".cards.c3" in css, "responsive breakpoints in the stylesheet")
check('name="viewport"' in c.get("/dashboard").text, "viewport meta tag present")
print("FAILURES:", ok.count(False)); shutil.rmtree(tmp)
