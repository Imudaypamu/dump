"""Recording incident numbers by hand: one by one, split, bulk, validation, no incident needed."""
import os, sys, tempfile, shutil
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _helpers as hp
from portal import create_app, db, intake, incidents
from portal.rules import Rules

tmp = tempfile.mkdtemp()
app = create_app({"DATABASE": os.path.join(tmp, "d.xlsx"), "PORTAL_PASSWORD": "pw", "TESTING": True})
conn = db.STORE.conn
txt = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample.txt")).read()
# 6 rows -> 3 groups (grid x2 BDM, data x2 PWC, lookup-cache x2 PWC)
b1 = intake.create_batch(conn, Rules(conn), txt, "2026-07-29"); intake.commit(conn, Rules(conn), b1)
b2 = intake.create_batch(conn, Rules(conn), txt.replace("2026-07-29", "2026-07-30").replace("(2394", "(2494").replace("(2395", "(2495"), "2026-07-30")
intake.commit(conn, Rules(conn), b2)
c = app.test_client(); hp.login(c)
H = {"X-CSRF-Token": hp.csrf(c.get("/incidents").text)}
ok = []
def check(x, m): print(("PASS " if x else "FAIL ") + m); ok.append(x)
rec = lambda entries, **kw: c.post("/incidents/record", json={"entries": entries, **kw}, headers=H).get_json()
items = incidents.build_items(Rules(conn), incidents.open_rows(conn), "group")
page = c.get("/incidents").text
check(len(items) == 3 and all(i["count"] == 4 for i in items) and "12 logged abends" in page and "Fields" in page, f"queue shows 12 abends as {len(items)} incidents")
p = items[0]["payload"]
check("caller_id" not in p and list(p)[:3] == ["short_description", "description", "category"] and "close_notes" in p, "payload fields ready to copy (no caller_id)")
check("No incident numbers recorded yet" in page.replace("&#39;", "'") or "No incident numbers recorded yet" in page, "nothing recorded yet")

# --- validation: nothing is saved if anything is wrong
before = conn.execute("SELECT COUNT(*) FROM abends WHERE incident_no IS NOT NULL").fetchone()[0]
r = rec([{"ids": items[0]["ids"], "number": "INC2698633"}, {"ids": items[1]["ids"], "number": "12345"}])
check(not r["ok"] and "doesn't look like" in r["error"] and r["errors"][0]["index"] == 1, "bad format refused, error points at the right box")
check(conn.execute("SELECT COUNT(*) FROM abends WHERE incident_no IS NOT NULL").fetchone()[0] == before, "all-or-nothing: the valid one was not saved either")
r = rec([{"ids": items[0]["ids"], "number": "inc 2698633"}, {"ids": items[1]["ids"], "number": "INC2698633"}])
check(not r["ok"] and "more than one incident" in r["error"], "same number twice in one save refused by default")

# --- save one group (typed sloppily: lower case + space)
r = rec([{"ids": items[0]["ids"], "number": " inc2698633 "}])
check(r == {"ok": True, "saved": 1, "rows": len(items[0]["ids"])}, f"group saved: {r}")
rows = [dict(x) for x in conn.execute("SELECT incident_no, incident_status FROM abends WHERE id IN (%s)" % ",".join(map(str, items[0]["ids"])))]
check(all(x["incident_no"] == "INC2698633" and x["incident_status"] == "created" for x in rows), "every abend in the group got the number, normalised")
r = rec([{"ids": items[0]["ids"], "number": "INC2698999"}])
check(not r["ok"] and "already have an incident" in r["error"], "rows that already have an incident can't be overwritten here")
r = rec([{"ids": items[1]["ids"], "number": "INC2698633"}])
check(not r["ok"] and "already recorded" in r["error"], "number already used elsewhere refused")

# --- split a group: one number per task
g = items[1]; ids = g["ids"]
r = rec([{"ids": [ids[0]], "number": "INC2700001"}, {"ids": [ids[1]], "number": "INC2700002"}])
check(r["ok"] and r["saved"] == 2, "split group: each task got its own number")
check(conn.execute("SELECT COUNT(DISTINCT incident_no) FROM abends WHERE id IN (?,?)", ids[:2]).fetchone()[0] == 2, "two different numbers stored")

# --- one number for several incidents (bulk) needs the explicit tick
rest = items[1]["ids"][2:]
r = rec([{"ids": [rest[0]], "number": "INC2800000"}, {"ids": [rest[1]], "number": "INC2800000"}])
check(not r["ok"], "bulk same number refused without the tick")
r = rec([{"ids": [rest[0]], "number": "INC2800000"}, {"ids": [rest[1]], "number": "INC2800000"}], allow_same=True)
check(r["ok"] and r["saved"] == 2, "bulk same number accepted with 'same number is intended'")
check(len(incidents.open_rows(conn)) == 4, "recorded rows left the queue (only the 4 untouched rows remain)")

# --- no incident needed
left = incidents.open_rows(conn); ids_left = [x["id"] for x in left]
r = c.post("/incidents/skip", json={"ids": ids_left}, headers=H).get_json()
check(r["ok"] and r["changed"] == len(ids_left) and incidents.open_rows(conn) == [], "'no incident needed' clears them from the list")
check(conn.execute("SELECT COUNT(*) FROM abends WHERE incident_status='historical' AND incident_no IS NULL AND source!='excel:Abends_data'").fetchone()[0] >= len(ids_left), "they stay in the tracker/dashboard as 'no incident'")
check("No abends are waiting" in c.get("/incidents").text, "empty state shown")
page = c.get("/incidents").text
check("INC2698633" in page and "INC2800000" in page, "recently recorded list shows the numbers")
trk = c.get("/tracker").text
check("INC2698633" in trk and "no incident" in trk, "tracker shows numbers and 'no incident'")
check(c.get("/tracker?status=historical").status_code == 200 and c.get("/tracker?status=created").status_code == 200, "tracker status filter works")

# --- export of what's still to raise
b3 = intake.create_batch(conn, Rules(conn), txt.replace("2026-07-29", "2026-08-05").replace("(2394", "(2694").replace("(2395", "(2695"), "2026-08-05"); intake.commit(conn, Rules(conn), b3)
x = c.get("/export/incidents.xlsx")
from openpyxl import load_workbook
import io
ws = load_workbook(io.BytesIO(x.data)).active
check(x.data[:2] == b"PK" and ws.max_row == 4 and ws.cell(1, 2).value == "short_description" and ws.cell(1, 15).value.startswith("Incident number"), "Excel of incidents to raise (3 rows + header)")
check(c.get("/incidents?mode=row").status_code == 200 and "6 logged abends" in c.get("/incidents?mode=row").text, "per-row mode works")
# --- removed features really are gone
check(all(c.get(p).status_code == 404 for p in ["/tickets", "/script-incidents", "/incidents/close", "/admin/mywizard"]), "MyWizard / tickets / close / script pages are gone")
check("Service desk" not in c.get("/dashboard").text and "Open RITMs" not in c.get("/dashboard").text, "no incident analysis on the dashboard")
print("FAILURES:", ok.count(False)); shutil.rmtree(tmp)
