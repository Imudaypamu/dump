"""Paste -> review -> log -> dashboard/tracker/exports, and everything survives a restart."""
import os, re, shutil, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _helpers as hp
from portal import create_app, db
from openpyxl import load_workbook

tmp = tempfile.mkdtemp(); path = os.path.join(tmp, "data.xlsx")
app = create_app({"DATABASE": path, "PORTAL_PASSWORD": "pw", "TESTING": True})
c = app.test_client(); conn = db.STORE.conn
ok = []
def check(x, m): print(("PASS " if x else "FAIL ") + m); ok.append(x)
check(c.get("/dashboard").status_code == 302, "pages need a login")
hp.login(c)
for p in ["/dashboard", "/intake", "/tracker", "/incidents", "/config", "/account", "/admin/users"]:
    check(c.get(p).status_code == 200, f"GET {p}")
sample = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample.txt")).read()
T = hp.csrf(c.get("/intake").text)
r = c.post("/intake/parse", data={"csrf_token": T, "raw_text": sample, "default_date": "2026-07-29"}); burl = r.location
page = c.get(burl).text
check("RKH01J02" in page and "23941963" in page and "R_HVD_Process" in page, "review page shows extracted task / run id / process")
ids = re.findall(r'name="include_(\d+)"', page); form = {"csrf_token": hp.csrf(page), "then": "incidents"}
for i in ids:
    form[f"include_{i}"] = "1"
    for k in ("app", "root_cause", "date", "assigned_to", "task_text", "comments"):
        m = re.search(rf'name="{k}_{i}"[^>]*value="([^"]*)"', page)
        if m: form[f"{k}_{i}"] = m.group(1).replace("&#39;", "'")
    for k in ("action", "category"):
        blk = re.search(rf'<select name="{k}_{i}".*?</select>', page, re.S).group(0)
        sel = re.search(r"<option selected>([^<]*)</option>", blk); form[f"{k}_{i}"] = sel.group(1) if sel else ""
r = c.post(burl + "/commit", data=form)
check(r.status_code == 302 and "/incidents" in r.location, "log -> goes to Record incidents")
check("6 logged abends" in c.get("/incidents").text and "BDM | VCD, CDK | Grid issue" in c.get("/incidents").text, "incident list: 6 abends, grouped short description")
check("RKH01J02" in c.get("/tracker").text and "Category summary" in c.get("/dashboard?month=2026-07").text, "tracker and dashboard updated")
check(c.get("/export/tracker.xlsx").data[:2] == b"PK" and c.get("/export/abends_data.xlsx").data[:2] == b"PK", "excel exports")
T = hp.csrf(c.get("/config").text)
c.post("/config/save", data={"csrf_token": T, "itsm_impact": "2 - Medium"})
c.post("/intake/parse", data={"csrf_token": T, "raw_text": sample.replace("2026-07-29", "2026-07-30"), "default_date": "2026-07-30"})
app2 = create_app({"DATABASE": path, "PORTAL_PASSWORD": "pw", "TESTING": True}); st = db.STORE
check(st.load_notes == [], f"nothing skipped on reload: {st.load_notes}")
n = lambda t: st.conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
check(n("root_causes") == 8 and n("abends") == 6 and n("staging") == 12 and n("users") == 1, "root causes, abends, staging rows and users survive a restart")
check(st.conn.execute("SELECT value FROM settings WHERE key='itsm_impact'").fetchone()[0] == "2 - Medium", "config change survived")
names = set(load_workbook(path, read_only=True).sheetnames)
check(names == {"Abends", "Root Causes", "Applications", "Settings", "Users", "Batches", "Staging"}, f"workbook sheets: {sorted(names)}")
check(sorted(os.listdir(tmp)) == ["data.xlsx"], "only the workbook on disk")
print("FAILURES:", ok.count(False)); shutil.rmtree(tmp)
