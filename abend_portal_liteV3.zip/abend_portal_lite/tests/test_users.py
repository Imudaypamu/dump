"""Users and roles: admin manages users; operator uses everything else."""
import html as _html, os, shutil, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _helpers as hp
from portal import create_app, db

tmp = tempfile.mkdtemp(); path = os.path.join(tmp, "d.xlsx")
app = create_app({"DATABASE": path, "PORTAL_PASSWORD": "adminpass1", "TESTING": True,
                  "PORTAL_OPERATOR_USER": "ops", "PORTAL_OPERATOR_PASSWORD": "operpass1"})
conn = db.STORE.conn
ok = []
def check(c, m): print(("PASS " if c else "FAIL ") + m); ok.append(c)
U = _html.unescape
admin = app.test_client(); hp.login(admin, "admin", "adminpass1")
op = app.test_client(); check(hp.login(op, "ops", "operpass1").status_code == 302, "operator created from .env can sign in")
check(app.test_client().post("/login", data={"csrf_token": "x", "username": "ops", "password": "operpass1"}).status_code == 400, "login without CSRF refused")
check(hp.login(app.test_client(), "ops", "wrong").status_code == 401, "wrong password refused")
check(conn.execute("SELECT password_hash FROM users WHERE username='ops'").fetchone()[0].startswith(("scrypt:", "pbkdf2:")), "passwords stored hashed")
check("operpass1" not in open(path, "rb").read().decode("latin1"), "no plain-text password in the workbook")
for p in ["/dashboard", "/intake", "/tracker", "/incidents", "/config", "/account"]:
    check(op.get(p).status_code == 200, f"operator can use {p}")
check(op.get("/admin/users").status_code == 403, "operator can't open Users")
T = hp.csrf(op.get("/config").text)
for url, data in [("/admin/users/add", {"username": "hack", "password": "hackpass123", "role": "admin"}),
                  ("/admin/users/1/password", {"password": "hackedpass1"}), ("/admin/users/1/delete", {})]:
    check(op.post(url, data={"csrf_token": T, **data}).status_code == 403, f"operator POST {url} -> 403")
check(conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 2, "operator changed no users")
check("/admin/users" not in op.get("/dashboard").text and "/admin/users" in admin.get("/dashboard").text, "Users link only for admins")
T = hp.csrf(admin.get("/admin/users").text)
check("at least 8" in admin.post("/admin/users/add", data={"csrf_token": T, "username": "sam", "password": "short"}, follow_redirects=True).text, "short password refused")
check("Username:" in admin.post("/admin/users/add", data={"csrf_token": T, "username": "bad name!", "password": "longenough1"}, follow_redirects=True).text, "bad username refused")
check("created as operator" in U(admin.post("/admin/users/add", data={"csrf_token": T, "username": "sam", "password": "longenough1", "role": "operator"}, follow_redirects=True).text), "admin adds an operator")
check("already exists" in admin.post("/admin/users/add", data={"csrf_token": T, "username": "SAM", "password": "longenough1"}, follow_redirects=True).text, "duplicate username refused (any case)")
sam = app.test_client(); check(hp.login(sam, "sam", "longenough1").status_code == 302, "new operator can sign in")
uid = {r[1]: r[0] for r in conn.execute("SELECT id, username FROM users")}
check("can't delete the account" in U(admin.post(f"/admin/users/{uid['admin']}/delete", data={"csrf_token": T}, follow_redirects=True).text), "admin can't delete themselves")
admin.post("/admin/users/add", data={"csrf_token": T, "username": "boss2", "password": "longenough1", "role": "admin"})
boss = app.test_client(); hp.login(boss, "boss2", "longenough1"); Tb = hp.csrf(boss.get("/admin/users").text)
boss.post(f"/admin/users/{uid['admin']}/delete", data={"csrf_token": Tb})
b2 = {r[1]: r[0] for r in conn.execute("SELECT id, username FROM users")}
check("admin" not in b2, "another admin can delete the first admin")
check("can't delete the account" in U(boss.post(f"/admin/users/{b2['boss2']}/delete", data={"csrf_token": Tb}, follow_redirects=True).text)
      and conn.execute("SELECT COUNT(*) FROM users WHERE role='admin'").fetchone()[0] == 1, "the last admin can't remove themselves")
boss.post(f"/admin/users/{b2['sam']}/delete", data={"csrf_token": hp.csrf(boss.get("/admin/users").text)})
check(sam.get("/dashboard").status_code == 302 and "/login" in sam.get("/dashboard").location, "a deleted user's open session ends at once")
boss.post(f"/admin/users/{b2['ops']}/password", data={"csrf_token": hp.csrf(boss.get("/admin/users").text), "password": "resetpass12"})
check(hp.login(app.test_client(), "ops", "resetpass12").status_code == 302 and hp.login(app.test_client(), "ops", "operpass1").status_code == 401, "admin password reset works")
o2 = app.test_client(); hp.login(o2, "ops", "resetpass12"); T2 = hp.csrf(o2.get("/account").text)
check("current password is wrong" in o2.post("/account", data={"csrf_token": T2, "current": "nope", "new": "brandnew123", "repeat": "brandnew123"}, follow_redirects=True).text, "wrong current password refused")
check("Password changed" in o2.post("/account", data={"csrf_token": T2, "current": "resetpass12", "new": "brandnew123", "repeat": "brandnew123"}, follow_redirects=True).text, "operator changes own password")
app2 = create_app({"DATABASE": path, "PORTAL_PASSWORD": "different-env-pw", "TESTING": True})
check(hp.login(app2.test_client(), "ops", "brandnew123").status_code == 302 and hp.login(app2.test_client(), "admin", "different-env-pw").status_code == 401, "after restart: users persist, .env password ignored")
print("FAILURES:", ok.count(False)); shutil.rmtree(tmp)
